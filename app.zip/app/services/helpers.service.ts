import { Injectable } from '@angular/core';
import { EventableService } from '../services/eventable.service';
import { CoreService } from './core.service';
import { ConstantService } from './constant.service';

@Injectable({
  providedIn: 'root'
})
export class HelpersService {
  boxAttribute = "data-dhxbox";

  _dhx_msg_cfg = null;
  handlers = [];
  seed = (new Date()).valueOf();
  uId;
  expire = 4000;
  keyboard = true;
  position = "top";
  pull = {};
  timers = {};

  constructor(private eventableService: EventableService, private coreService: CoreService, private constantService:ConstantService) { }

  // Dom Event Scope

  attach(el, event, callback, capture) {
    this.handlers.push({ element: el, event, callback, capture });
    // this.eventableService.addEvent(el, event, callback, capture);
    this.eventableService.addEvent(el);
  }

  detach(el, event, callback, capture) {
    // this.eventableService.removeEvent(el, event, callback, capture);
    this.eventableService.removeEvent(el);

    for (let i = 0; i < this.handlers.length; i++) {
      let handler = this.handlers[i];
      if (handler.element === el && handler.event === event && handler.callback === callback && handler.capture === capture) {
        this.handlers.splice(i, 1);
        i--;
      }
    }
  }

  detachAll() {
    let staticArray = this.handlers.slice();
    // original this.handlers array can be spliced on every iteration
    for (let i = 0; i < staticArray.length; i++) {
      let handler = staticArray[i];
      this.detach(handler.element, handler.event, handler.callback, handler.capture);
      this.detach(handler.element, handler.event, handler.callback, undefined);
      this.detach(handler.element, handler.event, handler.callback, false);
      this.detach(handler.element, handler.event, handler.callback, true);
    }
    this.handlers.splice(0, this.handlers.length);
  }

  extend() {
    return this.createScope(this.event, this.eventRemove);
  }

  createScope(addEvent, removeEvent) {
    addEvent = addEvent || this.event;
    removeEvent = removeEvent || this.eventRemove;
    // if (!window.scopes) {
    //   window.scopes = [];
    // }
    // window.scopes.push(this.handlers);
  }

  // Dom Helpers JS
  elementPosition(elem) {
    let top = 0, left = 0, right = 0, bottom = 0;
    if (elem.getBoundingClientRect) { // HTML5 method
      let box = elem.getBoundingClientRect();
      let body = document.body;
      let docElem: any = (document.documentElement ||
        document.body.parentNode ||
        document.body);

      let scrollTop = window.pageYOffset || docElem.scrollTop || body.scrollTop;
      let scrollLeft = window.pageXOffset || docElem.scrollLeft || body.scrollLeft;
      let clientTop = docElem.clientTop || body.clientTop || 0;
      let clientLeft = docElem.clientLeft || body.clientLeft || 0;
      top = box.top + scrollTop - clientTop;
      left = box.left + scrollLeft - clientLeft;

      right = document.body.offsetWidth - box.right;
      bottom = document.body.offsetHeight - box.bottom;
    } else { // fallback to naive approach
      while (elem) {
        top = top + parseInt(elem.offsetTop, 10);
        left = left + parseInt(elem.offsetLeft, 10);
        elem = elem.offsetParent;
      }

      right = document.body.offsetWidth - elem.offsetWidth - left;
      bottom = document.body.offsetHeight - elem.offsetHeight - top;
    }
    return { y: Math.round(top), x: Math.round(left), width: elem.offsetWidth, height: elem.offsetHeight, right: Math.round(right), bottom: Math.round(bottom) };
  }

  isVisible(node) {
    let display: any = false,
      visibility: any = false;
    if (window.getComputedStyle) {
      let style = window.getComputedStyle(node, null);
      display = style.display;
      visibility = style['visibility'];
    } else if (node.currentStyle) {
      display = node.currentStyle['display'];
      visibility = node.currentStyle['visibility'];
    }
    return (display != 'none' && visibility != 'hidden');
  }

  hasNonNegativeTabIndex(node) {
    return !isNaN(node.getAttribute('tabindex')) && (node.getAttribute('tabindex') * 1 >= 0);
  }

  hasHref(node) {
    let canHaveHref = { 'a': true, 'area': true };
    if (canHaveHref[node.nodeName.loLowerCase()]) {
      return !!node.getAttribute('href');
    }
    return true;
  }

  isEnabled(node) {
    let canDisable = { 'input': true, 'select': true, 'textarea': true, 'button': true, 'object': true };
    if (canDisable[node.nodeName.toLowerCase()]) {
      return !node.hasAttribute('disabled');
    }

    return true;
  }

  getFocusableNodes(root) {
    let nodes = root.querySelectorAll([
      'a[href]',
      'area[href]',
      'input',
      'select',
      'textarea',
      'button',
      'iframe',
      'object',
      'embed',
      '[tabindex]',
      '[contenteditable]'
    ].join(', '));

    let nodesArray = Array.prototype.slice.call(nodes, 0);
    for (let i = 0; i < nodesArray.length; i++) {
      let node = nodesArray[i];
      let isValid = (this.hasNonNegativeTabIndex(node) || this.isEnabled(node) || this.hasHref(node)) && this.isVisible(node);
      if (!isValid) {
        nodesArray.splice(i, 1);
        i--;
      }
    }
    return nodesArray;
  }

  getScrollSize() {
    let div = document.createElement('div');
    div.style.cssText = 'visibility:hidden;position:absolute;left:-1000px;width:100px;padding:0px;margin:0px;height:110px;min-height:100px;overflow-y:scroll;';

    document.body.appendChild(div);
    let width = div.offsetWidth - div.clientWidth;
    document.body.removeChild(div);

    return width;
  }

  getClassName(node) {
    if (!node) { return ""; }

    let className = node.className || '';
    if (className.baseVal) {//'className' exist but not a string - IE svg element in DOM
      className = className.baseVal;
    }

    if (!className.indexOf) {
      className = "";
    }

    return this._trimString(className);
  }

  addClassName(node, className) {
    if (className && node.className.indexOf(className) === -1) {
      node.className += ' ' + className;
    }
  }

  removeClassName(node, name) {
    name = name.split(' ');
    for (let i = 0; i < name.length; i++) {
      let regEx = new RegExp('\\s?\\b' + name[i] + '\\b(?![-_.])', '');
      node.className = node.className.replace(regEx, '');
    }
  }

  hasClass(element, className) {
    if ('classList' in element) {
      return element.classList.contains(className);
    } else {
      return new RegExp('\\b' + className + '\\b').test(element.className);
    }
  }

  toNode(node) {
    if (typeof node === 'string') {
      return (document.getElementById(node) || document.querySelector(node) || document.body);
    }
    return node || document.body;
  }

  _slave = document.createElement('div');
  insert(node, newone) {
    this._slave.innerHTML = newone;
    let child = this._slave.firstChild;
    node.appendChild(child);
    return child;
  }

  remove(node) {
    if (node && node.parentNode) {
      node.parentNode.removeChild(node);
    }
  }

  getChildren(node, css) {
    let ch = node.childNodes;
    let len = ch.length;
    let out = [];
    for (let i = 0; i < len; i++) {
      let obj = ch[i];
      if (obj.className && obj.className.indexOf(css) !== -1) {
        out.push(obj);
      }
    }
    return out;
  }

  getTargetNode(e) {
    let trg;
    if (e.tagName) {
      trg = e;
    }
    else {
      e = e || window.event;
      trg = e.target || e.srcElement;
    }
    return trg;
  }

  locateAttribute(e, attribute) {
    if (!attribute) { return; }

    let trg = this.getTargetNode(e);

    while (trg) {
      if (trg.getAttribute) {	// text nodes has not getAttribute
        let test = trg.getAttribute(attribute);
        if (test) { return trg; }
      }
      trg = trg.parentNode;
    }
    return null;
  }

  _trimString(str) {
    let func = String.prototype.trim || function () { return this.replace(/^\s+|\s+$/g, ''); };
    return func.apply(str);
  }

  locateClassName(e, classname, strict) {
    let trg = this.getTargetNode(e);
    let css = '';

    if (strict === undefined) {
      strict = true;
    }

    while (trg) {
      css = this.getClassName(trg);
      if (css) {
        let ind = css.indexOf(classname);
        if (ind >= 0) {
          if (!strict) {
            return trg;
          }

          // check that we have exact match
          let left = (ind === 0) || (!this._trimString(css.charAt(ind - 1)));
          let right = ((ind + classname.length >= css.length)) || (!this._trimString(css.charAt(ind + classname.length)));

          if (left && right) {
            return trg;
          }
        }
      }
      trg = trg.parentNode;
    }
    return null;
  }

  /*
  event position relatively to DOM element
   */
  getRelativeEventPosition(ev, node) {
    let d = document.documentElement;
    let box = this.elementPosition(node);

    return {
      x: ev.clientX + d.scrollLeft - d.clientLeft - box.x + node.scrollLeft,
      y: ev.clientY + d.scrollTop - d.clientTop - box.y + node.scrollTop
    };
  }

  isChildOf(child, parent) {
    if (!child || !parent) {
      return false;
    }

    while (child && child != parent) {
      child = child.parentNode;
    }

    return child === parent;
  }

  closest(element, selector) {
    if (element.closest) {
      return element.closest(selector);
    } else if (element.matches || element.msMatchesSelector || element.webkitMatchesSelector) {
      let el = element;
      if (!document.documentElement.contains(el)) { return null; }
      do {
        let method = el.matches || el.msMatchesSelector || el.webkitMatchesSelector;

        if (method.call(el, selector)) { return el; }
        el = el.parentElement || el.parentNode;
      } while (el !== null && el.nodeType === 1);
      return null;
    } else {
      // eslint-disable-next-line no-console
      console.error('Your browser is not supported');
      return null;
    }
  }



  // Extends JS
  // tslint:disable-next-line: member-ordering
  extends = ((d, b) => {
    for (const p in b) {
      if (b.hasOwnProperty(p)) {
        d[p] = b[p];
      }
    }
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  });

  // Helpers JS
  // tslint:disable-next-line: member-ordering
  units = {
    second: 1,
    minute: 60,
    hour: 60 * 60,
    day: 60 * 60 * 24,
    week: 60 * 60 * 24 * 7,
    month: 60 * 60 * 24 * 30,
    quarter: 60 * 60 * 24 * 30 * 3,
    year: 60 * 60 * 24 * 365
  };

  getSecondsInUnit(unit) {
    return this.units[unit] || this.units.hour;
  }

  forEach(arr, callback) {
    if (arr.forEach) {
      arr.forEach(callback);
    } else {
      const workArray = arr.slice();
      for (let i = 0; i < workArray.length; i++) {
        callback(workArray[i], i);
      }
    }
  }

  arrayMap(arr, callback) {
    if (arr.map) {
      return arr.map(callback);
    } else {
      const workArray = arr.slice();
      const resArray = [];

      for (let i = 0; i < workArray.length; i++) {
        resArray.push(callback(workArray[i], i));
      }
      return resArray;
    }
  }


  arrayFind(arr, callback) {
    if (arr.find) {
      return arr.find(callback);
    } else {
      for (let i = 0; i < arr.length; i++) {
        if (callback(arr[i], i)) {
          return arr[i];
        }
      }
    }
  }

  // iframe-safe array type check instead of using instanceof
  isArray(obj) {
    if (Array.isArray) {
      return Array.isArray(obj);
    } else {
      // close enough
      return (obj && obj.length !== undefined && obj.pop && obj.push);
    }
  }

  // non-primitive string object, e.g. new String("abc")
  isStringObject(obj) {
    return obj && typeof obj === 'object'
      && Function.prototype.toString.call(obj.constructor) === 'function String() { [native code] }';
  }

  // non-primitive number object, e.g. new Number(5)
  isNumberObject(obj) {
    return obj && typeof obj === 'object'
      && Function.prototype.toString.call(obj.constructor) === 'function Number() { [native code] }';
  }

  // non-primitive number object, e.g. new Boolean(true)
  isBooleanObject(obj) {
    return obj && typeof obj === 'object'
      && Function.prototype.toString.call(obj.constructor) === 'function Boolean() { [native code] }';
  }

  isDate(obj) {
    if (obj && typeof obj === 'object') {
      return !!(obj.getFullYear && obj.getMonth && obj.getDate);
    } else {
      return false;
    }
  }

  arrayFilter(arr, callback) {
    const result = [];

    if (arr.filter) {
      return arr.filter(callback);
    } else {
      for (let i = 0; i < arr.length; i++) {
        if (callback(arr[i], i)) {
          result[result.length] = arr[i];
        }
      }
      return result;
    }
  }

  hashToArray(hash) {
    const result = [];

    for (const key in hash) {
      if (hash.hasOwnProperty(key)) {
        result.push(hash[key]);
      }
    }

    return result;
  }

  arraySome(arr, callback) {
    if (arr.length === 0) { return false; }

    for (let i = 0; i < arr.length; i++) {
      if (callback(arr[i], i, arr)) {
        return true;
      }
    }
    return false;
  }

  arrayDifference(arr, callback) {
    return this.arrayFilter(arr, function (item, i) {
      return !callback(item, i);
    });
  }

  throttle(callback, timeout) {
    let wait = false;

    // tslint:disable-next-line: only-arrow-functions
    return function () {
      if (!wait) {
        callback.apply(null, arguments);
        wait = true;
        setTimeout(() => {
          wait = false;
        }, timeout);
      }
    };
  }

  delay(callback, timeout) {
    let timer;

    let result: any = function () {
      result.$cancelTimeout();
      callback.pending = true;
      let args = Array.prototype.slice.call(arguments);
      timer = setTimeout(() => {
        callback.apply(this, args);
        result.pending = false;
      }, timeout);
    };

    result.pending = false;
    result.cancelTimeout = function () {
      clearTimeout(timer);
      callback.pending = false;
    };
    result.$execute = function () {
      callback();
      callback.$cancelTimeout();
    };

    return result;
  }

  sortArrayOfHash(arr, field, desc) {
    const compare = function (a, b) {
      return a < b;
    };

    arr.sort(function (a, b) {
      if (a[field] === b[field]) { return 0; }

      return desc ? compare(a[field], b[field]) : compare(b[field], a[field]);
    });
  }

  objectKeys(obj) {
    if (Object.keys) {
      return Object.keys(obj);
    }
    const result = [];
    let key;
    for (key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        result.push(key);
      }
    }
    return result;
  }

  requestAnimationFrame(callback) {
    const w = window;
    const foundRequestAnimationFrame = w.requestAnimationFrame
      || w.webkitRequestAnimationFrame
      // || w.msRequestAnimationFrame
      // || w.mozRequestAnimationFrame
      // || w.oRequestAnimationFrame
      || ((cb) => { setTimeout(cb, 1000 / 60); });
    return foundRequestAnimationFrame(callback);
  }

  isEventable(obj) {
    return obj.attachEvent && obj.detachEvent;
  }

  // Html Helpers JS
  // tslint:disable-next-line: member-ordering

  getHtmlSelect(options, attributes, value) {
    let innerHTML = '';
    // tslint:disable-next-line: variable-name
    const _this = this;
    options = options || [];

    this.forEach(options, (entry) => {
      // tslint:disable-next-line: variable-name
      let _attributes = [{ key: 'value', value: entry.key }];

      if (value === entry.key) {
        _attributes[_attributes.length] = { key: 'selected', value: 'selected' };
      }
      if (entry.attributes) {
        _attributes = _attributes.concat(entry.attributes);
      }
      innerHTML += _this.getHtmlOption({ innerHTML: entry.label }, _attributes);
    });

    return this._getHtmlContainer('select', { innerHTML }, attributes);
  }
  getHtmlOption(options, attributes) { return this._getHtmlContainer('option', options, attributes); }

  getHtmlButton(options, attributes) { return this._getHtmlContainer('button', options, attributes); }

  getHtmlDiv(options, attributes) { return this._getHtmlContainer('div', options, attributes); }
  
  getHtmlLabel(options, attributes) { return this._getHtmlContainer('label', options, attributes); }

  getHtmlInput(attributes) {
    return '<input' + this._getHtmlAttributes(attributes || []) + '>';
  }

  _getHtmlContainer(tag, options, attributes) {
    let html;

    options = options || [];

    html = '<' + tag + this._getHtmlAttributes(attributes || []) + '>' + (options.innerHTML || '') + '</' + tag + '>';
    return html;

  }

  _getHtmlAttributes(attributes) {
    let html = '';

    this.forEach(attributes, (entry) => {
      html += ' ' + entry.key + `='` + entry.value + `'`;
    });
    return html;
  }

  // Task Tree Helpers JS
  copyLinkIdsArray(gantt, linkIds, targetHash) {
    for (let i = 0; i < linkIds.length; i++) {
      if (gantt.isLinkExists(linkIds[i])) {
        targetHash[linkIds[i]] = gantt.getLink(linkIds[i]);
      }
    }
  }

  copyLinkIds(gantt, task, targetHash) {
    this.copyLinkIdsArray(gantt, task.$source, targetHash);
    this.copyLinkIdsArray(gantt, task.$target, targetHash);
  }

  getSubtreeLinks(gantt, rootId) {
    const res = {};

    if (gantt.isTaskExists(rootId)) {
      this.copyLinkIds(gantt, gantt.getTask(rootId), res);
    }

    gantt.eachTask((child) => {
      this.copyLinkIds(gantt, child, res);
    }, rootId);

    return res;
  }

  getSubtreeTasks(gantt, rootId) {
    const res = {};

    gantt.eachTask((child) => {
      res[child.id] = child;
    }, rootId);

    return res;
  }


  // Timeout JS
  checkTimeout(host, updPerSecond) {
    if (!updPerSecond) {
      return true;
    }

    if (host._on_timeout) {
      return false;
    }

    const timeout = Math.ceil(1000 / updPerSecond);
    if (timeout < 2) {
      return true;
    }
    setTimeout(() => {
      delete host._on_timeout;
    }, timeout);

    host._on_timeout = true;
    return true;
  }

  // Utils JS
  copy(object) {
    let i, result; // iterator, types array, result

    if (object && typeof object === 'object') {

      switch (true) {
        case (this.isDate(object)):
          result = new Date(object);
          break;
        case (this.isArray(object)):
          result = new Array(object.length);
          for (i = 0; i < object.length; i++) {
            result[i] = this.copy(object[i]);
          }
          break;
        case (this.isStringObject(object)):
          result = new String(object);
          break;
        case (this.isNumberObject(object)):
          result = new Number(object);
          break;
        case (this.isBooleanObject(object)):
          result = new Boolean(object);
          break;
        default:
          result = {};
          for (i in object) {
            if (Object.prototype.hasOwnProperty.apply(object, [i])) {
              result[i] = this.copy(object[i]);
            }
          }
          break;
      }
    }
    return result || object;
  }

  mixin(target, source, force?) {
    for (const f in source) {
      if (((target[f] === undefined) || force)) {
        target[f] = source[f];
      }
    }
    return target;
  }

  defined(obj) {
    return typeof (obj) !== 'undefined';
  }

  uid() {
    let seed;
    if (!seed) {
      seed = (new Date()).valueOf();
    }
    seed++;
    return seed;
  }

  bind(functor, object) {
    if (functor.bind) {
      return functor.bind(object);
    } else {
      // tslint:disable-next-line: only-arrow-functions
      return function () { return functor.apply(object, arguments); };
    }
  }

  eventRemove(el, event, handler, capture) {
    if (el.removeEventListener) {
      el.removeEventListener(event, handler, capture === undefined ? false : capture);
    } else if (el.detachEvent) {
      el.detachEvent('on' + event, handler);
    }
  }

  event(el, event, handler, capture?) {
    if (el.addEventListener) {
      el.addEventListener(event, handler, capture === undefined ? false : capture);
    } else if (el.attachEvent) {
      el.attachEvent('on' + event, handler);
    }
  }



  // return {
  //   copy: this.copy,
  //   defined: this.defined,
  //   mixin: this.mixin,
  //   uid: this.uid,
  //   bind: this.bind,
  //   event: this.event,
  //   eventRemove: this.eventRemove
  // };

  callback(config, result) {
    var usercall = config.callback;
    this.hide(config.box);

    this._dhx_msg_cfg = config.box = null;
    if (usercall)
      usercall(result);
  }

  e;
  modal_key(e) {
    if (this._dhx_msg_cfg) {
      this.e = e || event;
      var code = e.which || e.keyCode; // event.keyCode;
      var preventDefault = false;

      if (this.keyboard) {
        if (code == 13 || code == 32) {
          // default behavior is to confirm/submit popup on space/enter
          // if browser focus is set on button element - do button click instead of default behavior
          var target = e.target || e.srcElement;
          if (this.getClassName(target).indexOf("gantt_popup_button") > -1 && target.click) {
            target.click();
          } else {
            this.callback(this._dhx_msg_cfg, true);
            preventDefault = true;
          }
        }

        if (code == 27) {
          this.callback(this._dhx_msg_cfg, false);
          preventDefault = true;
        }
      }

      if (preventDefault) {
        if (e.preventDefault)
          e.preventDefault();
        return !(e.cancelBubble = true);
      }
      return;
    }
  }

  // this.event(document, "keydown", modal_key, true);

  // tslint:disable-next-line: member-ordering
  modalityObject: any = {
    cover: ''
  };

  modality(mode) {
    if (!this.modalityObject.cover) {
      this.modalityObject.cover = document.createElement("div");
      //necessary for IE only
      this.modalityObject.cover.onkeydown = this.modal_key;
      this.modalityObject.cover.className = "dhx_modal_cover";
      document.body.appendChild(this.modalityObject.cover);
    }

    this.modalityObject.cover.style.display = mode ? "inline-block" : "none";
  }

  button(text, className, result) {
    // var buttonAriaAttrs = this.coreService.messageButtonAttrString(text);
    var buttonAriaAttrs;
    var name = className.toLowerCase().replace(/ /g, "_");
    var button_css = "gantt_" + name + "_button" + " dhtmlx_" + name + "_button"; // dhtmlx_ok_button, dhtmlx_click_me_button
    return "<div " + buttonAriaAttrs + " class='gantt_popup_button dhtmlx_popup_button " + button_css + "' data-result='" + result + "' result='" + result + "' ><div>" + text + "</div></div>";
  }

  // tslint:disable-next-line: member-ordering
  messageBoxObject: any = {
    area:'',
    position: ''
  };

  messageonclick(text) {
    this.messageBoxhide(text.id);
    text = null;
  }

  info(text) {
    if (!this.messageBoxObject.area) {
      this.messageBoxObject.area = document.createElement("div");
      this.messageBoxObject.area.className = "gantt_message_area dhtmlx_message_area";
      this.messageBoxObject.area.style[this.messageBoxObject.position] = "5px";
      document.body.appendChild(this.messageBoxObject.area);
    }

    this.messageBoxhide(text.id);
    var message = document.createElement("div");
    message.innerHTML = "<div>" + text.text + "</div>";
    message.className = "gantt-info dhtmlx-info gantt-" + text.type + " dhtmlx-" + text.type;
   this.messageonclick(text);

    // this.coreService.messageInfoAttr(message);

    if (this.messageBoxObject.position == "bottom" && this.messageBoxObject.area.firstChild)
      this.messageBoxObject.area.insertBefore(message, this.messageBoxObject.area.firstChild);
    else
      this.messageBoxObject.area.appendChild(message);

    if (text.expire > 0)
      this.timers[text.id] = window.setTimeout(function () {
        this.messageBoxhide(text.id);
      }, text.expire);

    this.pull[text.id] = message;
    message = null;

    return text.id;
  }

  getFirstDefined(...args) {
    var values = [].slice.apply(arguments, [0]);

    for (var i = 0; i < values.length; i++) {
      if (values[i]) {
        return values[i];
      }
    }

  }

  _boxStructure(config, ok, cancel) {
    var box = document.createElement("div");

    var contentId = this.uid();
    // this.coreService.messageModalAttr(box, contentId);


    box.className = " gantt_modal_box dhtmlx_modal_box gantt-" + config.type + " dhtmlx-" + config.type;
    box.setAttribute(this.boxAttribute, '1');

    var inner = '';

    if (config.width)
      box.style.width = config.width;
    if (config.height)
      box.style.height = config.height;
    if (config.title)
      inner += '<div class="gantt_popup_title dhtmlx_popup_title">' + config.title + '</div>';
    inner += '<div class="gantt_popup_text dhtmlx_popup_text" id="' + contentId + '"><span>' + (config.content ? '' : config.text) + '</span></div><div  class="gantt_popup_controls dhtmlx_popup_controls">';
    if (ok)
      inner += this.button(this.getFirstDefined(config.ok, this.constantService.locale.labels.message_ok, "OK"), "ok", true);
    if (cancel)
      inner += this.button(this.getFirstDefined(config.cancel, this.constantService.locale.labels.message_cancel, 'Cancel'), "cancel", false);

    if (config.buttons) {
      for (var i = 0; i < config.buttons.length; i++) {
        var btn = config.buttons[i];
        if (typeof btn == "object") {
          // Support { label:"Save", css:"main_button", value:"save" }
          var label = btn.label;
          var css = btn.css || ("gantt_" + btn.label.toLowerCase() + "_button dhtmlx_" + btn.label.toLowerCase() + "_button");
          var value = btn.value || i;
          inner += this.button(label, css, value);
        } else {
          inner += this.button(btn, btn, i);
        }
      }
    }

    inner += '</div>';
    box.innerHTML = inner;

    if (config.content) {
      var node = config.content;
      if (typeof node == "string")
        node = document.getElementById(node);
      if (node.style.display == 'none')
        node.style.display = "";
      box.childNodes[config.title ? 1 : 0].appendChild(node);
    }

    this.boxOnClick(this.e, config);
    config.box = box;
    if (ok || cancel)
      this._dhx_msg_cfg = config;

    return box;
  }

  boxOnClick(e,config) {
    // e = e || event ;
    var source = (<HTMLInputElement>e.target) || (<HTMLInputElement>e.srcElement);
    // if (!source.className) source = source.parentNode;
    if (source.className.split(' ')[0] == 'gantt_popup_button') {
      var result: any = source.getAttribute("data-result");
      result = (result == "true") || (result == "false" ? false : result);
      this.callback(config, result);
    }
  };

  _createBox(config, ok?, cancel?) {
    var box = config.tagName ? config : this._boxStructure(config, ok, cancel);

    if (!config.hidden)
      this.modality(true);
    document.body.appendChild(box);
    var x = Math.abs(Math.floor(((window.innerWidth || document.documentElement.offsetWidth) - box.offsetWidth) / 2));
    var y = Math.abs(Math.floor(((window.innerHeight || document.documentElement.offsetHeight) - box.offsetHeight) / 2));
    if (config.position == "top")
      box.style.top = "-3px";
    else
      box.style.top = y + 'px';
    box.style.left = x + 'px';
    //necessary for IE only
    box.onkeydown = this.modal_key;

    this.focus(box);

    if (config.hidden)
      this.hide(box);

    gantt.callEvent("onMessagePopup", [box]);
    return box;
  }

  alertPopup(config) {
    return this._createBox(config, true, false);
  }

  confirmPopup(config) {
    return this._createBox(config, true, true);
  }

  boxPopup(config) {
    return this._createBox(config);
  }

  box_params(text, type, callback) {
    if (typeof text != "object") {
      if (typeof type == "function") {
        callback = type;
        type = "";
      }
      text = { text: text, type: type, callback: callback };
    }
    return text;
  }

  params(text, type, expire, id) {
    if (typeof text != "object")
      text = { text: text, type: type, expire: expire, id: id };
    text.id = text.id || this.uid();
    text.expire = text.expire || this.expire;
    return text;
  }

  alertBox() {
    var text = this.box_params.apply(this, arguments);
    text.type = text.type || "confirm";
    return this.alertPopup(text);
  }

  confirmBox() {
    var text = this.box_params.apply(this, arguments);
    text.type = text.type || "alert";
    return this.confirmPopup(text);
  }

  modalBox() {
    var text = this.box_params.apply(this, arguments);
    text.type = text.type || "alert";
    return this.boxPopup(text);
  }

  hide(node) {
    while (node && node.getAttribute && !node.getAttribute(this.boxAttribute))
      node = node.parentNode;
    if (node) {
      node.parentNode.removeChild(node);
      this.modality(false);

      gantt.callEvent("onAfterMessagePopup", [node]);
    }
  }

  focus(node) {
    setTimeout(function () {
      var focusable = this.domHelpers.getFocusableNodes(node);
      if (focusable.length) {
        if (focusable[0].focus) focusable[0].focus();
      }
    }, 1);
  }

  messageBox(text, type, expire, id) {
    text = this.params.apply(this, arguments);
    text.type = text.type || "info";

    var subtype = text.type.split("-")[0];
    switch (subtype) {
      case "alert":
        return this.alertPopup(text);
      case "confirm":
        return this.confirmPopup(text);
      case "modalbox":
        return this.boxPopup(text);
      default:
        return this.info(text);
    }
  }



  hideAll() {
    for (var key in this.pull)
      this.messageBoxhide(key);
  }

  messageBoxhide(id) {
    var obj = this.pull[id];
    if (obj && obj.parentNode) {
      window.setTimeout(function () {
        obj.parentNode.removeChild(obj);
        obj = null;
      }, 2000);
      obj.className += " hidden";

      if (this.timers[id])
        window.clearTimeout(this.timers[id]);
      delete this.pull[id];
    }
  }

  popups = [];
  onMessagePopupsbox = function (box) {
    this.popups.push(box);
  }

  onAfterMessagePopup = function (box) {
    for (var i = 0; i < this.popups.length; i++) {
      if (this.popups[i] === box) {
        this.popups.splice(i, 1);
        i--;
      }
    }
  }

  onDestroy = function () {
    if (this.modalityObject.cover && this.modalityObject.cover.parentNode) {
      this.modalityObject.cover.parentNode.removeChild(this.modalityObject.cover);
    }

    for (var i = 0; i < this.popups.length; i++) {
      if (this.popups[i].parentNode) {
        this.popups[i].parentNode.removeChild(this.popups[i]);
      }
    }
    this.popups = null;

    if (this.messageBoxObject.area && this.messageBoxObject.area.parentNode) {
      this.messageBoxObject.area.parentNode.removeChild(this.messageBoxObject.area);
    }
    this.messageBoxObject = null;
  }

//   this.eventableService.attachEvent("onMessagePopup", this.onMessagePopupsbox);

// this.eventableServiceattachEvent("onAfterMessagePopup", this.onAfterMessagePopup);

// this.eventableService.attachEvent("onDestroy", this.onDestroy);

  // message = function (gantt) {


  //   return {
  //     alert: alertBox,
  //     confirm: confirmBox,
  //     message: messageBox,
  //     modalbox: modalBox
  //   };

  //   // module.exports = {
  //   //   alert: alertBox,
  //   //   confirm: confirmBox,
  //   //   message: messageBox,
  //   //   modalbox: modalBox
  //   // };
  // };
  
}
