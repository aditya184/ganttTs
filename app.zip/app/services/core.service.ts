import { Injectable } from '@angular/core';
import { HelpersService } from './helpers.service';
import { EventableService } from './eventable.service';
import { UiService } from './ui.service';
import { ConstantService } from './constant.service';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class CoreService {

  constructor(private helperService: HelpersService, private eventableService: EventableService, private uiService: UiService,
    private constantService: ConstantService, private commonService: CommonService) { }

    dataTaskLayers = function (gantt) {

      delete gantt.addTaskLayer;
      delete gantt.addLinkLayer;

  };

  createLayoutFacadeJs = function () {

    function createLayoutFacade() {

      function getTimeline(gantt) {
        return gantt.$ui.getView("timeline");
      }

      function getGrid(gantt) {
        return gantt.$ui.getView("grid");
      }

      function getVerticalScrollbar(gantt) {
        return gantt.$ui.getView("scrollVer");
      }

      function getHorizontalScrollbar(gantt) {
        return gantt.$ui.getView("scrollHor");
      }

      var DEFAULT_VALUE = "DEFAULT_VALUE";

      function tryCall(getView, method, args, fallback) {
        var view = getView(this);
        if (!(view && view.isVisible())) {
          if (fallback) {
            return fallback();
          } else {
            return DEFAULT_VALUE;
          }
        } else {
          return view[method].apply(view, args);
        }
      }

      return {

        getColumnIndex: function (name) {
          var res = tryCall.call(this, getGrid, "getColumnIndex", [name]);
          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },

        dateFromPos: function (x) {
          var res = tryCall.call(this, getTimeline, "dateFromPos", Array.prototype.slice.call(arguments));
          if (res === DEFAULT_VALUE) {
            return this.getState().min_date;
          } else {
            return res;
          }
        },

        posFromDate: function (date) {
          var res = tryCall.call(this, getTimeline, "posFromDate", [date]);
          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },

        getRowTop: function (index) {
          var self = this;
          var res = tryCall.call(self, getTimeline, "getRowTop", [index],
            function () { return tryCall.call(self, getGrid, "getRowTop", [index]); }
          );

          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },

        getTaskTop: function (id) {
          var self = this;
          var res = tryCall.call(self, getTimeline, "getItemTop", [id],
            function () { return tryCall.call(self, getGrid, "getItemTop", [id]); }
          );

          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },


        getTaskPosition: function (task, start_date, end_date) {
          var res = tryCall.call(this, getTimeline, "getItemPosition", [task, start_date, end_date]);

          if (res === DEFAULT_VALUE) {
            var top = this.getTaskTop(task.id);
            var height = this.getTaskHeight();

            return {
              left: 0,
              top: top,
              height: height,
              width: 0
            };
          } else {
            return res;
          }
        },

        getTaskHeight: function () {
          var self = this;
          var res = tryCall.call(self, getTimeline, "getItemHeight", [],
            function () { return tryCall.call(self, getGrid, "getItemHeight", []); }
          );

          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },


        columnIndexByDate: function (date) {
          var res = tryCall.call(this, getTimeline, "columnIndexByDate", [date]);
          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },

        roundTaskDates: function () {
          tryCall.call(this, getTimeline, "roundTaskDates", []);
        },

        getScale: function () {
          var res = tryCall.call(this, getTimeline, "getScale", []);
          if (res === DEFAULT_VALUE) {
            return null;
          } else {
            return res;
          }
        },

        getTaskNode: function (id) {
          var timeline = getTimeline(this);
          if (!timeline || !timeline.isVisible()) {
            return null;
          } else {
            return timeline._taskRenderer.rendered[id];
          }
        },


        getLinkNode: function (id) {
          var timeline = getTimeline(this);
          if (!timeline.isVisible()) {
            return null;
          } else {
            return timeline._linkRenderer.rendered[id];
          }
        },

        scrollTo: function (left, top) {
          var vertical = getVerticalScrollbar(this);
          var horizontal = getHorizontalScrollbar(this);

          var oldH = { position: 0 },
            oldV = { position: 0 };

          if (vertical) {
            oldV = vertical.getScrollState();
          }
          if (horizontal) {
            oldH = horizontal.getScrollState();
          }

          if (horizontal && left * 1 == left) {
            horizontal.scroll(left);
          }
          if (vertical && top * 1 == top) {
            vertical.scroll(top);
          }

          var newV = { position: 0 },
            newH = { position: 0 };
          if (vertical) {
            newV = vertical.getScrollState();
          }
          if (horizontal) {
            newH = horizontal.getScrollState();
          }

          this.callEvent("onGanttScroll", [oldH.position, oldV.position, newH.position, newV.position]);
        },

        showDate: function (date) {
          var date_x = this.posFromDate(date);
          var scroll_to = Math.max(date_x - this.config.task_scroll_offset, 0);
          this.scrollTo(scroll_to);
        },
        showTask: function (id) {
          var pos = this.getTaskPosition(this.getTask(id));

          var left = Math.max(pos.left - this.config.task_scroll_offset, 0);

          var dataHeight = this._scroll_state().y;
          var top;
          if (!dataHeight) {
            top = pos.top;
          } else {
            top = pos.top - (dataHeight - this.config.row_height) / 2;
          }

          this.scrollTo(left, top);
        },
        _scroll_state: function () {
          var result = {
            x: false,
            y: false,
            x_pos: 0,
            y_pos: 0,
            scroll_size: this.config.scroll_size + 1,//1px for inner content
            x_inner: 0,
            y_inner: 0
          };

          var scrollVer = getVerticalScrollbar(this),
            scrollHor = getHorizontalScrollbar(this);
          if (scrollHor) {
            var horState = scrollHor.getScrollState();
            if (horState.visible) {
              result.x = horState.size;
              result.x_inner = horState.scrollSize;
            }
            result.x_pos = horState.position || 0;
          }

          if (scrollVer) {
            var verState = scrollVer.getScrollState();
            if (verState.visible) {
              result.y = verState.size;

              result.y_inner = verState.scrollSize;
            }
            result.y_pos = verState.position || 0;
          }

          return result;
        },
        getScrollState: function () {
          var state = this._scroll_state();
          return { x: state.x_pos, y: state.y_pos, inner_width: state.x, inner_height: state.y, width: state.x_inner, height: state.y_inner };
        }

      };

    }

    return createLayoutFacade;

    /***/
  };

  createTasksFacadeJs = function () {

    var utils = this.helperService.utils;

    var createTasksDatastoreFacade = function () {
      return {
        getTask: function (id) {
          this.assert(id, "Invalid argument for gantt.getTask");
          var task = this.$data.tasksStore.getItem(id);
          this.assert(task, "Task not found id=" + id);
          return task;
        },
        getTaskByTime: function (from, to) {
          var p = this.$data.tasksStore.getItems();

          var res = [];

          if (!(from || to)) {
            res = p;
          } else {
            from = +from || -Infinity;
            to = +to || Infinity;
            for (var t = 0; t < p.length; t++) {
              var task = p[t];
              if (+task.start_date < to && +task.end_date > from)
                res.push(task);
            }
          }
          return res;
        },
        isTaskExists: function (id) {
          if (!this.$data || !this.$data.tasksStore) {
            return false;
          }
          return this.$data.tasksStore.exists(id);
        },
        updateTask: function (id, item) {
          if (!utils.defined(item)) item = this.getTask(id);
          this.$data.tasksStore.updateItem(id, item);
          if (this.isTaskExists(id))
            this.refreshTask(id);
        },
        addTask: function (item, parent, index) {
          if (!utils.defined(item.id))
            item.id = utils.uid();

          if (!utils.defined(parent)) parent = this.getParent(item) || 0;
          if (!this.isTaskExists(parent)) parent = this.config.root_id;
          this.setParent(item, parent);

          return this.$data.tasksStore.addItem(item, index, parent);
        },
        deleteTask: function (id) {
          return this.$data.tasksStore.removeItem(id);
        },
        getTaskCount: function () {
          return this.$data.tasksStore.count();
        },
        getVisibleTaskCount: function () {
          return this.$data.tasksStore.countVisible();
        },
        getTaskIndex: function (id) {
          return this.$data.tasksStore.getBranchIndex(id);
        },
        getGlobalTaskIndex: function (id) {
          this.assert(id, "Invalid argument");
          return this.$data.tasksStore.getIndexById(id);
        },
        eachTask: function (code, parent, master) {
          return this.$data.tasksStore.eachItem(utils.bind(code, master || this), parent);
        },
        eachParent: function (callback, startTask, master) {
          return this.$data.tasksStore.eachParent(utils.bind(callback, master || this), startTask);
        },
        changeTaskId: function (oldid, newid) {
          this.$data.tasksStore.changeId(oldid, newid);
          var task = this.$data.tasksStore.getItem(newid);

          var links = [];

          if (task.$source) {
            links = links.concat(task.$source);
          }
          if (task.$target) {
            links = links.concat(task.$target);
          }

          for (var i = 0; i < links.length; i++) {
            var link = this.getLink(links[i]);
            if (link.source == oldid) {
              link.source = newid;
            }
            if (link.target == oldid) {
              link.target = newid;
            }
          }
        },
        calculateTaskLevel: function (item) {
          return this.$data.tasksStore.calculateItemLevel(item);
        },
        getNext: function (id) {
          return this.$data.tasksStore.getNext(id);
        },
        getPrev: function (id) {
          return this.$data.tasksStore.getPrev(id);
        },
        getParent: function (id) {
          return this.$data.tasksStore.getParent(id);
        },
        setParent: function (task, new_pid, silent) {
          return this.$data.tasksStore.setParent(task, new_pid, silent);
        },
        getSiblings: function (id) {
          return this.$data.tasksStore.getSiblings(id).slice();
        },
        getNextSibling: function (id) {
          return this.$data.tasksStore.getNextSibling(id);
        },
        getPrevSibling: function (id) {
          return this.$data.tasksStore.getPrevSibling(id);
        },
        getTaskByIndex: function (index) {
          var id = this.$data.tasksStore.getIdByIndex(index);
          if (this.isTaskExists(id)) {
            return this.getTask(id);
          } else {
            return null;
          }
        },
        getChildren: function (id) {
          if (!this.hasChild(id)) {
            return [];
          } else {
            return this.$data.tasksStore.getChildren(id).slice();
          }
        },
        hasChild: function (id) {
          return this.$data.tasksStore.hasChild(id);
        },
        open: function (id) {
          this.$data.tasksStore.open(id);
        },
        close: function (id) {
          this.$data.tasksStore.close(id);
        },
        moveTask: function (sid, tindex, parent) {
          return this.$data.tasksStore.move.apply(this.$data.tasksStore, arguments);
        },
        sort: function (field, desc, parent, silent) {
          var render = !silent;//4th argument to cancel redraw after sorting

          this.$data.tasksStore.sort(field, desc, parent);
          this.callEvent("onAfterSort", [field, desc, parent]);

          if (render) {
            this.render();
          }
        }
      };
    };

    return createTasksDatastoreFacade;
  };

  createLinksFacadeJs = function () {

    var utils = this.helperService.utils;


    var createLinksStoreFacade = function () {
      return {
        getLinkCount: function () {
          return this.$data.linksStore.count();
        },

        getLink: function (id) {
          return this.$data.linksStore.getItem(id);
        },

        getLinks: function () {
          return this.$data.linksStore.getItems();
        },

        isLinkExists: function (id) {
          return this.$data.linksStore.exists(id);
        },

        addLink: function (link) {
          return this.$data.linksStore.addItem(link);
        },

        updateLink: function (id, data) {
          if (!utils.defined(data))
            data = this.getLink(id);
          this.$data.linksStore.updateItem(id, data);
        },

        deleteLink: function (id) {
          return this.$data.linksStore.removeItem(id);
        },

        changeLinkId: function (oldid, newid) {
          return this.$data.linksStore.changeId(oldid, newid);
        }
      };
    };

    return createLinksStoreFacade;

    /***/
  };

  powerArrayJs = function () {

    var utils = this.helperService.utils;

    var $powerArray = {
      $create(array?) {
        return utils.mixin(array || [], this);
      },
      //remove element at specified position
      $removeAt(pos, len) {
        if (pos >= 0) this.splice(pos, (len || 1));
      },
      //find element in collection and remove it
      $remove: function (value) {
        this.$removeAt(this.$find(value));
      },
      //add element to collection at specific position
      $insertAt: function (data, pos) {
        if (!pos && pos !== 0) 	//add to the end by default
          this.push(data);
        else {
          var b = this.splice(pos, (this.length - pos));
          this[pos] = data;
          this.push.apply(this, b); //reconstruct array without loosing this pointer
        }
      },
      //return index of element, -1 if it doesn't exists
      $find: function (data) {
        for (var i = 0; i < this.length; i++)
          if (data == this[i]) return i;
        return -1;
      },
      //execute some method for each element of array
      $each: function (functor, master) {
        for (var i = 0; i < this.length; i++)
          functor.call((master || this), this[i]);
      },
      //create new array from source, by using results of functor
      $map: function (functor, master) {
        for (var i = 0; i < this.length; i++)
          this[i] = functor.call((master || this), this[i]);
        return this;
      },
      $filter: function (functor, master) {
        for (var i = 0; i < this.length; i++)
          if (!functor.call((master || this), this[i])) {
            this.splice(i, 1);
            i--;
          }
        return this;
      }
    };

    return $powerArray;

    /***/
  }

  dataStoreJs = function () {

    var powerArray = this.powerArrayJs;
    var utils = this.helperService.utils;
    var eventable = this.eventableService;

    var DataStore = function (config) {
      this.pull = {};
      this.$initItem = config.initItem;
      this.visibleOrder = powerArray.$create();
      this.fullOrder = powerArray.$create();
      this._skip_refresh = false;
      this._filterRule = null;
      this._searchVisibleOrder = {};
      this.$config = config;
      eventable(this);
      return this;
    };
    DataStore.prototype = {

      _parseInner: function (data) {
        var item = null,
          loaded = [];
        for (var i = 0, len = data.length; i < len; i++) {
          item = data[i];
          if (this.$initItem) {
            item = this.$initItem(item);
          }
          if (this.callEvent("onItemLoading", [item])) {
            if (!this.pull.hasOwnProperty(item.id)) {
              this.fullOrder.push(item.id);
              loaded.push(item);
            }
            this.pull[item.id] = item;
          }
        }
        return loaded;
      },
      parse: function (data) {
        this.callEvent("onBeforeParse", [data]);
        var loaded = this._parseInner(data);
        this.refresh();
        this.callEvent("onParse", [loaded]);
      },
      getItem: function (id) {
        return this.pull[id];
      },

      _updateOrder: function (code) {
        code.call(this.visibleOrder);
        code.call(this.fullOrder);
      },
      updateItem: function (id, item) {
        if (!utils.defined(item)) item = this.getItem(id);

        if (!this._skip_refresh) {
          if (this.callEvent("onBeforeUpdate", [item.id, item]) === false) return false;
        }
        this.pull[id] = item;
        if (!this._skip_refresh) {
          this.callEvent("onAfterUpdate", [item.id, item]);
          this.callEvent("onStoreUpdated", [item.id, item, "update"]);
        }
      },

      _removeItemInner: function (id) {
        //clear from collections
        //this.visibleOrder.$remove(id);
        this._updateOrder(function () { this.$remove(id); });
        delete this.pull[id];
      },

      removeItem: function (id) {
        //utils.assert(this.exists(id), "Not existing ID in remove command"+id);

        var obj = this.getItem(id);	//save for later event
        if (!this._skip_refresh) {
          if (this.callEvent("onBeforeDelete", [obj.id, obj]) === false) return false;
        }

        this._removeItemInner(id);

        if (!this._skip_refresh) {
          this.filter();
          this.callEvent("onAfterDelete", [obj.id, obj]);
          //repaint signal
          this.callEvent("onStoreUpdated", [obj.id, obj, "delete"]);
        }
      },

      _addItemInner: function (item, index) {
        //in case of treetable order is sent as 3rd parameter
        //var order = index;

        if (this.exists(item.id)) {
          this.silent(function () { this.updateItem(item.id, item); });
        } else {
          var order = this.visibleOrder;

          //by default item is added to the end of the list
          var data_size = order.length;

          if (!utils.defined(index) || index < 0)
            index = data_size;
          //check to prevent too big indexes
          if (index > data_size) {
            //dhx.log("Warning","DataStore:add","Index of out of bounds");
            index = Math.min(order.length, index);
          }
        }


        //gantt.assert(!this.exists(id), "Not unique ID");

        this.pull[item.id] = item;
        if (!this._skip_refresh) {
          this._updateOrder(function () {
            if (this.$find(item.id) === -1)
              this.$insertAt(item.id, index);
          });
        }
        this.filter();
        //order.$insertAt(item.id,index);
      },


      isVisible: function (id) {
        return this.visibleOrder.$find(id) > -1;
      },
      getVisibleItems: function () {
        return this.getIndexRange();
      },

      addItem: function (item, index) {
        if (!utils.defined(item.id))
          item.id = utils.uid();

        if (this.$initItem) {
          item = this.$initItem(item);
        }

        if (!this._skip_refresh) {
          if (this.callEvent("onBeforeAdd", [item.id, item]) === false) return false;
        }


        this._addItemInner(item, index);

        if (!this._skip_refresh) {
          this.callEvent("onAfterAdd", [item.id, item]);
          //repaint signal
          this.callEvent("onStoreUpdated", [item.id, item, "add"]);
        }
        return item.id;
      },

      _changeIdInner: function (oldId, newId) {
        if (this.pull[oldId])
          this.pull[newId] = this.pull[oldId];

        var visibleOrder = this._searchVisibleOrder[oldId];
        this.pull[newId].id = newId;
        this._updateOrder(function () {
          this[this.$find(oldId)] = newId;
        });
        this._searchVisibleOrder[newId] = visibleOrder;
        delete this._searchVisibleOrder[oldId];

        //this.visibleOrder[this.visibleOrder.$find(oldId)]=newId;
        delete this.pull[oldId];
      },
      changeId: function (oldId, newId) {
        this._changeIdInner(oldId, newId);

        this.callEvent("onIdChange", [oldId, newId]);

      },
      exists: function (id) {
        return !!(this.pull[id]);
      },

      _moveInner: function (sindex, tindex) {
        var id = this.getIdByIndex(sindex);

        this._updateOrder(function () {
          this.$removeAt(sindex);
          this.$insertAt(id, Math.min(this.length, tindex));
        });
        //this.visibleOrder.$removeAt(sindex);	//remove at old position
        //if (sindex<tindex) tindex--;	//correct shift, caused by element removing
        //this.visibleOrder.$insertAt(id,Math.min(this.visibleOrder.length, tindex));	//insert at new position
      },

      move: function (sindex, tindex) {
        //gantt.assert(sindex>=0 && tindex>=0, "DataStore::move","Incorrect indexes");

        var id = this.getIdByIndex(sindex);
        var obj = this.getItem(id);
        this._moveInner(sindex, tindex);


        if (!this._skip_refresh) {
          //repaint signal
          this.callEvent("onStoreUpdated", [obj.id, obj, "move"]);
        }
      },
      clearAll: function () {
        this.pull = {};
        this.visibleOrder = powerArray.$create();
        this.fullOrder = powerArray.$create();
        if (this._skip_refresh) return;
        this.callEvent("onClearAll", []);
        this.refresh();
      },

      silent: function (code, master) {
        this._skip_refresh = true;
        code.call(master || this);
        this._skip_refresh = false;
      },

      arraysEqual: function (arr1, arr2) {
        if (arr1.length !== arr2.length)
          return false;
        for (var i = 0; i < arr1.length; i++) {
          if (arr1[i] !== arr2[i])
            return false;
        }

        return true;
      },

      refresh: function (id, quick) {
        if (this._skip_refresh) return;

        var args;
        if (id) {
          args = [id, this.pull[id], "paint"];
        } else {
          args = [null, null, null];
        }

        if (this.callEvent("onBeforeStoreUpdate", args) === false) {
          return;
        }

        if (id) {
          // if item changes visible order (e.g. expand-collapse branch) - do a complete repaint
          if (!quick) {
            var oldOrder = this.visibleOrder;
            this.filter();
            if (!this.arraysEqual(oldOrder, this.visibleOrder)) {
              id = undefined;
            }
          }

        } else {
          this.filter();
        }

        if (id) {
          args = [id, this.pull[id], "paint"];
        } else {
          args = [null, null, null];
        }

        this.callEvent("onStoreUpdated", args);
      },

      count: function () {
        return this.fullOrder.length;
      },
      countVisible: function () {
        return this.visibleOrder.length;
      },

      sort: function (sort) { },

      serialize: function () { },

      eachItem: function (code) {
        for (var i = 0; i < this.fullOrder.length; i++) {
          var item = this.pull[this.fullOrder[i]];
          code.call(this, item);
        }
      },

      filter: function (rule) {
        this.callEvent("onBeforeFilter", []);
        var filteredOrder = powerArray.$create();
        this.eachItem(function (item) {
          if (this.callEvent("onFilterItem", [item.id, item])) {
            filteredOrder.push(item.id);
          }
        });

        this.visibleOrder = filteredOrder;
        this._searchVisibleOrder = {};
        for (var i = 0; i < this.visibleOrder.length; i++) {
          this._searchVisibleOrder[this.visibleOrder[i]] = i;
        }
        this.callEvent("onFilter", []);
      },

      getIndexRange: function (from, to) {
        to = Math.min((to || Infinity), this.countVisible() - 1);

        var ret = [];
        for (var i = (from || 0); i <= to; i++)
          ret.push(this.getItem(this.visibleOrder[i]));
        return ret;
      },
      getItems: function () {
        var res = [];
        for (var i in this.pull) {
          res.push(this.pull[i]);
        }
        /*	for(var i = 0; i < this.fullOrder.length; i++){
      
          }*/
        return res;
      },

      getIdByIndex: function (index) {
        return this.visibleOrder[index];
      },
      getIndexById: function (id) {
        var res = this._searchVisibleOrder[id];
        if (res === undefined) {
          res = -1;
        }
        return res;
      },
      _getNullIfUndefined: function (value) {
        if (value === undefined) {
          return null;
        } else {
          return value;
        }
      },
      getFirst: function () {
        return this._getNullIfUndefined(this.visibleOrder[0]);
      },
      getLast: function () {
        return this._getNullIfUndefined(this.visibleOrder[this.visibleOrder.length - 1]);
      },
      getNext: function (id) {
        return this._getNullIfUndefined(this.visibleOrder[this.getIndexById(id) + 1]);
      },
      getPrev: function (id) {
        return this._getNullIfUndefined(this.visibleOrder[this.getIndexById(id) - 1]);
      },
      destructor: function () {
        this.detachAllEvents();
        this.pull = null;
        this.$initItem = null;
        this.visibleOrder = null;
        this.fullOrder = null;
        this._skip_refresh = null;
        this._filterRule = null;
        this._searchVisibleOrder = null;
      }
    };

    return DataStore;

    /***/
  }

  treeDataStoreJs = function () {

    var powerArray = this.powerArrayJs;
    var utils = this.helperService.utils;
    var DataStore = this.dataStoreJs;

    var TreeDataStore = function (config) {
      DataStore.apply(this, [config]);
      this._branches = {};

      this.pull = {};
      this.$initItem = config.initItem;
      this.$parentProperty = config.parentProperty || "parent";

      if (typeof config.rootId !== "function") {
        this.$getRootId = (function (val) {
          return function () { return val; };
        })(config.rootId || 0);
      } else {
        this.$getRootId = config.rootId;
      }

      // TODO: replace with live reference to gantt config
      this.$openInitially = config.openInitially;

      this.visibleOrder = powerArray.$create()
      this.fullOrder = powerArray.$create();
      this._searchVisibleOrder = {};
      this._skip_refresh = false;

      this._ganttConfig = null;
      if (config.getConfig) {
        this._ganttConfig = config.getConfig();
      }

      this.attachEvent("onFilterItem", function (id, item) {

        var canOpenSplitTasks: any = false;
        if (this._ganttConfig) {
          var canOpenSplitTasks = this._ganttConfig.open_split_tasks;
        }

        var open = true;
        this.eachParent(function (parent) {
          open = open && parent.$open && (canOpenSplitTasks || !this._isSplitItem(parent));
        }, item);
        return !!open;
      });

      return this;
    };

    TreeDataStore.prototype = utils.mixin({

      _buildTree: function (data) {
        var item = null;
        var rootId = this.$getRootId();
        for (var i = 0, len = data.length; i < len; i++) {
          item = data[i];
          this.setParent(item, this.getParent(item) || rootId);
        }

        // calculating $level for each item
        for (var i = 0, len = data.length; i < len; i++) {
          item = data[i];
          this._add_branch(item);
          item.$level = this.calculateItemLevel(item);

          if (!utils.defined(item.$open)) {
            item.$open = utils.defined(item.open) ? item.open : this.$openInitially();
          }

        }
        this._updateOrder();
      },
      _isSplitItem: function (item) {
        return (item.render == "split" && this.hasChild(item.id));
      },
      parse: function (data) {
        this.callEvent("onBeforeParse", [data]);
        var loaded = this._parseInner(data);
        this._buildTree(loaded);
        this.filter();
        this.callEvent("onParse", [loaded]);
      },

      _addItemInner: function (item, index) {

        var parent = this.getParent(item);

        if (!utils.defined(parent)) {
          parent = this.$getRootId();
          this.setParent(item, parent);
        }

        var parentIndex = this.getIndexById(parent);
        var targetIndex = parentIndex + Math.min(Math.max(index, 0), this.visibleOrder.length);

        if (targetIndex * 1 !== targetIndex) {
          targetIndex = undefined;
        }
        DataStore.prototype._addItemInner.call(this, item, targetIndex);
        this.setParent(item, parent);

        if (item.hasOwnProperty("$rendered_parent")) {
          this._move_branch(item, item.$rendered_parent);
        }
        this._add_branch(item, index);
      },
      _changeIdInner: function (oldId, newId) {
        var children = this.getChildren(oldId);
        var visibleOrder = this._searchVisibleOrder[oldId];

        DataStore.prototype._changeIdInner.call(this, oldId, newId);

        var parent = this.getParent(newId);

        this._replace_branch_child(parent, oldId, newId);
        for (var i = 0; i < children.length; i++) {
          this.setParent(this.getItem(children[i]), newId);
        }

        this._searchVisibleOrder[newId] = visibleOrder;
        delete this._branches[oldId];
      },

      _traverseBranches: function (code, parent) {
        parent = parent || this.$getRootId();
        var branch = this._branches[parent];
        if (branch) {
          for (var i = 0; i < branch.length; i++) {
            var itemId = branch[i];
            code.call(this, itemId);
            if (this._branches[itemId])
              this._traverseBranches(code, itemId);
          }
        }
      },

      _updateOrder: function (code) {

        this.fullOrder = powerArray.$create();
        this._traverseBranches(function (taskId) {
          this.fullOrder.push(taskId);
        });

        if (code)
          DataStore.prototype._updateOrder.call(this, code);
      },

      _removeItemInner: function (id) {

        var items = [];
        this.eachItem(function (child) {
          items.push(child);
        }, id);

        items.push(this.getItem(id));

        for (var i = 0; i < items.length; i++) {

          this._move_branch(items[i], this.getParent(items[i]), null);
          DataStore.prototype._removeItemInner.call(this, items[i].id);
          this._move_branch(items[i], this.getParent(items[i]), null);
        }
      },

      move: function (sid, tindex, parent) {
        //target id as 4th parameter
        var id = arguments[3];
        if (id) {
          if (id === sid) return;

          parent = this.getParent(id);
          tindex = this.getBranchIndex(id);
        }
        if (sid == parent) {
          return;
        }
        parent = parent || this.$getRootId();
        var source = this.getItem(sid);
        var source_pid = this.getParent(source.id);

        var tbranch = this.getChildren(parent);

        if (tindex == -1)
          tindex = tbranch.length + 1;
        if (source_pid == parent) {
          var sindex = this.getBranchIndex(sid);
          if (sindex == tindex) return;
        }

        if (this.callEvent("onBeforeItemMove", [sid, parent, tindex]) === false)
          return false;

        this._replace_branch_child(source_pid, sid);
        tbranch = this.getChildren(parent);

        var tid = tbranch[tindex];
        if (!tid) //adding as last element
          tbranch.push(sid);
        else
          tbranch = tbranch.slice(0, tindex).concat([sid]).concat(tbranch.slice(tindex));

        this.setParent(source, parent);
        this._branches[parent] = tbranch;

        var diff = this.calculateItemLevel(source) - source.$level;
        source.$level += diff;
        this.eachItem(function (item) {
          item.$level += diff;
        }, source.id, this);


        this._moveInner(this.getIndexById(sid), this.getIndexById(parent) + tindex);

        this.callEvent("onAfterItemMove", [sid, parent, tindex]);
        this.refresh();
      },

      getBranchIndex: function (id) {
        var branch = this.getChildren(this.getParent(id));
        for (var i = 0; i < branch.length; i++)
          if (branch[i] == id)
            return i;

        return -1;
      },
      hasChild: function (id) {
        return (utils.defined(this._branches[id]) && this._branches[id].length);
      },
      getChildren: function (id) {
        return utils.defined(this._branches[id]) ? this._branches[id] : powerArray.$create();
      },

      isChildOf: function (childId, parentId) {
        if (!this.exists(childId))
          return false;
        if (parentId === this.$getRootId())
          return true;

        if (!this.hasChild(parentId))
          return false;

        var item = this.getItem(childId);
        var pid = this.getParent(childId);

        var parent = this.getItem(parentId);
        if (parent.$level >= item.$level) {
          return false;
        }

        while (item && this.exists(pid)) {
          item = this.getItem(pid);

          if (item && item.id == parentId)
            return true;
          pid = this.getParent(item);
        }
        return false;
      },

      getSiblings: function (id) {
        if (!this.exists(id)) {
          return powerArray.$create();
        }
        var parent = this.getParent(id);
        return this.getChildren(parent);

      },
      getNextSibling: function (id) {
        var siblings = this.getSiblings(id);
        for (var i = 0, len = siblings.length; i < len; i++) {
          if (siblings[i] == id)
            return siblings[i + 1] || null;
        }
        return null;
      },
      getPrevSibling: function (id) {
        var siblings = this.getSiblings(id);
        for (var i = 0, len = siblings.length; i < len; i++) {
          if (siblings[i] == id)
            return siblings[i - 1] || null;
        }
        return null;
      },
      getParent: function (id) {
        var item = null;
        if (id.id !== undefined) {
          item = id;
        } else {
          item = this.getItem(id);
        }

        var parent;
        if (item) {
          parent = item[this.$parentProperty];
        } else {
          parent = this.$getRootId();
        }
        return parent;

      },

      clearAll: function () {
        this._branches = {};
        DataStore.prototype.clearAll.call(this);
      },

      calculateItemLevel: function (item) {
        var level = 0;
        this.eachParent(function () {
          level++;
        }, item);
        return level;
      },

      _setParentInner: function (item, new_pid, silent) {
        if (!silent) {
          if (item.hasOwnProperty("$rendered_parent")) {
            this._move_branch(item, item.$rendered_parent, new_pid);
          } else {
            this._move_branch(item, item[this.$parentProperty], new_pid);
          }
        }
      },
      setParent: function (item, new_pid, silent) {
        this._setParentInner(item, new_pid, silent);

        item[this.$parentProperty] = new_pid;
      },
      eachItem: function (code, parent) {
        parent = parent || this.$getRootId();


        var branch = this.getChildren(parent);
        if (branch)
          for (var i = 0; i < branch.length; i++) {
            var item = this.pull[branch[i]];
            code.call(this, item);
            if (this.hasChild(item.id))
              this.eachItem(code, item.id);
          }
      },
      eachParent: function (code, startItem) {
        var parentsHash = {};
        var item = startItem;
        var parent = this.getParent(item);

        while (this.exists(parent)) {
          if (parentsHash[parent]) {
            throw new Error("Invalid tasks tree. Cyclic reference has been detected on task " + parent);
          }
          parentsHash[parent] = true;
          item = this.getItem(parent);
          code.call(this, item);
          parent = this.getParent(item);
        }
      },
      _add_branch: function (item, index, parent) {
        var pid = parent === undefined ? this.getParent(item) : parent;
        if (!this.hasChild(pid))
          this._branches[pid] = powerArray.$create();
        var branch = this.getChildren(pid);
        var added_already = false;
        for (var i = 0, length = branch.length; i < length; i++) {
          if (branch[i] == item.id) {
            added_already = true;
            break;
          }
        }
        if (!added_already) {
          if (index * 1 == index) {

            branch.splice(index, 0, item.id);
          } else {
            branch.push(item.id);
          }

          item.$rendered_parent = pid;
        }
      },
      _move_branch: function (item, old_parent, new_parent) {
        //this.setParent(item, new_parent);
        //this._sync_parent(task);
        this._replace_branch_child(old_parent, item.id);
        if (this.exists(new_parent) || new_parent == this.$getRootId()) {

          this._add_branch(item, undefined, new_parent);
        } else {
          delete this._branches[item.id];
        }
        item.$level = this.calculateItemLevel(item);
        this.eachItem(function (child) {
          child.$level = this.calculateItemLevel(child);
        }, item.id);
      },

      _replace_branch_child: function (node, old_id, new_id) {
        var branch = this.getChildren(node);
        if (branch && node !== undefined) {
          var newbranch = powerArray.$create();
          for (var i = 0; i < branch.length; i++) {
            if (branch[i] != old_id)
              newbranch.push(branch[i]);
            else if (new_id)
              newbranch.push(new_id);
          }
          this._branches[node] = newbranch;
        }

      },

      sort: function (field, desc, parent) {
        if (!this.exists(parent)) {
          parent = this.$getRootId();
        }

        if (!field) field = "order";
        var criteria = (typeof (field) == "string") ? (function (a, b) {
          if (a[field] == b[field]) {
            return 0;
          }

          var result = a[field] > b[field];
          return result ? 1 : -1;
        }) : field;

        if (desc) {
          var original_criteria = criteria;
          criteria = function (a, b) {
            return original_criteria(b, a);
          };
        }

        var els = this.getChildren(parent);

        if (els) {
          var temp = [];
          for (var i = els.length - 1; i >= 0; i--)
            temp[i] = this.getItem(els[i]);

          temp.sort(criteria);

          for (var i = 0; i < temp.length; i++) {
            els[i] = temp[i].id;
            this.sort(field, desc, els[i]);
          }
        }
      },

      filter: function (rule) {
        for (var i in this.pull) {
          if (this.pull[i].$rendered_parent !== this.getParent(this.pull[i])) {
            this._move_branch(this.pull[i], this.pull[i].$rendered_parent, this.getParent(this.pull[i]));
          }
        }
        return DataStore.prototype.filter.apply(this, arguments);
      },

      open: function (id) {
        if (this.exists(id)) {
          this.getItem(id).$open = true;
          this.callEvent("onItemOpen", [id]);
        }
      },

      close: function (id) {
        if (this.exists(id)) {
          this.getItem(id).$open = false;
          this.callEvent("onItemClose", [id]);
        }
      },

      destructor: function () {
        DataStore.prototype.destructor.call(this);
        this._branches = null;
      }
    },
      DataStore.prototype
    );

    return TreeDataStore;

    /***/
  }

  createDataStoreSelectJs = function () {

    function createDataStoreSelectMixin(store) {
      var selectedId = null;

      var deleteItem = store._removeItemInner;

      function unselect(id) {
        selectedId = null;
        this.callEvent("onAfterUnselect", [id]);
      }

      store._removeItemInner = function (id) {
        if (selectedId == id) {
          unselect.call(this, id);
        }

        if (selectedId && this.eachItem) {
          this.eachItem(function (subItem) {
            if (subItem.id == selectedId) {
              unselect.call(this, subItem.id);
            }
          }, id);
        }

        return deleteItem.apply(this, arguments);
      };

      store.attachEvent("onIdChange", function (oldId, newId) {
        if (store.getSelectedId() == oldId) {
          store.silent(function () {
            store.unselect(oldId);
            store.select(newId);
          });
        }
      });

      return {
        select: function (id) {
          if (id) {

            if (selectedId == id)
              return selectedId;

            if (!this._skip_refresh) {
              if (!this.callEvent("onBeforeSelect", [id])) {
                return false;
              }
            }

            this.unselect();

            selectedId = id;

            if (!this._skip_refresh) {
              this.refresh(id);
              this.callEvent("onAfterSelect", [id]);
            }
          }
          return selectedId;
        },
        getSelectedId: function () {
          return selectedId;
        },
        isSelected: function (id) {
          return id == selectedId;
        },
        unselect: function (id) {
          var id = id || selectedId;
          if (!id)
            return;
          selectedId = null;
          if (!this._skip_refresh) {
            this.refresh(id);
            unselect.call(this, id);
          }
        }
      };
    }

    return createDataStoreSelectMixin;
  }

  datastoreRenderJs = function () {

    var storeRenderCreator = function (name, gantt) {
      var store = gantt.getDatastore(name);

      var itemRepainter = {
        renderItem: function (id, renderer) {

          var renders = renderer.getLayers();

          var item = store.getItem(id);
          if (item && store.isVisible(id)) {
            for (var i = 0; i < renders.length; i++)
              renders[i].render_item(item);
          }
        },
        renderItems: function (renderer) {
          var renderers = renderer.getLayers();
          for (var i = 0; i < renderers.length; i++) {
            renderers[i].clear();
          }

          var data = store.getVisibleItems();

          for (var i = 0; i < renderers.length; i++) {
            renderers[i].render_items(data);
          }
        },
        updateItems: function (layer) {
          if (layer.update_items) {
            var data = store.getVisibleItems();
            layer.update_items(data);
          }
        }
      };

      store.attachEvent("onStoreUpdated", function (id, item, action) {
        var renderer = gantt.$services.getService("layers").getDataRender(name);
        if (renderer) {
          renderer.onUpdateRequest = function (layer) {
            itemRepainter.updateItems(layer);
          };
        }
      });

      function skipRepaint(gantt) {
        var state = gantt.$services.getService("state");
        if (state.getState("batchUpdate").batch_update) {
          return true;
        } else {
          return false;
        }
      }

      store.attachEvent("onStoreUpdated", function (id, item, action) {
        if (skipRepaint(gantt)) {
          return;
        }

        var renderer = gantt.$services.getService("layers").getDataRender(name);

        if (renderer) {
          if (!id || action == "move" || action == "delete") {
            store.callEvent("onBeforeRefreshAll", []);
            itemRepainter.renderItems(renderer);
            store.callEvent("onAfterRefreshAll", []);
          } else {
            store.callEvent("onBeforeRefreshItem", [item.id]);
            itemRepainter.renderItem(item.id, renderer);
            store.callEvent("onAfterRefreshItem", [item.id]);
          }
        }

      });

      // TODO: probably can be done more in a more efficient way
      store.attachEvent("onItemOpen", function () {
        gantt.render();
      });

      store.attachEvent("onItemClose", function () {
        gantt.render();
      });

      function refreshId(renders, oldId, newId, item) {
        for (var i = 0; i < renders.length; i++) {
          renders[i].change_id(oldId, newId);
        }
      }

      store.attachEvent("onIdChange", function (oldId, newId) {

        // in case of linked datastores (tasks <-> links), id change should recalculate something in linked datastore before any repaint
        // use onBeforeIdChange for this hook.
        // TODO: use something more reasonable instead
        store.callEvent("onBeforeIdChange", [oldId, newId]);

        if (skipRepaint(gantt)) {
          return;
        }
        var renderer = gantt.$services.getService("layers").getDataRender(name);
        refreshId(renderer.getLayers(), oldId, newId, store.getItem(newId));
        itemRepainter.renderItem(newId, renderer);
      });

    };

    return {
      bindDataStore: storeRenderCreator
    };

  }

  facadeFactoryJs = function () {

    var utils = this.helperService.utils;
    var createTasksFacade = this.createTasksFacadeJs,
      createLinksFacade = this.createLinksFacadeJs,
      DataStore = this.dataStoreJs,
      TreeDataStore = this.treeDataStoreJs,
      createDatastoreSelect = this.createDataStoreSelectJs;
    var datastoreRender = this.datastoreRenderJs;

    function getDatastores() {
      var storeNames = this.$services.getService("datastores");
      var res = [];
      for (var i = 0; i < storeNames.length; i++) {
        res.push(this.getDatastore(storeNames[i]));
      }
      return res;
    }

    var createDatastoreFacade = function () {
      return {
        createDatastore: function (config) {

          var $StoreType = (config.type || "").toLowerCase() == "treedatastore" ? TreeDataStore : DataStore;

          if (config) {
            var self = this;
            config.openInitially = function () { return self.config.open_tree_initially; };
          }

          var store = new $StoreType(config);
          this.mixin(store, createDatastoreSelect(store));

          if (config.name) {
            var servicePrefix = "datastore:";

            this.$services.dropService(servicePrefix + config.name);
            this.$services.setService(servicePrefix + config.name, function () { return store; });

            var storeList = this.$services.getService("datastores");
            if (!storeList) {
              storeList = [];
              this.$services.setService("datastores", function () { return storeList; });
              storeList.push(config.name);
            } else if (storeList.indexOf(config.name) < 0) {
              storeList.push(config.name);
            }

            datastoreRender.bindDataStore(config.name, this);
          }

          return store;
        },
        getDatastore: function (name) {
          return this.$services.getService("datastore:" + name);
        },

        refreshData: function () {
          var scrollState = this.getScrollState();
          this.callEvent("onBeforeDataRender", []);

          var stores = getDatastores.call(this);
          for (var i = 0; i < stores.length; i++) {
            stores[i].refresh();
          }

          if (scrollState.x || scrollState.y) {
            this.scrollTo(scrollState.x, scrollState.y);
          }
          this.callEvent("onDataRender", []);
        },

        isChildOf: function (childId, parentId) {
          return this.$data.tasksStore.isChildOf(childId, parentId);
        },

        refreshTask: function (taskId, refresh_links) {
          var task = this.getTask(taskId);
          if (task && this.isTaskVisible(taskId)) {

            this.$data.tasksStore.refresh(taskId, !!this.getState().drag_id);// do quick refresh during drag and drop

            if (refresh_links !== undefined && !refresh_links)
              return;
            for (var i = 0; i < task.$source.length; i++) {
              this.refreshLink(task.$source[i]);
            }
            for (var i = 0; i < task.$target.length; i++) {
              this.refreshLink(task.$target[i]);
            }
          } else if (this.isTaskExists(taskId) && this.isTaskExists(this.getParent(taskId))) {
            this.refreshTask(this.getParent(taskId));
          }

        },
        refreshLink: function (linkId) {
          this.$data.linksStore.refresh(linkId, !!this.getState().drag_id);// do quick refresh during drag and drop
        },

        silent: function (code) {
          var gantt = this;
          gantt.$data.tasksStore.silent(function () {
            gantt.$data.linksStore.silent(function () {
              code();
            });
          });
        },

        clearAll: function () {
          var stores = getDatastores.call(this);
          for (var i = 0; i < stores.length; i++) {
            stores[i].clearAll();
          }

          this._update_flags();
          this.userdata = {};
          this.callEvent("onClear", []);
          this.render();
        },
        _clear_data: function () {
          this.$data.tasksStore.clearAll();
          this.$data.linksStore.clearAll();
          this._update_flags();
          this.userdata = {};
        },

        selectTask: function (id) {
          var store = this.$data.tasksStore;
          if (!this.config.select_task)
            return false;
          if (id) {

            store.select(id);
          }
          return store.getSelectedId();
        },
        unselectTask: function (id) {
          var store = this.$data.tasksStore;
          store.unselect(id);
        },
        isSelectedTask: function (id) {
          return this.$data.tasksStore.isSelected(id);
        },
        getSelectedId: function () {
          return this.$data.tasksStore.getSelectedId();
        }
      };
    };

    function createFacade() {
      var res = utils.mixin({}, createDatastoreFacade());
      utils.mixin(res, createTasksFacade());
      utils.mixin(res, createLinksFacade());
      return res;
    }

    return { create: createFacade };
  }

  calculateScaleRangeJs = function () {

    var ScaleHelper = this.uiService.ScaleHelperJs;
    var PrimaryScaleHelper = this.uiService.ScaleHelperJs;


    function dateRangeResolver(gantt) {
      //reset project timing
      //_get_tasks_data(gantt);
      return gantt.getSubtaskDates();
    }

    function defaultRangeResolver(gantt) {
      return {
        start_date: new Date(),
        end_date: new Date()
      };
    }

    function resolveConfigRange(unit, gantt) {
      var range = {
        start_date: null,
        end_date: null
      };

      if (gantt.config.start_date && gantt.config.end_date) {
        range.start_date = gantt.date[unit + "_start"](new Date(gantt.config.start_date));

        var end = new Date(gantt.config.end_date);
        var start_interval = gantt.date[unit + "_start"](new Date(end));
        if (+end != +start_interval) {
          end = gantt.date.add(start_interval, 1, unit);
        } else {
          end = start_interval;
        }

        range.end_date = end;
      }
      return range;
    }

    function _scale_range_unit(gantt) {
      var primaryScale = (new PrimaryScaleHelper(gantt)).primaryScale();
      var unit = primaryScale.unit;
      var step = primaryScale.step;
      if (gantt.config.scale_offset_minimal) {

        var helper = new ScaleHelper(gantt);
        var scales = [helper.primaryScale()].concat(helper.getSubScales());

        helper.sortScales(scales);
        unit = scales[scales.length - 1].unit;
        step = scales[scales.length - 1].step || 1;
      }
      return { unit: unit, step: step };
    }

    function _init_tasks_range(gantt) {
      var cfg = _scale_range_unit(gantt);
      var unit = cfg.unit,
        step = cfg.step;
      var range = resolveConfigRange(unit, gantt);

      if (!(range.start_date && range.end_date)) {
        range = dateRangeResolver(gantt);
        if (!range.start_date || !range.end_date) {
          range = defaultRangeResolver(gantt);
        }

        range.start_date = gantt.date[unit + "_start"](range.start_date);
        range.start_date = gantt.calculateEndDate({
          start_date: gantt.date[unit + "_start"](range.start_date),
          duration: -1,
          unit: unit,
          step: step
        });//one free column before first task

        range.end_date = gantt.date[unit + "_start"](range.end_date);
        range.end_date = gantt.calculateEndDate({ start_date: range.end_date, duration: 2, unit: unit, step: step });//one free column after last task
      }

      gantt._min_date = range.start_date;
      gantt._max_date = range.end_date;
    }

    function _adjust_scales(gantt) {
      if (gantt.config.fit_tasks) {
        var old_min = +gantt._min_date,
          old_max = +gantt._max_date;
        //this._init_tasks_range();
        if (+gantt._min_date != old_min || +gantt._max_date != old_max) {
          gantt.render();

          gantt.callEvent("onScaleAdjusted", []);
          return true;
        }
      }
      return false;
    }

    return function updateTasksRange(gantt) {
      _init_tasks_range(gantt);
      _adjust_scales(gantt);
    };

  }

  treeHelperJs = function () {

    function copyLinkIdsArray(gantt, linkIds, targetHash) {
      for (var i = 0; i < linkIds.length; i++) {
        if (gantt.isLinkExists(linkIds[i])) {
          targetHash[linkIds[i]] = gantt.getLink(linkIds[i]);
        }
      }
    }

    function copyLinkIds(gantt, task, targetHash) {
      copyLinkIdsArray(gantt, task.$source, targetHash);
      copyLinkIdsArray(gantt, task.$target, targetHash);
    }

    function getSubtreeLinks(gantt, rootId) {
      var res = {};

      if (gantt.isTaskExists(rootId)) {
        copyLinkIds(gantt, gantt.getTask(rootId), res);
      }

      gantt.eachTask(function (child) {
        copyLinkIds(gantt, child, res);
      }, rootId);

      return res;
    }

    function getSubtreeTasks(gantt, rootId) {
      var res = {};

      gantt.eachTask(function (child) {
        res[child.id] = child;
      }, rootId);

      return res;
    }

    return {
      getSubtreeLinks: getSubtreeLinks,
      getSubtreeTasks: getSubtreeTasks
    };
  }

  datastoreHooks = function (gantt) {

    var utils = this.helperService.utils;
    var facadeFactory = this.facadeFactoryJs;
    var calculateScaleRange = this.calculateScaleRangeJs;
    function initDataStores(gantt) {

      var facade = facadeFactory.create();
      utils.mixin(gantt, facade);
      var tasksStore = gantt.createDatastore({
        name: "task",
        type: "treeDatastore",
        rootId: function () { return gantt.config.root_id; },
        initItem: utils.bind(_init_task, gantt),
        getConfig: function () { return gantt.config; }
      });

      var linksStore = gantt.createDatastore({
        name: "link",
        initItem: utils.bind(_init_link, gantt)
      });

      gantt.attachEvent("onDestroy", function () {
        tasksStore.destructor();
        linksStore.destructor();
      });

      tasksStore.attachEvent("onBeforeRefreshAll", function () {

        var order = tasksStore.getVisibleItems();

        for (var i = 0; i < order.length; i++) {
          var item = order[i];
          item.$index = i;
          gantt.resetProjectDates(item);
        }

      });

      tasksStore.attachEvent("onFilterItem", function (id, task) {
        var min = null, max = null;
        if (gantt.config.start_date && gantt.config.end_date) {
          if (gantt._isAllowedUnscheduledTask(task)) return true;
          min = gantt.config.start_date.valueOf();
          max = gantt.config.end_date.valueOf();

          if (+task.start_date > max || +task.end_date < +min)
            return false;
        }
        return true;
      });

      tasksStore.attachEvent("onIdChange", function (oldId, newId) {
        gantt._update_flags(oldId, newId);
      });

      tasksStore.attachEvent("onAfterUpdate", function (id) {
        gantt._update_parents(id);
        if (gantt.getState("batchUpdate").batch_update) {
          return true;
        }

        var task = tasksStore.getItem(id);
        for (var i = 0; i < task.$source.length; i++) {
          linksStore.refresh(task.$source[i]);
        }
        for (var i = 0; i < task.$target.length; i++) {
          linksStore.refresh(task.$target[i]);
        }
      });

      tasksStore.attachEvent("onAfterItemMove", function (sid, parent, tindex) {
        var source = gantt.getTask(sid);

        if (this.getNextSibling(sid) !== null) {
          source.$drop_target = this.getNextSibling(sid);
        } else if (this.getPrevSibling(sid) !== null) {
          source.$drop_target = "next:" + this.getPrevSibling(sid);
        } else {
          source.$drop_target = "next:null";
        }

      });

      tasksStore.attachEvent("onStoreUpdated", function (id, item, action) {
        if (action == "delete") {
          gantt._update_flags(id, null);
        }

        var state = gantt.$services.getService("state");
        if (state.getState("batchUpdate").batch_update) {
          return;
        }

        if (gantt.config.fit_tasks && action !== "paint") {
          var oldState = gantt.getState();
          calculateScaleRange(gantt);
          var newState = gantt.getState();

          //this._init_tasks_range();
          if (+oldState.min_date != +newState.min_date || +oldState.max_date != +newState.max_date) {
            gantt.render();

            gantt.callEvent("onScaleAdjusted", []);
            return true;
          }

        }

        if (action == "add" || action == "move" || action == "delete") {
          gantt.$layout.resize();
        } else if (!id) {
          linksStore.refresh();
        }

      });

      linksStore.attachEvent("onAfterAdd", function (id, link) {
        sync_link(link);
      });
      linksStore.attachEvent("onAfterUpdate", function (id, link) {
        sync_links();
      });
      linksStore.attachEvent("onAfterDelete", function (id, link) {
        sync_link_delete(link);
      });
      linksStore.attachEvent("onBeforeIdChange", function (oldId, newId) {
        sync_link_delete(gantt.mixin({ id: oldId }, gantt.$data.linksStore.getItem(newId)));
        sync_link(gantt.$data.linksStore.getItem(newId));
      });

      function checkLinkedTaskVisibility(taskId) {
        var isVisible = gantt.isTaskVisible(taskId);
        if (!isVisible && gantt.isTaskExists(taskId)) {
          var parent = gantt.getParent(taskId);
          if (gantt.isTaskExists(parent) && gantt.isTaskVisible(parent)) {
            parent = gantt.getTask(parent);
            if (gantt.isSplitTask(parent)) {
              isVisible = true;
            }
          }
        }
        return isVisible;
      }

      linksStore.attachEvent("onFilterItem", function (id, link) {
        if (!gantt.config.show_links) {
          return false;
        }

        var sourceVisible = checkLinkedTaskVisibility(link.source);
        var targetVisible = checkLinkedTaskVisibility(link.target);

        if (!(sourceVisible && targetVisible) ||
          gantt._isAllowedUnscheduledTask(gantt.getTask(link.source)) || gantt._isAllowedUnscheduledTask(gantt.getTask(link.target)))
          return false;

        return gantt.callEvent("onBeforeLinkDisplay", [id, link]);
      });


      (function () {
        // delete all connected links after task is deleted
        var treeHelper = this.treeHelperJs;
        var deletedLinks = {};

        gantt.attachEvent("onBeforeTaskDelete", function (id, item) {
          deletedLinks[id] = treeHelper.getSubtreeLinks(gantt, id);
          return true;
        });

        gantt.attachEvent("onAfterTaskDelete", function (id, item) {
          if (deletedLinks[id]) {
            gantt.$data.linksStore.silent(function () {
              for (var i in deletedLinks[id]) {
                gantt.$data.linksStore.removeItem(i);
                sync_link_delete(deletedLinks[id][i]);
              }

              deletedLinks[id] = null;
            });
          }
        });
      })();

      gantt.attachEvent("onAfterLinkDelete", function (id, link) {
        gantt.refreshTask(link.source);
        gantt.refreshTask(link.target);
      });

      gantt.attachEvent("onParse", sync_links);

      mapEvents({
        source: linksStore,
        target: gantt,
        events: {
          "onItemLoading": "onLinkLoading",
          "onBeforeAdd": "onBeforeLinkAdd",
          "onAfterAdd": "onAfterLinkAdd",
          "onBeforeUpdate": "onBeforeLinkUpdate",
          "onAfterUpdate": "onAfterLinkUpdate",
          "onBeforeDelete": "onBeforeLinkDelete",
          "onAfterDelete": "onAfterLinkDelete",
          "onIdChange": "onLinkIdChange"
        }
      });

      mapEvents({
        source: tasksStore,
        target: gantt,
        events: {
          "onItemLoading": "onTaskLoading",
          "onBeforeAdd": "onBeforeTaskAdd",
          "onAfterAdd": "onAfterTaskAdd",
          "onBeforeUpdate": "onBeforeTaskUpdate",
          "onAfterUpdate": "onAfterTaskUpdate",
          "onBeforeDelete": "onBeforeTaskDelete",
          "onAfterDelete": "onAfterTaskDelete",
          "onIdChange": "onTaskIdChange",
          "onBeforeItemMove": "onBeforeTaskMove",
          "onAfterItemMove": "onAfterTaskMove",
          "onFilterItem": "onBeforeTaskDisplay",
          "onItemOpen": "onTaskOpened",
          "onItemClose": "onTaskClosed",
          "onBeforeSelect": "onBeforeTaskSelected",
          "onAfterSelect": "onTaskSelected",
          "onAfterUnselect": "onTaskUnselected"
        }
      });

      gantt.$data = {
        tasksStore: tasksStore,
        linksStore: linksStore
      };

      function sync_link(link) {
        if (gantt.isTaskExists(link.source)) {
          var sourceTask = gantt.getTask(link.source);
          sourceTask.$source = sourceTask.$source || [];
          sourceTask.$source.push(link.id);
        }
        if (gantt.isTaskExists(link.target)) {
          var targetTask = gantt.getTask(link.target);
          targetTask.$target = targetTask.$target || [];
          targetTask.$target.push(link.id);
        }
      }

      function sync_link_delete(link) {
        if (gantt.isTaskExists(link.source)) {
          var sourceTask = gantt.getTask(link.source);
          for (var i = 0; i < sourceTask.$source.length; i++) {
            if (sourceTask.$source[i] == link.id) {
              sourceTask.$source.splice(i, 1);
              break;
            }
          }
        }
        if (gantt.isTaskExists(link.target)) {
          var targetTask = gantt.getTask(link.target);
          for (var i = 0; i < targetTask.$target.length; i++) {
            if (targetTask.$target[i] == link.id) {
              targetTask.$target.splice(i, 1);
              break;
            }
          }
        }
      }

      function sync_links() {
        var task = null;
        var tasks = gantt.$data.tasksStore.getItems();

        for (var i = 0, len = tasks.length; i < len; i++) {
          task = tasks[i];
          task.$source = [];
          task.$target = [];
        }

        var links = gantt.$data.linksStore.getItems();
        for (var i = 0, len = links.length; i < len; i++) {

          var link = links[i];
          sync_link(link);
        }
      }

      function mapEvents(conf) {
        var mapFrom = conf.source;
        var mapTo = conf.target;
        for (var i in conf.events) {
          (function (sourceEvent, targetEvent) {
            mapFrom.attachEvent(sourceEvent, function () {
              return mapTo.callEvent(targetEvent, Array.prototype.slice.call(arguments));
            }, targetEvent);
          })(i, conf.events[i]);
        }
      }

      function _init_task(task) {
        if (!this.defined(task.id))
          task.id = this.uid();

        if (task.start_date)
          task.start_date = gantt.date.parseDate(task.start_date, "parse_date");
        if (task.end_date)
          task.end_date = gantt.date.parseDate(task.end_date, "parse_date");


        var duration = null;
        if (task.duration || task.duration === 0) {
          task.duration = duration = task.duration * 1;
        }

        if (duration) {
          if (task.start_date && !task.end_date) {
            task.end_date = this.calculateEndDate(task);
          } else if (!task.start_date && task.end_date) {
            task.start_date = this.calculateEndDate({
              start_date: task.end_date,
              duration: -task.duration,
              task: task
            });
          }
        }

        task.progress = Number(task.progress) || 0;

        if (this._isAllowedUnscheduledTask(task)) {
          this._set_default_task_timing(task);
        }
        this._init_task_timing(task);
        if (task.start_date && task.end_date)
          this.correctTaskWorkTime(task);

        task.$source = [];
        task.$target = [];
        if (task.parent === undefined) {
          this.setParent(task, this.config.root_id);
        }

        return task;
      }

      function _init_link(link) {
        if (!this.defined(link.id))
          link.id = this.uid();
        return link;
      }
    }

    return initDataStores;
  }

  dataProcessorEvent1 = function () {

    "use strict";

    // Object.defineProperty(e, "__esModule", { value: true });
    var helpers = this.helperService;
    var DataProcessorEvents = /** @class */ (function () {
      function DataProcessorEvents(gantt, dp) {
        this.$gantt = gantt;
        this.$dp = dp;
        this._dataProcessorHandlers = [];
      }
      DataProcessorEvents.prototype.attach = function () {
        var dp = this.$dp;
        var gantt = this.$gantt;
        var treeHelper = this.treeHelperJs;
        var cascadeDelete = {};
        function clientSideDelete(id) {
          var updated = dp.updatedRows.slice();
          var clientOnly = false;
          for (var i = 0; i < updated.length && !dp._in_progress[id]; i++) {
            if (updated[i] === id) {
              if (gantt.getUserData(id, "!nativeeditor_status") === "inserted") {
                clientOnly = true;
              }
              dp.setUpdated(id, false);
            }
          }
          return clientOnly;
        }
        function getTaskLinks(task) {
          var _links = [];
          if (task.$source) {
            _links = _links.concat(task.$source);
          }
          if (task.$target) {
            _links = _links.concat(task.$target);
          }
          return _links;
        }
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterTaskAdd", function (id, item) {
          if (gantt.isTaskExists(id)) {
            dp.setGanttMode("tasks");
            dp.setUpdated(id, true, "inserted");
          }
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterTaskUpdate", function (id, item) {
          if (gantt.isTaskExists(id)) {
            dp.setGanttMode("tasks");
            dp.setUpdated(id, true);
            // gantt can be destroyed/reinitialized after dp.setUpdated
            if (gantt._sendTaskOrder) {
              gantt._sendTaskOrder(id, item);
            }
          }
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onBeforeTaskDelete", function (id, item) {
          if (!gantt.config.cascade_delete) {
            return true;
          }
          cascadeDelete[id] = {
            tasks: treeHelper.getSubtreeTasks(gantt, id),
            links: treeHelper.getSubtreeLinks(gantt, id)
          };
          return true;
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterTaskDelete", function (id, item) {
          dp.setGanttMode("tasks");
          // not send delete request if item is not inserted into the db - just remove it from the client
          var needDbDelete = !clientSideDelete(id);
          if (!needDbDelete) {
            return;
          }
          if (gantt.config.cascade_delete && cascadeDelete[id]) {
            var dpMode = dp.updateMode;
            dp.setUpdateMode("off");
            var cascade = cascadeDelete[id];
            for (var i in cascade.tasks) {
              if (!clientSideDelete(i)) {
                dp.setUpdated(i, true, "deleted");
              }
            }
            dp.setGanttMode("links");
            for (var i in cascade.links) {
              if (!clientSideDelete(i)) {
                dp.setUpdated(i, true, "deleted");
              }
            }
            cascadeDelete[id] = null;
            if (dpMode !== "off") {
              dp.sendAllData();
            }
            dp.setGanttMode("tasks");
            dp.setUpdateMode(dpMode);
          }
          dp.setUpdated(id, true, "deleted");
          if (dp.updateMode !== "off" && !dp._tSend) {
            dp.sendAllData();
          }
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterLinkUpdate", function (id, item) {
          if (gantt.isLinkExists(id)) {
            dp.setGanttMode("links");
            dp.setUpdated(id, true);
          }
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterLinkAdd", function (id, item) {
          if (gantt.isLinkExists(id)) {
            dp.setGanttMode("links");
            dp.setUpdated(id, true, "inserted");
          }
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterLinkDelete", function (id, item) {
          dp.setGanttMode("links");
          var needDbDelete = !clientSideDelete(id);
          if (!needDbDelete) {
            return;
          }
          dp.setUpdated(id, true, "deleted");
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onRowDragEnd", function (id, target) {
          gantt._sendTaskOrder(id, gantt.getTask(id));
        }));
        var tasks = null;
        var links = null;
        this._dataProcessorHandlers.push(gantt.attachEvent("onTaskIdChange", function (oldId, newId) {
          if (!dp._waitMode) {
            return;
          }
          var children = gantt.getChildren(newId);
          if (children.length) {
            tasks = tasks || {};
            for (var i = 0; i < children.length; i++) {
              var ch = this.getTask(children[i]);
              tasks[ch.id] = ch;
            }
          }
          var item = this.getTask(newId);
          var itemLinks = getTaskLinks(item);
          if (itemLinks.length) {
            links = links || {};
            for (var i = 0; i < itemLinks.length; i++) {
              var link = this.getLink(itemLinks[i]);
              links[link.id] = link;
            }
          }
        }));
        dp.attachEvent("onAfterUpdateFinish", function () {
          if (tasks || links) {
            gantt.batchUpdate(function () {
              for (var id in tasks) {
                gantt.updateTask(tasks[id].id);
              }
              for (var id in links) {
                gantt.updateLink(links[id].id);
              }
              tasks = null;
              links = null;
            });
            if (tasks) {
              gantt._dp.setGanttMode("tasks");
            }
            else {
              gantt._dp.setGanttMode("links");
            }
          }
        });
        dp.attachEvent("onBeforeDataSending", function () {
          if (this._tMode === "CUSTOM") {
            return true;
          }
          var url = this._serverProcessor;
          if (this._tMode === "REST-JSON" || this._tMode === "REST") {
            var mode = this._ganttMode;
            url = url.substring(0, url.indexOf("?") > -1 ? url.indexOf("?") : url.length);
            // editing=true&
            this.serverProcessor = url + (url.slice(-1) === "/" ? "" : "/") + mode;
          }
          else {
            var pluralizedMode = this._ganttMode + "s";
            this.serverProcessor = url + gantt.ajax.urlSeparator(url) + "gantt_mode=" + pluralizedMode;
          }
          return true;
        });
        dp.attachEvent("insertCallback", function insertCallback(upd, id, parent, mode) {
          var data = upd.data || gantt.xml._xmlNodeToJSON(upd.firstChild);
          var methods = {
            add: gantt.addTask,
            isExist: gantt.isTaskExists
          };
          if (mode === "links") {
            methods.add = gantt.addLink;
            methods.isExist = gantt.isLinkExists;
          }
          if (methods.isExist.call(gantt, id)) {
            return;
          }
          data.id = id;
          methods.add.call(gantt, data);
        });
        dp.attachEvent("updateCallback", function updateCallback(upd, id) {
          var data = upd.data || gantt.xml._xmlNodeToJSON(upd.firstChild);
          if (!gantt.isTaskExists(id)) {
            return;
          }
          var objData = gantt.getTask(id);
          for (var key in data) {
            var property = data[key];
            switch (key) {
              case "id":
                continue;
              case "start_date":
              case "end_date":
                property = gantt.templates.xml_date !== gantt.templates.parse_date ? gantt.templates.xml_date(property) : gantt.templates.parse_date(property);
                break;
              case "duration":
                objData.end_date = gantt.calculateEndDate({ start_date: objData.start_date, duration: property, task: objData });
                break;
            }
            objData[key] = property;
          }
          gantt.updateTask(id);
          gantt.refreshData();
        });
        dp.attachEvent("deleteCallback", function deleteCallback(upd, id, parent, mode) {
          var methods = {
            delete: gantt.deleteTask,
            isExist: gantt.isTaskExists
          };
          if (mode === "links") {
            methods.delete = gantt.deleteLink;
            methods.isExist = gantt.isLinkExists;
          }
          if (methods.isExist.call(gantt, id)) {
            methods.delete.call(gantt, id);
          }
        });
      };
      DataProcessorEvents.prototype.detach = function () {
        var _this = this;
        helpers.forEach(this._dataProcessorHandlers, function (e) {
          _this.$gantt.detachEvent(e);
        });
        this._dataProcessorHandlers = [];
      };
      return DataProcessorEvents;
    }());
    return {default : DataProcessorEvents};
  }

  extendGantt1 = function () {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    function extendGantt(gantt, dp) {
      gantt.getUserData = function (id, name) {
        if (!this.userdata) {
          this.userdata = {};
        }
        if (this.userdata[id] && this.userdata[id][name]) {
          return this.userdata[id][name];
        }
        return "";
      };
      gantt.setUserData = function (id, name, value) {
        if (!this.userdata) {
          this.userdata = {};
        }
        if (!this.userdata[id]) {
          this.userdata[id] = {};
        }
        this.userdata[id][name] = value;
      };
      gantt._change_id = function (oldId, newId) {
        if (this._dp._ganttMode !== "task") {
          this.changeLinkId(oldId, newId);
        }
        else {
          this.changeTaskId(oldId, newId);
        }
      };
      gantt._row_style = function (rowId, classname) {
        if (this._dp._ganttMode !== "task") {
          return;
        }
        if (!gantt.isTaskExists(rowId)) {
          return;
        }
        var task = gantt.getTask(rowId);
        task.$dataprocessor_class = classname;
        gantt.refreshTask(rowId);
      };
      // fake method for dataprocessor
      gantt._delete_task = function (rowId, node) { }; // tslint:disable-line
      gantt._sendTaskOrder = function (id, item) {
        if (item.$drop_target) {
          this._dp.setGanttMode("task");
          this.getTask(id).target = item.$drop_target;
          this._dp.setUpdated(id, true, "order");
          delete this.getTask(id).$drop_target;
        }
      };
      gantt.setDp = function () {
        this._dp = dp;
      };
      gantt.setDp();
    }
    return { default : extendGantt };

  }

  DataProcessorJS = function () {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    var eventable = this.eventableService;
    var helpers = this.helperService;
    var utils = this.helperService.utils;
    var data_processor_events_1 = this.dataProcessorEvent1;
    var extend_gantt_1 = this.extendGantt1;
    function createDataProcessor(config) {
      var router;
      var tMode;
      if (config instanceof Function) {
        router = config;
      }
      else if (config.hasOwnProperty("router")) {
        router = config.router;
      }
      else if (config.hasOwnProperty("link") && config.hasOwnProperty("task")) {
        router = config;
      }
      if (router) {
        tMode = "CUSTOM";
      }
      else {
        tMode = config.mode || "REST-JSON";
      }
      var gantt = this; // tslint:disable-line
      var dp = new DataProcessor(config.url);
      dp.init(gantt);
      dp.setTransactionMode({
        mode: tMode,
        router: router
      }, config.batchUpdate);
      return dp;
    }
    return { createDataProcessor : createDataProcessor };
    var DataProcessor = /** @class */ (function () {
      function DataProcessor(serverProcessorURL) {
        this.serverProcessor = serverProcessorURL;
        this.action_param = "!nativeeditor_status";
        this.object = null;
        this.updatedRows = []; // ids of updated rows
        this.autoUpdate = true;
        this.updateMode = "cell";
        this._headers = null;
        this._payload = null;
        this._postDelim = "_";
        this._waitMode = 0;
        this._in_progress = {}; // ?
        this._invalid = {};
        this.mandatoryFields = [];
        this.messages = [];
        this.styles = {
          updated: "font-weight:bold;",
          inserted: "font-weight:bold;",
          deleted: "text-decoration : line-through;",
          invalid: "background-color:FFE0E0;",
          invalid_cell: "border-bottom:2px solid red;",
          error: "color:red;",
          clear: "font-weight:normal;text-decoration:none;"
        };
        this.enableUTFencoding(true);
        eventable(this);
      }
      DataProcessor.prototype.setTransactionMode = function (mode, total) {
        if (typeof mode === "object") {
          this._tMode = mode.mode || this._tMode;
          if (utils.defined(mode.headers)) {
            this._headers = mode.headers;
          }
          if (utils.defined(mode.payload)) {
            this._payload = mode.payload;
          }
        }
        else {
          this._tMode = mode;
          this._tSend = total;
        }
        if (this._tMode === "REST") {
          this._tSend = false;
          this._endnm = true;
        }
        if (this._tMode === "JSON" || this._tMode === "REST-JSON") {
          this._tSend = false;
          this._endnm = true;
          this._serializeAsJson = true;
          this._headers = this._headers || {};
          this._headers["Content-type"] = "application/json";
        }
        if (this._tMode === "CUSTOM") {
          this._tSend = false;
          this._endnm = true;
          this._router = mode.router;
        }
      };
      DataProcessor.prototype.escape = function (data) {
        if (this._utf) {
          return encodeURIComponent(data);
        }
        else {
          return escape(data);
        }
      };
      /**
       * @desc: allows to set escaping mode
       * @param: true - utf based escaping, simple - use current page encoding
       * @type: public
       */
      DataProcessor.prototype.enableUTFencoding = function (mode) {
        this._utf = !!mode;
      };
      /**
       * @desc: allows to define, which column may trigger update
       * @param: val - array or list of true/false values
       * @type: public
       */
      DataProcessor.prototype.setDataColumns = function (val) {
        this._columns = (typeof val === "string") ? val.split(",") : val;
      };
      /**
       * @desc: get state of updating
       * @returns:   true - all in sync with server, false - some items not updated yet.
       * @type: public
       */
      DataProcessor.prototype.getSyncState = function () {
        return !this.updatedRows.length;
      };
      /**
       * @desc: enable/disable named field for data syncing, will use column ids for grid
       * @param:   mode - true/false
       * @type: public
       */
      DataProcessor.prototype.enableDataNames = function (mode) {
        this._endnm = !!mode;
      };
      /**
       * @desc: enable/disable mode , when only changed fields and row id send to the server side, instead of all fields in default mode
       * @param:   mode - true/false
       * @type: public
       */
      DataProcessor.prototype.enablePartialDataSend = function (mode) {
        this._changed = !!mode;
      };
      /**
       * @desc: set if rows should be send to server automaticaly
       * @param: mode - "row" - based on row selection changed, "cell" - based on cell editing finished, "off" - manual data sending
       * @type: public
       */
      DataProcessor.prototype.setUpdateMode = function (mode, dnd) {
        this.autoUpdate = (mode === "cell");
        this.updateMode = mode;
        this.dnd = dnd;
      };
      DataProcessor.prototype.ignore = function (code, master) {
        this._silent_mode = true;
        code.call(master || window);
        this._silent_mode = false;
      };
      /**
       * @desc: mark row as updated/normal. check mandatory fields,initiate autoupdate (if turned on)
       * @param: rowId - id of row to set update-status for
       * @param: state - true for "updated", false for "not updated"
       * @param: mode - update mode name
       * @type: public
       */
      DataProcessor.prototype.setUpdated = function (rowId, state, mode) {
        if (this._silent_mode) {
          return;
        }
        var ind = this.findRow(rowId);
        mode = mode || "updated";
        var existing = this.$gantt.getUserData(rowId, this.action_param);
        if (existing && mode === "updated") {
          mode = existing;
        }
        if (state) {
          this.set_invalid(rowId, false); // clear previous error flag
          this.updatedRows[ind] = rowId;
          this.$gantt.setUserData(rowId, this.action_param, mode);
          if (this._in_progress[rowId]) {
            this._in_progress[rowId] = "wait";
          }
        }
        else {
          if (!this.is_invalid(rowId)) {
            this.updatedRows.splice(ind, 1);
            this.$gantt.setUserData(rowId, this.action_param, "");
          }
        }
        this.markRow(rowId, state, mode);
        if (state && this.autoUpdate) {
          this.sendData(rowId);
        }
      };
      DataProcessor.prototype.markRow = function (id, state, mode) {
        var str = "";
        var invalid = this.is_invalid(id);
        if (invalid) {
          str = this.styles[invalid];
          state = true;
        }
        if (this.callEvent("onRowMark", [id, state, mode, invalid])) {
          // default logic
          str = this.styles[state ? mode : "clear"] + str;
          this.$gantt[this._methods[0]](id, str);
          if (invalid && invalid.details) {
            str += this.styles[invalid + "_cell"];
            for (var i = 0; i < invalid.details.length; i++) {
              if (invalid.details[i]) {
                this.$gantt[this._methods[1]](id, i, str);
              }
            }
          }
        }
      };
      DataProcessor.prototype.getActionByState = function (state) {
        if (state === "inserted") {
          return "create";
        }
        if (state === "updated") {
          return "update";
        }
        if (state === "deleted") {
          return "delete";
        }
        // reorder
        return "update";
      };
      DataProcessor.prototype.getState = function (id) {
        return this.$gantt.getUserData(id, this.action_param);
      };
      DataProcessor.prototype.is_invalid = function (id) {
        return this._invalid[id];
      };
      DataProcessor.prototype.set_invalid = function (id, mode, details) {
        if (details) {
          mode = {
            value: mode,
            details: details,
            toString: function () {
              return this.value.toString();
            }
          };
        }
        this._invalid[id] = mode;
      };
      /**
       * @desc: check mandatory fields and varify values of cells, initiate update (if specified)
       * @param: rowId - id of row to set update-status for
       * @type: public
       */
      // tslint:disable-next-line
      DataProcessor.prototype.checkBeforeUpdate = function (rowId) {
        return true;
      };
      /**
       * @desc: send row(s) values to server
       * @param: rowId - id of row which data to send. If not specified, then all "updated" rows will be send
       * @type: public
       */
      DataProcessor.prototype.sendData = function (rowId) {
        if (this._waitMode && (this.$gantt.mytype === "tree" || this.$gantt._h2)) {
          return;
        }
        if (this.$gantt.editStop) {
          this.$gantt.editStop();
        }
        if (typeof rowId === "undefined" || this._tSend) {
          return this.sendAllData();
        }
        if (this._in_progress[rowId]) {
          return false;
        }
        this.messages = [];
        if (!this.checkBeforeUpdate(rowId) && this.callEvent("onValidationError", [rowId, this.messages])) {
          return false; // ??? unreachable code, drop it?
        }
        this._beforeSendData(this._getRowData(rowId), rowId);
      };
      DataProcessor.prototype._beforeSendData = function (data, rowId) {
        if (!this.callEvent("onBeforeUpdate", [rowId, this.getState(rowId), data])) {
          return false;
        }
        this._sendData(data, rowId);
      };
      DataProcessor.prototype.serialize = function (data, id) {
        if (this._serializeAsJson) {
          return this._serializeAsJSON(data);
        }
        if (typeof data === "string") {
          return data;
        }
        if (typeof id !== "undefined") {
          return this.serialize_one(data, "");
        }
        else {
          var stack = [];
          var keys = [];
          for (var key in data) {
            if (data.hasOwnProperty(key)) {
              stack.push(this.serialize_one(data[key], key + this._postDelim));
              keys.push(key);
            }
          }
          stack.push("ids=" + this.escape(keys.join(",")));
          if (this.$gantt.security_key) {
            stack.push("dhx_security=" + this.$gantt.security_key);
          }
          return stack.join("&");
        }
      };
      DataProcessor.prototype._serializeAsJSON = function (data) {
        if (typeof data === "string") {
          return data;
        }
        var copy = utils.copy(data);
        if (this._tMode === "REST-JSON") {
          delete copy.id;
          delete copy[this.action_param];
        }
        return JSON.stringify(copy);
      };
      DataProcessor.prototype.serialize_one = function (data, pref) {
        if (typeof data === "string") {
          return data;
        }
        var stack = [];
        var serialized = "";
        for (var key in data)
          if (data.hasOwnProperty(key)) {
            if ((key === "id" ||
              key == this.action_param) && // tslint:disable-line
              this._tMode === "REST") {
              continue;
            }
            if (typeof data[key] === "string" || typeof data[key] === "number") {
              serialized = data[key];
            }
            else {
              serialized = JSON.stringify(data[key]);
            }
            stack.push(this.escape((pref || "") + key) + "=" + this.escape(serialized));
          }
        return stack.join("&");
      };
      DataProcessor.prototype._applyPayload = function (url) {
        var ajax = this.$gantt.ajax;
        if (this._payload) {
          for (var key in this._payload) {
            url = url + ajax.urlSeparator(url) + this.escape(key) + "=" + this.escape(this._payload[key]);
          }
        }
        return url;
      };
      DataProcessor.prototype._sendData = function (dataToSend, rowId) {
        var _this = this;
        if (!dataToSend) {
          return; // nothing to send
        }
        if (!this.callEvent("onBeforeDataSending", rowId ? [rowId, this.getState(rowId), dataToSend] : [null, null, dataToSend])) {
          return false;
        }
        if (rowId) {
          this._in_progress[rowId] = (new Date()).valueOf();
        }
        var ajax = this.$gantt.ajax;
        if (this._tMode === "CUSTOM") {
          var taskState_1 = this.getState(rowId);
          var taskAction = this.getActionByState(taskState_1);
          var ganttMode = this.getGanttMode();
          var _onResolvedCreateUpdate = function (tag) {
            var action = taskState_1 || "updated";
            var sid = rowId;
            var tid = rowId;
            if (tag) {
              action = tag.action || taskState_1;
              sid = tag.sid || sid;
              tid = tag.id || tag.tid || tid;
            }
            _this.afterUpdateCallback(sid, tid, action, tag);
          };
          var actionPromise = void 0;
          if (this._router instanceof Function) {
            actionPromise = this._router(ganttMode, taskAction, dataToSend, rowId);
          }
          else if (this._router[ganttMode] instanceof Function) {
            actionPromise = this._router[ganttMode](taskAction, dataToSend, rowId);
          }
          else {
            switch (taskState_1) {
              case "inserted":
                actionPromise = this._router[ganttMode].create(dataToSend);
                break;
              case "deleted":
                actionPromise = this._router[ganttMode].delete(rowId);
                break;
              default:
                actionPromise = this._router[ganttMode].update(dataToSend, rowId);
                break;
            }
          }
          if (actionPromise) {
            // neither promise nor {tid: newId} response object
            if (!actionPromise.then &&
              (actionPromise.id === undefined && actionPromise.tid === undefined)) {
              throw new Error("Incorrect router return value. A Promise or a response object is expected");
            }
            if (actionPromise.then) {
              actionPromise.then(_onResolvedCreateUpdate);
            }
            else {
              // custom method may return a response object in case of sync action
              _onResolvedCreateUpdate(actionPromise);
            }
          }
          else {
            _onResolvedCreateUpdate(null);
          }
          return;
        }
        var queryParams;
        queryParams = {
          callback: function (xml) {
            var ids = [];
            if (rowId) {
              ids.push(rowId);
            }
            else if (dataToSend) {
              for (var key in dataToSend) {
                ids.push(key);
              }
            }
            return _this.afterUpdate(_this, xml, ids);
          },
          headers: this._headers
        };
        var urlParams = this.serverProcessor + (this._user ? (ajax.urlSeparator(this.serverProcessor) + ["dhx_user=" + this._user, "dhx_version=" + this.$gantt.getUserData(0, "version")].join("&")) : "");
        var url = this._applyPayload(urlParams);
        var data;
        switch (this._tMode) {
          case "GET":
            queryParams.url = url + ajax.urlSeparator(url) + this.serialize(dataToSend, rowId);
            queryParams.method = "GET";
            break;
          case "POST":
            queryParams.url = url;
            queryParams.method = "POST";
            queryParams.data = this.serialize(dataToSend, rowId);
            break;
          case "JSON":
            data = {};
            for (var key in dataToSend) {
              if (key === this.action_param || key === "id" || key === "gr_id") {
                continue;
              }
              data[key] = dataToSend[key];
            }
            queryParams.url = url;
            queryParams.method = "POST";
            queryParams.data = JSON.stringify({
              id: rowId,
              action: dataToSend[this.action_param],
              data: data
            });
            break;
          case "REST":
          case "REST-JSON":
            url = urlParams.replace(/(&|\?)editing=true/, "");
            data = "";
            switch (this.getState(rowId)) {
              case "inserted":
                queryParams.method = "POST";
                queryParams.data = this.serialize(dataToSend, rowId);
                break;
              case "deleted":
                queryParams.method = "DELETE";
                url = url + (url.slice(-1) === "/" ? "" : "/") + rowId;
                break;
              default:
                queryParams.method = "PUT";
                queryParams.data = this.serialize(dataToSend, rowId);
                url = url + (url.slice(-1) === "/" ? "" : "/") + rowId;
                break;
            }
            queryParams.url = this._applyPayload(url);
            break;
        }
        this._waitMode++;
        return ajax.query(queryParams);
      };
      DataProcessor.prototype._forEachUpdatedRow = function (code) {
        var updatedRows = this.updatedRows.slice();
        for (var i = 0; i < updatedRows.length; i++) {
          var rowId = updatedRows[i];
          if (this.$gantt.getUserData(rowId, this.action_param)) {
            code.call(this, rowId);
          }
        }
      };
      DataProcessor.prototype.sendAllData = function () {
        if (!this.updatedRows.length) {
          return;
        }
        this.messages = [];
        var valid = true;
        this._forEachUpdatedRow(function (rowId) {
          valid = valid && this.checkBeforeUpdate(rowId); // ??? checkBeforeUpdate() always is true
        });
        if (!valid && !this.callEvent("onValidationError", ["", this.messages])) {
          return false;
        }
        if (this._tSend) {
          this._sendData(this._getAllData());
        }
        else {
          var stop_1 = false;
          // this.updatedRows can be spliced from onBeforeUpdate via dp.setUpdated false
          // use an iterator instead of for(var i = 0; i < this.updatedRows; i++) then
          this._forEachUpdatedRow(function (rowId) {
            if (stop_1) {
              return;
            }
            if (!this._in_progress[rowId]) {
              if (this.is_invalid(rowId)) {
                return;
              }
              this._beforeSendData(this._getRowData(rowId), rowId);
              if (this._waitMode && (this.$gantt.mytype === "tree" || this.$gantt._h2)) {
                stop_1 = true; // block send all for tree
              }
            }
          });
        }
      };
      DataProcessor.prototype._getAllData = function () {
        var out = {};
        var hasOne = false;
        this._forEachUpdatedRow(function (id) {
          if (this._in_progress[id] || this.is_invalid(id)) {
            return;
          }
          var row = this._getRowData(id);
          if (!this.callEvent("onBeforeUpdate", [id, this.getState(id), row])) {
            return;
          }
          out[id] = row;
          hasOne = true;
          this._in_progress[id] = (new Date()).valueOf();
        });
        return hasOne ? out : null;
      };
      /**
       * @desc: specify column which value should be verified before sending to server
       * @param: ind - column index (0 based)
       * @param: verifFunction - function(object) which should verify cell value (if not specified, then value will be compared to empty string). Two arguments will be passed into it: value and column name
       * @type: public
       */
      DataProcessor.prototype.setVerificator = function (ind, verifFunction) {
        this.mandatoryFields[ind] = verifFunction || (function (value) { return (value !== ""); });
      };
      /**
       * @desc: remove column from list of those which should be verified
       * @param: ind - column Index (0 based)
       * @type: public
       */
      DataProcessor.prototype.clearVerificator = function (ind) {
        this.mandatoryFields[ind] = false;
      };
      DataProcessor.prototype.findRow = function (pattern) {
        var i = 0;
        for (i = 0; i < this.updatedRows.length; i++) {
          if (pattern == this.updatedRows[i]) { // tslint:disable-line
            break;
          }
        }
        return i;
      };
      /**
       * @desc: define custom actions
       * @param: name - name of action, same as value of action attribute
       * @param: handler - custom function, which receives a XMl response content for action
       * @type: private
       */
      DataProcessor.prototype.defineAction = function (name, handler) {
        if (!this._uActions) {
          this._uActions = {};
        }
        this._uActions[name] = handler;
      };
      /**
       * @desc: used in combination with setOnBeforeUpdateHandler to create custom client-server transport system
       * @param: sid - id of item before update
       * @param: tid - id of item after up0ate
       * @param: action - action name
       * @type: public
       * @topic: 0
       */
      DataProcessor.prototype.afterUpdateCallback = function (sid, tid, action, btag) {
        if (!this.$gantt) {
          // destructor has been called before the callback
          return;
        }
        var marker = sid;
        var correct = (action !== "error" && action !== "invalid");
        if (!correct) {
          this.set_invalid(sid, action);
        }
        if ((this._uActions) && (this._uActions[action]) && (!this._uActions[action](btag))) {
          return (delete this._in_progress[marker]);
        }
        if (this._in_progress[marker] !== "wait") {
          this.setUpdated(sid, false);
        }
        var originalSid = sid;
        switch (action) {
          case "inserted":
          case "insert":
            if (tid != sid) { // tslint:disable-line
              this.setUpdated(sid, false);
              this.$gantt[this._methods[2]](sid, tid);
              sid = tid;
            }
            break;
          case "delete":
          case "deleted":
            this.$gantt.setUserData(sid, this.action_param, "true_deleted");
            this.$gantt[this._methods[3]](sid);
            delete this._in_progress[marker];
            return this.callEvent("onAfterUpdate", [sid, action, tid, btag]);
        }
        if (this._in_progress[marker] !== "wait") {
          if (correct) {
            this.$gantt.setUserData(sid, this.action_param, "");
          }
          delete this._in_progress[marker];
        }
        else {
          delete this._in_progress[marker];
          this.setUpdated(tid, true, this.$gantt.getUserData(sid, this.action_param));
        }
        this.callEvent("onAfterUpdate", [originalSid, action, tid, btag]);
      };
      /**
       * @desc: response from server
       * @param: xml - XMLLoader object with response XML
       * @type: private
       */
      DataProcessor.prototype.afterUpdate = function (that, xml, id) {
        var _xml;
        if (arguments.length === 3) {
          _xml = arguments[1];
        }
        else {
          // old dataprocessor
          _xml = arguments[4];
        }
        var mode = this.getGanttMode();
        var reqUrl = _xml.filePath || _xml.url;
        if (this._tMode !== "REST" && this._tMode !== "REST-JSON") {
          if (reqUrl.indexOf("gantt_mode=links") !== -1) {
            mode = "link";
          }
          else {
            mode = "task";
          }
        }
        else {
          if (reqUrl.indexOf("/link") > reqUrl.indexOf("/task")) {
            mode = "link";
          }
          else {
            mode = "task";
          }
        }
        this.setGanttMode(mode);
        var ajax = this.$gantt.ajax;
        // try to use json first
        if (window /* .JSON */) {
          var tag = void 0;
          try {
            tag = JSON.parse(xml.xmlDoc.responseText);
          }
          catch (e) {
            // empty response also can be processed by json handler
            if (!xml.xmlDoc.responseText.length) {
              tag = {};
            }
          }
          if (tag) {
            var action = tag.action || this.getState(id) || "updated";
            var sid = tag.sid || id[0];
            var tid = tag.tid || id[0];
            that.afterUpdateCallback(sid, tid, action, tag);
            that.finalizeUpdate();
            this.setGanttMode(mode);
            return;
          }
        }
        // xml response
        var top = ajax.xmltop("data", xml.xmlDoc); // fix incorrect content type in IE
        if (!top) {
          return this.cleanUpdate(id);
        }
        var atag = ajax.xpath("//data/action", top);
        if (!atag.length) {
          return this.cleanUpdate(id);
        }
        for (var i = 0; i < atag.length; i++) {
          var btag = atag[i];
          var action = btag.getAttribute("type");
          var sid = btag.getAttribute("sid");
          var tid = btag.getAttribute("tid");
          that.afterUpdateCallback(sid, tid, action, btag);
        }
        that.finalizeUpdate();
      };
      DataProcessor.prototype.cleanUpdate = function (id) {
        if (id) {
          for (var i = 0; i < id.length; i++) {
            delete this._in_progress[id[i]];
          }
        }
      };
      DataProcessor.prototype.finalizeUpdate = function () {
        if (this._waitMode) {
          this._waitMode--;
        }
        if ((this.$gantt.mytype === "tree" || this.$gantt._h2) && this.updatedRows.length) {
          this.sendData();
        }
        this.callEvent("onAfterUpdateFinish", []);
        if (!this.updatedRows.length) {
          this.callEvent("onFullSync", []);
        }
      };
      /**
       * @desc: initializes data-processor
       * @param: anObj - dhtmlxGrid object to attach this data-processor to
       * @type: public
       */
      DataProcessor.prototype.init = function (anObj) {
        if (this._initialized) {
          return;
        }
        this.$gantt = anObj;
        if (this.$gantt._dp_init) {
          this.$gantt._dp_init(this);
        }
        this._setDefaultTransactionMode();
        this.styles = {
          updated: "gantt_updated",
          order: "gantt_updated",
          inserted: "gantt_inserted",
          deleted: "gantt_deleted",
          invalid: "gantt_invalid",
          error: "gantt_error",
          clear: ""
        };
        this._methods = ["_row_style", "setCellTextStyle", "_change_id", "_delete_task"];
        extend_gantt_1.default(this.$gantt, this);
        var dataProcessorEvents = new data_processor_events_1.default(this.$gantt, this);
        dataProcessorEvents.attach();
        this.attachEvent("onDestroy", function () {
          delete this.setGanttMode;
          delete this._getRowData;
          delete this.$gantt._dp;
          delete this.$gantt._change_id;
          delete this.$gantt._row_style;
          delete this.$gantt._delete_task;
          delete this.$gantt._sendTaskOrder;
          delete this.$gantt;
          dataProcessorEvents.detach();
        });
        this.$gantt.callEvent("onDataProcessorReady", [this]);
        this._initialized = true;
      };
      DataProcessor.prototype._setDefaultTransactionMode = function () {
        if (this.serverProcessor) {
          this.setTransactionMode("POST", true);
          this.serverProcessor += (this.serverProcessor.indexOf("?") !== -1 ? "&" : "?") + "editing=true";
          this._serverProcessor = this.serverProcessor;
        }
      };
      DataProcessor.prototype.setOnAfterUpdate = function (handler) {
        this.attachEvent("onAfterUpdate", handler);
      };
      DataProcessor.prototype.enableDebug = function (mode) { }; // tslint:disable-line
      DataProcessor.prototype.setOnBeforeUpdateHandler = function (handler) {
        this.attachEvent("onBeforeDataSending", handler);
      };
      /* starts autoupdate mode
          @param interval time interval for sending update requests
      */
      DataProcessor.prototype.setAutoUpdate = function (interval, user) {
        var _this = this;
        interval = interval || 2000;
        this._user = user || (new Date()).valueOf();
        this._needUpdate = false;
        // this._loader = null;
        this._updateBusy = false;
        this.attachEvent("onAfterUpdate", this.afterAutoUpdate); // arguments sid, action, tid, xml_node;
        this.attachEvent("onFullSync", this.fullSync);
        window.setInterval(function () {
          _this.loadUpdate();
        }, interval);
      };
      /* process updating request answer
          if status == collision version is depricated
          set flag for autoupdating immidiatly
      */
      DataProcessor.prototype.afterAutoUpdate = function (sid, action, tid, xml_node) {
        if (action === "collision") {
          this._needUpdate = true;
          return false;
        }
        else {
          return true;
        }
      };
      /* callback function for onFillSync event
          call update function if it's need
      */
      DataProcessor.prototype.fullSync = function () {
        if (this._needUpdate) {
          this._needUpdate = false;
          this.loadUpdate();
        }
        return true;
      };
      /* sends query to the server and call callback function
      */
      DataProcessor.prototype.getUpdates = function (url, callback) {
        var ajax = this.$gantt.ajax;
        if (this._updateBusy) {
          return false;
        }
        else {
          this._updateBusy = true;
        }
        // this._loader = this._loader || new dtmlXMLLoaderObject(true);
        // this._loader.async=true;
        // this._loader.waitCall=callback;
        // this._loader.loadXML(url);
        ajax.get(url, callback);
      };
      // I didn't found some use of _v and _a functions
      /* returns xml node value
          @param node
              xml node
      */
      DataProcessor.prototype._v = function (node) {
        if (node.firstChild) {
          return node.firstChild.nodeValue;
        }
        return "";
      };
      /* returns values array of xml nodes array
          @param arr
              array of xml nodes
      */
      DataProcessor.prototype._a = function (arr) {
        var res = [];
        for (var i = 0; i < arr.length; i++) {
          res[i] = this._v(arr[i]);
        }
        return res;
      };
      /* loads updates and processes them
      */
      DataProcessor.prototype.loadUpdate = function () {
        var _this = this;
        var ajax = this.$gantt.ajax;
        var version = this.$gantt.getUserData(0, "version");
        var url = this.serverProcessor + ajax.urlSeparator(this.serverProcessor) + ["dhx_user=" + this._user, "dhx_version=" + version].join("&");
        url = url.replace("editing=true&", "");
        this.getUpdates(url, function (xml) {
          var vers = ajax.xpath("//userdata", xml);
          _this.obj.setUserData(0, "version", _this._v(vers[0]));
          var upds = ajax.xpath("//update", xml);
          if (upds.length) {
            _this._silent_mode = true;
            for (var i = 0; i < upds.length; i++) {
              var status_1 = upds[i].getAttribute("status");
              var id = upds[i].getAttribute("id");
              var parent_1 = upds[i].getAttribute("parent");
              switch (status_1) {
                case "inserted":
                  _this.callEvent("insertCallback", [upds[i], id, parent_1]);
                  break;
                case "updated":
                  _this.callEvent("updateCallback", [upds[i], id, parent_1]);
                  break;
                case "deleted":
                  _this.callEvent("deleteCallback", [upds[i], id, parent_1]);
                  break;
              }
            }
            _this._silent_mode = false;
          }
          _this._updateBusy = false;
        });
      };
      DataProcessor.prototype.destructor = function () {
        this.callEvent("onDestroy", []);
        this.detachAllEvents();
        this.updatedRows = [];
        this._in_progress = {}; // ?
        this._invalid = {};
        this._headers = null;
        this._payload = null;
        delete this._initialized;
      };
      DataProcessor.prototype.setGanttMode = function (mode) {
        if (mode === "tasks") {
          mode = "task";
        }
        else if (mode === "links") {
          mode = "link";
        }
        var modes = this.modes || {};
        var ganttMode = this.getGanttMode();
        if (ganttMode) {
          modes[ganttMode] = {
            _in_progress: this._in_progress,
            _invalid: this._invalid,
            updatedRows: this.updatedRows
          };
        }
        var newState = modes[mode];
        if (!newState) {
          newState = modes[mode] = {
            _in_progress: {},
            _invalid: {},
            updatedRows: []
          };
        }
        this._in_progress = newState._in_progress;
        this._invalid = newState._invalid;
        this.updatedRows = newState.updatedRows;
        this.modes = modes;
        this._ganttMode = mode;
      };
      DataProcessor.prototype.getGanttMode = function () {
        return this._ganttMode;
      };
      DataProcessor.prototype._getRowData = function (id) {
        var task;
        if (this.getGanttMode() === "task") {
          task = this.$gantt.isTaskExists(id) ? this.$gantt.getTask(id) : { id: id };
        }
        else {
          task = this.$gantt.isLinkExists(id) ? this.$gantt.getLink(id) : { id: id };
        }
        task = this.$gantt.copy(task);
        var data = {};
        for (var key in task) {
          if (key.substr(0, 1) === "$") {
            continue;
          }
          var value = task[key];
          if (helpers.isDate(value)) {
            data[key] = this.$gantt.templates.xml_format !== this.$gantt.templates.format_date ? this.$gantt.templates.xml_format(value) : this.$gantt.templates.format_date(value);
          }
          else if (value === null) {
            data[key] = "";
          }
          else {
            data[key] = value;
          }
        }
        var taskTiming = this.$gantt._get_task_timing_mode(task);
        if (taskTiming.$no_start) {
          task.start_date = "";
          task.duration = "";
        }
        if (taskTiming.$no_end) {
          task.end_date = "";
          task.duration = "";
        }
        data[this.action_param] = this.$gantt.getUserData(id, this.action_param);
        return data;
      };
      DataProcessor.prototype._isFetchResult = function (result) {
        return result.body instanceof ReadableStream;
      };
      DataProcessor.prototype.setSerializeAsJSON = function (flag) {
        this._serializeAsJson = flag;
      };
      return DataProcessor;
    }());
    return { DataProcessor : DataProcessor };

  }

  dataProcessor = function () {

    var DataProcessor = this.DataProcessorJs;
    return {
      DEPRECATED_api: function (server) {
        return new (DataProcessor.DataProcessor)(server);
      },
      createDataProcessor: DataProcessor.createDataProcessor,
      getDataProcessorModes: DataProcessor.getAvailableModes
    };
  }

  autoscroll = function () {

    var domHelpers = this.helperService.domHelpers;

    return function (gantt) {

      var scrollRange = 50,
        scrollStep = 30,
        scrollDelay = 10,
        scrollSpeed = 50;

      var interval = null,
        isMove = false,
        delayTimeout = null,
        startPos: any = {
          started: false
        },
        eventPos: any = {};


      function isDisplayed(element) {
        return element &&
          domHelpers.isChildOf(element, gantt.$root) &&
          element.offsetHeight;
      }

      function getAutoscrollContainer() {
        var element;
        if (isDisplayed(gantt.$task)) {
          element = gantt.$task;
        } else if (isDisplayed(gantt.$grid)) {
          element = gantt.$grid;
        } else {
          element = gantt.$root;
        }

        return element;
      }

      function isScrollState() {
        var dragMarker = !!document.querySelector(".gantt_drag_marker");
        var isResize = !!document.querySelector(".gantt_drag_marker.gantt_grid_resize_area");
        var isLink = !!document.querySelector(".gantt_link_direction");
        var state = gantt.getState();
        var isClickDrag = state.autoscroll;
        isMove = dragMarker && !isResize && !isLink;

        return !((!state.drag_mode && !dragMarker) || isResize) || isClickDrag;
      }

      function defineDelayTimeout(state) {
        if (delayTimeout) {
          clearTimeout(delayTimeout);
          delayTimeout = null;
        }
        if (state) {
          var speed = gantt.config.autoscroll_speed;
          if (speed && speed < 10) // limit speed value to 10
            speed = 10;

          delayTimeout = setTimeout(function () {
            interval = setInterval(tick, speed || scrollSpeed);
          }, gantt.config.autoscroll_delay || scrollDelay);
        }
      }

      function defineScrollInterval(state) {
        if (state) {
          defineDelayTimeout(true);
          if (!startPos.started) {
            startPos.x = eventPos.x;
            startPos.y = eventPos.y;
            startPos.started = true;
          }
        } else {
          if (interval) {
            clearInterval(interval);
            interval = null;
          }
          defineDelayTimeout(false);
          startPos.started = false;
        }
      }

      function autoscrollInterval(event) {

        var isScroll = isScrollState();

        if ((interval || delayTimeout) && !isScroll) {
          defineScrollInterval(false);
        }

        if (!gantt.config.autoscroll || !isScroll) {
          return false;
        }

        eventPos = {
          x: event.clientX,
          y: event.clientY
        };

        if (!interval && isScroll) {
          defineScrollInterval(true);
        }
      }

      function tick() {

        if (!isScrollState()) {
          defineScrollInterval(false);
          return false;
        }

        var box = domHelpers.getNodePosition(getAutoscrollContainer());
        var posX = eventPos.x - box.x;
        var posY = eventPos.y - box.y;

        var scrollLeft = isMove ? 0 : need_scroll(posX, box.width, startPos.x - box.x);
        var scrollTop = need_scroll(posY, box.height, startPos.y - box.y);

        var scrollState = gantt.getScrollState();

        var currentScrollTop = scrollState.y,
          scrollOuterHeight = scrollState.inner_height,
          scrollInnerHeight = scrollState.height,
          currentScrollLeft = scrollState.x,
          scrollOuterWidth = scrollState.inner_width,
          scrollInnerWidth = scrollState.width;

        // do scrolling only if we have scrollable area to do so
        if (scrollTop && !scrollOuterHeight) {
          scrollTop = 0;
        } else if (scrollTop < 0 && !currentScrollTop) {
          scrollTop = 0;
        } else if (scrollTop > 0 && currentScrollTop + scrollOuterHeight >= scrollInnerHeight + 2) {
          scrollTop = 0;
        }

        if (scrollLeft && !scrollOuterWidth) {
          scrollLeft = 0;
        } else if (scrollLeft < 0 && !currentScrollLeft) {
          scrollLeft = 0;
        } else if (scrollLeft > 0 && currentScrollLeft + scrollOuterWidth >= scrollInnerWidth) {
          scrollLeft = 0;
        }

        var step = gantt.config.autoscroll_step;

        if (step && step < 2) // limit step value to 2
          step = 2;

        scrollLeft = scrollLeft * (step || scrollStep);
        scrollTop = scrollTop * (step || scrollStep);

        if (scrollLeft || scrollTop) {
          scroll(scrollLeft, scrollTop);
        }
      }

      function need_scroll(pos, boxSize, startCoord) {
        if ((pos - scrollRange < 0) && (pos < startCoord))
          return -1;
        else if ((pos > boxSize - scrollRange) && (pos > startCoord))
          return 1;
        return 0;
      }

      function scroll(left, top) {
        var scrollState = gantt.getScrollState();

        var scrollLeft = null,
          scrollTop = null;

        if (left) {
          scrollLeft = scrollState.x + left;
          scrollLeft = Math.min(scrollState.width, scrollLeft);
          scrollLeft = Math.max(0, scrollLeft);
        }

        if (top) {
          scrollTop = scrollState.y + top;
          scrollTop = Math.min(scrollState.height, scrollTop);
          scrollTop = Math.max(0, scrollTop);
        }

        gantt.scrollTo(scrollLeft, scrollTop);
      }

      gantt.attachEvent("onGanttReady", function () {
        gantt.eventRemove(document.body, "mousemove", autoscrollInterval);
        gantt.event(document.body, "mousemove", autoscrollInterval);
      });

    };
  }

  batchUpdate = function () {

    function createMethod(gantt) {
      var methods = {};
      var isActive = false;
      function disableMethod(methodName, dummyMethod) {
        dummyMethod = typeof dummyMethod == "function" ? dummyMethod : function () { };

        if (!methods[methodName]) {
          methods[methodName] = this[methodName];
          this[methodName] = dummyMethod;
        }
      }
      function restoreMethod(methodName) {
        if (methods[methodName]) {
          this[methodName] = methods[methodName];
          methods[methodName] = null;
        }
      }
      function disableMethods(methodsHash) {
        for (var i in methodsHash) {
          disableMethod.call(this, i, methodsHash[i]);
        }
      }
      function restoreMethods() {
        for (var i in methods) {
          restoreMethod.call(this, i);
        }
      }

      function batchUpdatePayload(callback) {
        try {
          callback();
        } catch (e) {
          window.console.error(e);
        }
      }

      var state = gantt.$services.getService("state");
      state.registerProvider("batchUpdate", function () {
        return {
          batch_update: isActive
        };
      }, true);

      return function batchUpdate(callback, noRedraw) {
        if (isActive) {
          // batch mode is already active
          batchUpdatePayload(callback);
          return;
        }

        var call_dp = (this._dp && this._dp.updateMode != "off");
        var dp_mode;
        if (call_dp) {
          dp_mode = this._dp.updateMode;
          this._dp.setUpdateMode("off");
        }

        // temporary disable some methods while updating multiple tasks
        var resetProjects = {};
        var methods = {
          "render": true,
          "refreshData": true,
          "refreshTask": true,
          "refreshLink": true,
          "resetProjectDates": function (task) {
            resetProjects[task.id] = task;
          }
        };

        disableMethods.call(this, methods);

        isActive = true;
        this.callEvent("onBeforeBatchUpdate", []);

        batchUpdatePayload(callback);

        this.callEvent("onAfterBatchUpdate", []);

        restoreMethods.call(this);

        // do required updates after changes applied
        for (var i in resetProjects) {
          this.resetProjectDates(resetProjects[i]);
        }

        isActive = false;

        if (!noRedraw) {
          this.render();
        }

        if (call_dp) {
          this._dp.setUpdateMode(dp_mode);
          this._dp.setGanttMode("task");
          this._dp.sendData();
          this._dp.setGanttMode("link");
          this._dp.sendData();
        }
      };
    }

    return function (gantt) {
      gantt.batchUpdate = createMethod(gantt);
    };
  }

  wbs = function () {

    var createWbs = (function (gantt) {
      return {
        _needRecalc: true,
        reset: function () {
          this._needRecalc = true;
        },
        _isRecalcNeeded: function () {
          return (!this._isGroupSort() && this._needRecalc);
        },
        _isGroupSort: function () {
          return !!(gantt._groups && gantt._groups.is_active());
        },
        _getWBSCode: function (task) {
          if (!task) return "";

          if (this._isRecalcNeeded()) {
            this._calcWBS();
          }

          if (task.$virtual) return "";
          if (this._isGroupSort()) return task.$wbs || "";

          if (!task.$wbs) {
            this.reset();
            this._calcWBS();
          }
          return task.$wbs;
        },
        _setWBSCode: function (task, value) {
          task.$wbs = value;
        },
        getWBSCode: function (task) {
          return this._getWBSCode(task);
        },
        getByWBSCode: function (code) {
          var parts = code.split(".");
          var currentNode = gantt.config.root_id;
          for (var i = 0; i < parts.length; i++) {
            var children = gantt.getChildren(currentNode);
            var index = parts[i] * 1 - 1;
            if (gantt.isTaskExists(children[index])) {
              currentNode = children[index];
            } else {
              return null;
            }
          }
          if (gantt.isTaskExists(currentNode)) {
            return gantt.getTask(currentNode);
          } else {
            return null;
          }
        },
        _calcWBS: function () {
          if (!this._isRecalcNeeded()) return;

          var _isFirst = true;
          gantt.eachTask(function (ch) {
            if (_isFirst) {
              _isFirst = false;
              this._setWBSCode(ch, "1");
              return;
            }
            var _prevSibling = gantt.getPrevSibling(ch.id);
            if (_prevSibling !== null) {
              var _wbs = gantt.getTask(_prevSibling).$wbs;
              if (_wbs) {
                _wbs = _wbs.split(".");
                _wbs[_wbs.length - 1]++;
                this._setWBSCode(ch, _wbs.join("."));
              }
            } else {
              var _parent = gantt.getParent(ch.id);
              this._setWBSCode(ch, gantt.getTask(_parent).$wbs + ".1");
            }
          }, gantt.config.root_id, this);

          this._needRecalc = false;
        }
      };
    });

    return function (gantt) {
      var wbs = createWbs(gantt);
      gantt.getWBSCode = function getWBSCode(task) {
        return wbs.getWBSCode(task);
      };

      gantt.getTaskByWBSCode = function (code) {
        return wbs.getByWBSCode(code);
      };

      function resetCache() {
        wbs.reset();
        return true;
      }

      gantt.attachEvent("onAfterTaskMove", resetCache);
      gantt.attachEvent("onBeforeParse", resetCache);
      gantt.attachEvent("onAfterTaskDelete", resetCache);
      gantt.attachEvent("onAfterTaskAdd", resetCache);
      gantt.attachEvent("onAfterSort", resetCache);

    };

  }

  jqueryHooks = function () {

    // if (window.jQuery) {

    //   (function ($) {

    //     var methods = [];
    //     $.fn.dhx_gantt = function (config) {
    //       config = config || {};
    //       if (typeof (config) === 'string') {
    //         if (methods[config]) {
    //           return methods[config].apply(this, []);
    //         } else {
    //           $.error('Method ' + config + ' does not exist on jQuery.dhx_gantt');
    //         }
    //       } else {
    //         var views = [];
    //         this.each(function () {
    //           if (this && this.getAttribute) {
    //             if (!this.gantt && !(window.gantt.$root == this)) {

    //               var newgantt = (window.gantt.$container && window.Gantt) ? window.Gantt.getGanttInstance() : window.gantt;
    //               for (var key in config)
    //                 if (key != "data")
    //                   newgantt.config[key] = config[key];

    //               newgantt.init(this);
    //               if (config.data)
    //                 newgantt.parse(config.data);

    //               views.push(newgantt);
    //             } else
    //               views.push(typeof this.gantt == "object" ? this.gantt : window.gantt);
    //           }
    //         });


    //         if (views.length === 1) return views[0];
    //         return views;
    //       }
    //     };

    //   })(window.jQuery);

    // }

    return null;
  }

  dhtmlxHooks = function () {

    // if (window.dhtmlx) {

    //   if (!window.dhtmlx.attaches)
    //     window.dhtmlx.attaches = {};

    //   window.dhtmlx.attaches.attachGantt = function (start, end, gantt) {
    //     var obj = document.createElement("DIV");

    //     gantt = gantt || window.gantt;

    //     obj.id = "gantt_" + gantt.uid();
    //     obj.style.width = "100%";
    //     obj.style.height = "100%";
    //     obj.cmp = "grid";

    //     document.body.appendChild(obj);
    //     this.attachObject(obj.id);
    //     this.dataType = "gantt";
    //     this.dataObj = gantt;

    //     var that = this.vs[this.av];
    //     that.grid = gantt;

    //     gantt.init(obj.id, start, end);
    //     obj.firstChild.style.border = "none";

    //     that.gridId = obj.id;
    //     that.gridObj = obj;

    //     var method_name = "_viewRestore";
    //     return this.vs[this[method_name]()].grid;
    //   };

    // }
    // if (typeof (window.dhtmlXCellObject) != "undefined") {

    //   window.dhtmlXCellObject.prototype.attachGantt = function (start, end, gantt) {
    //     gantt = gantt || window.gantt;

    //     var obj: any = document.createElement("DIV");
    //     obj.id = "gantt_" + gantt.uid();
    //     obj.style.width = "100%";
    //     obj.style.height = "100%";
    //     obj.cmp = "grid";

    //     document.body.appendChild(obj);
    //     this.attachObject(obj.id);

    //     this.dataType = "gantt";
    //     this.dataObj = gantt;

    //     gantt.init(obj.id, start, end);
    //     obj.firstChild.style.border = "none";

    //     obj = null;
    //     this.callEvent("_onContentAttach", []);

    //     return this.dataObj;
    //   };
    // }

    return null;

  }

  resources = function () {

    var helpers = this.helperService;
    var smartRender = this.uiService.smartRenderJs;

    function createResourceMethods(gantt) {

      var resourceTaskCache = {};

      gantt.$data.tasksStore.attachEvent("onStoreUpdated", function () {
        resourceTaskCache = {};
      });

      function getTaskBy(propertyName, propertyValue) {
        if (typeof propertyName == "function") {
          return filterResourceTasks(propertyName);
        } else {
          if (helpers.isArray(propertyValue)) {
            return getResourceTasks(propertyName, propertyValue);
          } else {
            return getResourceTasks(propertyName, [propertyValue]);
          }
        }
      }

      function filterResourceTasks(filter) {
        var res = [];
        gantt.eachTask(function (task) {
          if (filter(task)) {
            res.push(task);
          }
        });
        return res;
      }

      var falsyValuePreffix = String(Math.random());
      function resourceHashFunction(value) {
        if (value === null) {
          return falsyValuePreffix + String(value);
        }
        return String(value);
      }

      function getResourceTasks(property, resourceIds) {
        var res;
        var cacheKey = resourceIds.join("_") + "_" + property;
        var resourceHash = {};
        helpers.forEach(resourceIds, function (resourceId) {
          resourceHash[resourceHashFunction(resourceId)] = true;
        });

        if (!resourceTaskCache[cacheKey]) {
          res = resourceTaskCache[cacheKey] = [];
          gantt.eachTask(function (task) {
            if (task.type == gantt.config.types.project) return;
            if (property in task) {
              var resourceValue;
              if (!helpers.isArray(task[property])) {
                resourceValue = [task[property]];
              } else {
                resourceValue = task[property];
              }
              helpers.forEach(resourceValue, function (value) {
                if (resourceHash[resourceHashFunction(value)] || (value && resourceHash[resourceHashFunction(value.resource_id)])) {
                  res.push(task);
                }
              });

            }
          });
        } else {
          res = resourceTaskCache[cacheKey];
        }

        return res;
      }

      function getResourceLoad(resource, resourceProperty, scale, timeline) {
        var cacheKey = resource.id + "_" + resourceProperty + "_" + scale.unit + "_" + scale.step;
        var res;
        if (!resourceTaskCache[cacheKey]) {
          res = resourceTaskCache[cacheKey] = calculateResourceLoad(resource, resourceProperty, scale, timeline);

        } else {
          res = resourceTaskCache[cacheKey];
        }
        return res;
      }

      function calculateResourceLoad(resource, resourceProperty, scale, timeline) {

        var tasks;
        if (resource.$role == "task") {
          tasks = [];
        } else {
          tasks = getTaskBy(resourceProperty, resource.id);
        }
        var step = scale.unit;
        var timegrid = {};

        for (var i = 0; i < tasks.length; i++) {
          var task = tasks[i];

          var currDate = gantt.date[step + "_start"](new Date(task.start_date));

          while (currDate < task.end_date) {

            var date = currDate;
            currDate = gantt.date.add(currDate, 1, step);

            if (!gantt.isWorkTime({ date: date, task: task, unit: step })) {
              continue;
            }

            var timestamp = date.valueOf();
            if (!timegrid[timestamp]) {
              timegrid[timestamp] = [];
            }

            timegrid[timestamp].push(task);
          }
        }

        var timetable = [];
        var start, end, tasks;
        var config = timeline.$getConfig();

        for (var i = 0; i < scale.trace_x.length; i++) {
          start = new Date(scale.trace_x[i]);
          end = gantt.date.add(start, 1, step);
          tasks = timegrid[start.valueOf()] || [];
          if (tasks.length || config.resource_render_empty_cells) {
            timetable.push({
              start_date: start,
              end_date: end,
              tasks: tasks
            });
          }

        }

        return timetable;
      }

      function isInViewPort(item, view, viewport) {
        var position = view.getItemTop(item.id);
        var height = view.getItemHeight(item);
        if (viewport.y > position + height || viewport.y_end < position) {
          return false;
        } else {
          return true;
        }
      }

      function generateRenderResourceLine() {
        function renderResourceLine(resource, timeline, viewport) {
          if (!isInViewPort(resource, timeline, viewport)) {
            return null;
          }
          var config = timeline.$getConfig(),
            templates = timeline.$getTemplates();
          var timetable = getResourceLoad(resource, config.resource_property, timeline.getScale(), timeline);

          var cells = [];
          for (var i = 0; i < timetable.length; i++) {

            var day = timetable[i];

            var css = templates.resource_cell_class(day.start_date, day.end_date, resource, day.tasks);
            var content = templates.resource_cell_value(day.start_date, day.end_date, resource, day.tasks);

            if (css || content) {
              var sizes = timeline.getItemPosition(resource, day.start_date, day.end_date);
              var el = document.createElement('div');
              el.className = ["gantt_resource_marker", css].join(" ");

              el.style.cssText = [
                'left:' + sizes.left + 'px',
                'width:' + sizes.width + 'px',
                'height:' + (config.row_height - 1) + 'px',
                'line-height:' + (config.row_height - 1) + 'px',
                'top:' + sizes.top + 'px'
              ].join(";");

              if (content)
                el.innerHTML = content;

              cells.push(el);
            }

          }

          var row = null;
          if (cells.length) {
            row = document.createElement("div");
            for (var i = 0; i < cells.length; i++) {
              row.appendChild(cells[i]);
            }
          }

          return row;
        }
        return smartRender(renderResourceLine, function () { }, isInViewPort);
      }

      function renderBar(level, start, end, timeline) {
        var top = (1 - (level * 1 || 0)) * 100;
        var left = timeline.posFromDate(start);
        var right = timeline.posFromDate(end);
        var element = document.createElement("div");
        element.className = "gantt_histogram_hor_bar";
        element.style.top = top + '%';
        element.style.left = left + "px";
        element.style.width = (right - left + 1) + "px";
        return element;
      }
      function renderConnection(prevLevel, nextLevel, left) {
        if (prevLevel === nextLevel) {
          return null;
        }

        var top = 1 - Math.max(prevLevel, nextLevel);
        var height = Math.abs(prevLevel - nextLevel);
        var element = document.createElement("div");
        element.className = "gantt_histogram_vert_bar";
        element.style.top = top * 100 + "%";
        element.style.height = height * 100 + "%";
        element.style.left = left + "px";

        return element;
      }

      function isColumnVisible(columnIndex, scale, viewPort) {
        var width = scale.width[columnIndex];
        var cellLeftCoord = scale.left[columnIndex] - width;
        var cellRightCoord = scale.left[columnIndex] + width;
        return (width > 0 && cellLeftCoord <= viewPort.x_end && cellRightCoord >= viewPort.x);//do not render skipped columns
      }



      function generateRenderResourceHistogram() {

        var renderedHistogramCells = {};
        var renderedHistogramRows = {};

        function renderHistogramLine(capacity, timeline, maxCapacity, viewPort) {
          var scale = timeline.getScale();

          var el = document.createElement("div");

          for (var i = 0; i < scale.trace_x.length; i++) {
            if (!isColumnVisible(i, scale, viewPort)) {
              continue;
            }

            var colStart = scale.trace_x[i];
            var colEnd = scale.trace_x[i + 1] || gantt.date.add(colStart, scale.step, scale.unit);
            var col = scale.trace_x[i].valueOf();
            var level = Math.min(capacity[col] / maxCapacity, 1) || 0;
            // do not render histogram for lines with below zero capacity, as it's reserved for folders
            if (level < 0) {
              return null;
            }

            var nextLevel = Math.min(capacity[colEnd.valueOf()] / maxCapacity, 1) || 0;
            var bar = renderBar(level, colStart, colEnd, timeline);
            if (bar) {
              el.appendChild(bar);
            }
            var connection = renderConnection(level, nextLevel, timeline.posFromDate(colEnd));
            if (connection) {
              el.appendChild(connection);
            }

          }
          return el;
        }

        function renderResourceHistogram(resource, timeline, viewport) {
          if (!isInViewPort(resource, timeline, viewport)) {
            return null;
          }
          var config = timeline.$getConfig(),
            templates = timeline.$getTemplates();
          var scale = timeline.getScale();
          var timetable = getResourceLoad(resource, config.resource_property, scale, timeline);

          var cells = [];
          var capacityMatrix = {};
          var maxCapacity = resource.capacity || timeline.$config.capacity || 24;
          renderedHistogramCells[resource.id] = {};
          renderedHistogramRows[resource.id] = null;
          for (var i = 0; i < timetable.length; i++) {

            var day = timetable[i];
            var columnIndex = scale.trace_indexes[day.start_date.valueOf()];
            if (!isColumnVisible(columnIndex, scale, viewport)) {
              continue;
            }

            var css = templates.histogram_cell_class(day.start_date, day.end_date, resource, day.tasks);
            var content = templates.histogram_cell_label(day.start_date, day.end_date, resource, day.tasks);
            var fill = templates.histogram_cell_allocated(day.start_date, day.end_date, resource, day.tasks);
            var capacity = templates.histogram_cell_capacity(day.start_date, day.end_date, resource, day.tasks);
            capacityMatrix[day.start_date.valueOf()] = capacity || 0;
            if (css || content) {
              var sizes = timeline.getItemPosition(resource, day.start_date, day.end_date);
              var el = document.createElement('div');
              el.className = ["gantt_histogram_cell", css].join(" ");

              el.style.cssText = [
                'left:' + sizes.left + 'px',
                'width:' + sizes.width + 'px',
                'height:' + (config.row_height - 1) + 'px',
                'line-height:' + (config.row_height - 1) + 'px',
                'top:' + (sizes.top + 1) + 'px'
              ].join(";");


              if (content) {
                content = "<div class='gantt_histogram_label'>" + content + "</div>";
              }

              if (fill) {
                content = "<div class='gantt_histogram_fill' style='height:" + (Math.min(fill / maxCapacity || 0, 1) * 100) + "%;'></div>" + content;
              }

              if (content) {
                el.innerHTML = content;
              }

              cells.push(el);
              renderedHistogramCells[resource.id][columnIndex] = el;
            }

          }

          var row = null;
          if (cells.length) {
            row = document.createElement("div");
            for (var i = 0; i < cells.length; i++) {
              row.appendChild(cells[i]);
            }

            var capacityElement: any = renderHistogramLine(capacityMatrix, timeline, maxCapacity, viewport);

            if (capacityElement) {
              capacityElement.setAttribute("data-resource-id", resource.id);
              capacityElement.style.position = "absolute";
              capacityElement.style.top = (sizes.top + 1) + "px";
              capacityElement.style.height = (config.row_height - 1) + "px";
              capacityElement.style.left = 0;
              row.appendChild(capacityElement);
            }

            renderedHistogramRows[resource.id] = row;
          }

          return row;
        }

        return smartRender(renderResourceHistogram, function () { }, isInViewPort);
      }


      function selectAssignments(resourceId, taskId, result) {
        var property = gantt.config.resource_property;
        var owners = [];
        if (gantt.getDatastore("task").exists(taskId)) {
          var task = gantt.getTask(taskId);
          owners = task[property] || [];
        }

        if (!Array.isArray(owners)) {
          owners = [owners];
        }
        for (var i = 0; i < owners.length; i++) {
          if (owners[i].resource_id == resourceId) {
            result.push({ task_id: task.id, resource_id: owners[i].resource_id, value: owners[i].value });
          }
        }
      }

      function getResourceAssignments(resourceId, taskId) {
        // resource assignment as an independent module:
        // {taskId:, resourceId, value}
        // TODO: probably should add a separate datastore for these
        var assignments = [];
        var property = gantt.config.resource_property;
        if (taskId !== undefined) {
          selectAssignments(resourceId, taskId, assignments);
        } else {
          var tasks = gantt.getTaskBy(property, resourceId);
          tasks.forEach(function (task) {
            selectAssignments(resourceId, task.id, assignments);
          });
        }
        return assignments;
      }

      return {
        renderLine: generateRenderResourceLine,
        renderHistogram: generateRenderResourceHistogram,
        filterTasks: getTaskBy,
        getResourceAssignments: getResourceAssignments
      };
    }

    return function (gantt) {
      var methods = createResourceMethods(gantt);

      gantt.getTaskBy = methods.filterTasks;
      gantt.getResourceAssignments = methods.getResourceAssignments;
      gantt.$ui.layers.resourceRow = methods.renderLine;
      gantt.$ui.layers.resourceHistogram = methods.renderHistogram;
      gantt.config.resource_property = "owner_id";
      gantt.config.resource_store = "resource";
      gantt.config.resource_render_empty_cells = false;

      /**
       * these are placeholder functions that should be redefined by the user
      */
      gantt.templates.histogram_cell_class = function (start_date, end_date, resource, tasks) { };
      gantt.templates.histogram_cell_label = function (start_date, end_date, resource, tasks) {
        return tasks.length + "/3";
      };
      gantt.templates.histogram_cell_allocated = function (start_date, end_date, resource, tasks) {
        return tasks.length / 3;
      };
      gantt.templates.histogram_cell_capacity = function (start_date, end_date, resource, tasks) {
        return 0;
      };



      gantt.templates.resource_cell_class = function (start, end, resource, tasks) {
        var css = "";
        if (tasks.length <= 1) {
          css = "gantt_resource_marker_ok";
        } else {
          css = "gantt_resource_marker_overtime";
        }
        return css;
      };

      gantt.templates.resource_cell_value = function (start, end, resource, tasks) {
        return tasks.length * 8;
      };
    };
  }

  newTaskPlaceholder = function () {

    return function addPlaceholder(gantt) {
      function isEnabled() {
        return gantt.config.placeholder_task;
      }

      function callIfEnabled(callback) {
        return function () {
          if (!isEnabled()) {
            return true;
          }
          return callback.apply(this, arguments);
        };
      }

      function silenceDataProcessor(dataProcessor) {
        if (dataProcessor && !dataProcessor._silencedPlaceholder) {
          dataProcessor._silencedPlaceholder = true;
          dataProcessor.attachEvent("onBeforeUpdate", callIfEnabled(function (id, state, data) {
            if (data.type == gantt.config.types.placeholder) {
              dataProcessor.setUpdated(id, false);
              return false;
            }
            return true;
          }));
        }
      }

      function insertPlaceholder() {
        var placeholders = gantt.getTaskBy("type", gantt.config.types.placeholder);
        if (!placeholders.length || !gantt.isTaskExists(placeholders[0].id)) {
          var placeholder = {
            unscheduled: true,
            type: gantt.config.types.placeholder,
            duration: 0,
            text: gantt.locale.labels.new_task
          };
          if (gantt.callEvent("onTaskCreated", [placeholder]) === false) {
            return;
          }

          gantt.addTask(placeholder);

        }
      }

      function afterEdit(id) {
        var item = gantt.getTask(id);
        if (item.type == gantt.config.types.placeholder) {
          if (item.start_date && item.end_date && item.unscheduled) {
            item.unscheduled = false;
          }

          gantt.batchUpdate(function () {
            var newTask = gantt.copy(item);
            gantt.silent(function () {
              gantt.deleteTask(item.id);
            });

            delete newTask["!nativeeditor_status"];
            newTask.type = gantt.config.types.task;
            newTask.id = gantt.uid();
            gantt.addTask(newTask);

            //insertPlaceholder();
          });

        }
      }

      gantt.config.types.placeholder = "placeholder";
      gantt.attachEvent("onDataProcessorReady", callIfEnabled(silenceDataProcessor));

      var ready = false;
      gantt.attachEvent("onGanttReady", function () {
        if (ready) {
          return;
        }
        ready = true;
        gantt.attachEvent("onAfterTaskUpdate", callIfEnabled(afterEdit));
        gantt.attachEvent("onAfterTaskAdd", callIfEnabled(function (id, task) {
          if (task.type != gantt.config.types.placeholder) {
            var placeholders = gantt.getTaskBy("type", gantt.config.types.placeholder);
            placeholders.forEach(function (p) {
              gantt.silent(function () {
                if (gantt.isTaskExists(p.id))
                  gantt.deleteTask(p.id);
              });
            });
            insertPlaceholder();
          }
        }));
        gantt.attachEvent("onParse", callIfEnabled(insertPlaceholder));
      });

      gantt.attachEvent("onBeforeUndoStack", function (action) {
        for (var i = 0; i < action.commands.length; i++) {
          var command = action.commands[i];
          if (command.entity === "task" && command.value.type === gantt.config.types.placeholder) {
            action.commands.splice(i, 1);
            i--;
          }
        }
        return true;
      });

    };

  }

  autoTaskTypes = function () {

    return function (gantt) {
      function isEnabled() {
        return gantt.config.auto_types && // if enabled
          (gantt.getTaskType(gantt.config.types.project) == gantt.config.types.project);// and supported
      }

      function callIfEnabled(callback) {
        return function () {
          if (!isEnabled()) {
            return true;
          }
          return callback.apply(this, arguments);
        };
      }

      function updateParents(childId) {
        gantt.batchUpdate(function () {
          checkParent(childId);
        });
      }

      var delTaskParent;

      function checkParent(id) {
        setTaskType(id);
        var parent = gantt.getParent(id);

        if (parent != gantt.config.root_id) {
          checkParent(parent);
        }
      }

      function setTaskType(id) {
        id = id.id || id;
        var task = gantt.getTask(id);
        var targetType = getTaskTypeToUpdate(task);

        if (targetType !== false) {
          updateTaskType(task, targetType);
        }
      }

      function updateTaskType(task, targetType) {
        task.type = targetType;
        gantt.updateTask(task.id);
      }

      function getTaskTypeToUpdate(task) {
        var allTypes = gantt.config.types;
        var hasChildren = gantt.hasChild(task.id);
        var taskType = gantt.getTaskType(task.type);

        if (hasChildren && taskType === allTypes.task) {
          return allTypes.project;
        }

        if (!hasChildren && taskType === allTypes.project) {
          return allTypes.task;
        }

        return false;
      }

      var isParsingDone = true;

      gantt.attachEvent("onParse", callIfEnabled(function () {
        isParsingDone = false;

        gantt.batchUpdate(function () {
          gantt.eachTask(function (task) {
            var targetType = getTaskTypeToUpdate(task);
            if (targetType !== false) {
              updateTaskType(task, targetType);
            }
          });
        });

        isParsingDone = true;
      }));

      gantt.attachEvent("onAfterTaskAdd", callIfEnabled(function (id) {
        if (isParsingDone) {
          updateParents(id);
        }
      }));

      gantt.attachEvent("onAfterTaskUpdate", callIfEnabled(function (id) {
        if (isParsingDone) {
          updateParents(id);
        }
      }));

      function updateAfterRemoveChild(id) {
        if (id != gantt.config.root_id && gantt.isTaskExists(id)) {
          updateParents(id);
        }
      }

      gantt.attachEvent("onBeforeTaskDelete", callIfEnabled(function (id, task) {
        delTaskParent = gantt.getParent(id);
        return true;
      }));

      gantt.attachEvent("onAfterTaskDelete", callIfEnabled(function (id, task) {
        updateAfterRemoveChild(delTaskParent);
      }));


      var originalRowDndParent;

      gantt.attachEvent("onRowDragStart", callIfEnabled(function (id, target, e) {
        originalRowDndParent = gantt.getParent(id);
        return true;
      }));

      gantt.attachEvent("onRowDragEnd", callIfEnabled(function (id, target) {
        updateAfterRemoveChild(originalRowDndParent);
        updateParents(id);
      }));

      var originalMoveTaskParent;

      gantt.attachEvent("onBeforeTaskMove", callIfEnabled(function (sid, parent, tindex) {
        originalMoveTaskParent = gantt.getParent(sid);
        return true;
      }));

      gantt.attachEvent("onAfterTaskMove", callIfEnabled(function (id, parent, tindex) {
        if (document.querySelector(".gantt_drag_marker")) {
          // vertical dnd in progress
          return;
        }
        updateAfterRemoveChild(originalMoveTaskParent);
        updateParents(id);
      }));
    };

  }

  timelineZoom = function () {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    var env = this.constantService.env;
    var eventable = this.eventableService;
    var USE_KEY = ["ctrlKey", "altKey", "shiftKey", "metaKey"];
    var _defaultScales = [
      [
        {
          unit: "month",
          date: "%M",
          step: 1
        },
        {
          unit: "day",
          date: "%d",
          step: 1
        }
      ],
      [
        {
          unit: "day",
          date: "%d %M",
          step: 1
        }
      ],
      [
        {
          unit: "day",
          date: "%d %M",
          step: 1
        },
        {
          unit: "hour",
          date: "%H:00",
          step: 8
        },
      ],
      [
        {
          unit: "day",
          date: "%d %M",
          step: 1
        },
        {
          unit: "hour",
          date: "%H:00",
          step: 1
        },
      ],
    ];
    var TimelineZoom = /** @class */ (function () {
      function TimelineZoom(gantt) {
        var _this = this;
        this.zoomIn = function () {
          var index = _this.getCurrentLevel() - 1;
          if (index < 0) {
            return;
          }
          _this.setLevel(index);
        };
        this.zoomOut = function () {
          var index = _this.getCurrentLevel() + 1;
          if (index > _this._levels.length - 1) {
            return;
          }
          _this.setLevel(index);
        };
        this.getCurrentLevel = function () {
          return _this._activeLevelIndex;
        };
        this.getLevels = function () {
          return _this._levels;
        };
        this.setLevel = function (level) {
          var zoomLevel = _this._getZoomIndexByName(level);
          if (zoomLevel === -1) {
            _this.$gantt.assert(zoomLevel !== -1, "Invalid zoom level for gantt.ext.zoom.setLevel. " + level + " is not an expected value.");
          }
          _this._setLevel(zoomLevel, 0);
        };
        this._getZoomIndexByName = function (levelName) {
          var zoomLevel = -1;
          if (typeof levelName === "string") {
            if (!isNaN(Number(levelName)) && _this._levels[Number(levelName)]) {
              zoomLevel = Number(levelName);
            }
            else {
              for (var i = 0; i < _this._levels.length; i++) {
                if (_this._levels[i].name === levelName) {
                  zoomLevel = i;
                  break;
                }
              }
            }
          }
          else {
            zoomLevel = levelName;
          }
          return zoomLevel;
        };
        this._getVisibleDate = function () {
          var scrollPos = _this.$gantt.getScrollState().x;
          var viewPort = _this.$gantt.$task.offsetWidth;
          _this._visibleDate = _this.$gantt.dateFromPos(scrollPos + viewPort / 2);
        };
        this._setLevel = function (level, cursorOffset) {
          _this._activeLevelIndex = level;
          var gantt = _this.$gantt;
          var nextConfig = gantt.copy(_this._levels[_this._activeLevelIndex]);
          var chartConfig = gantt.copy(nextConfig);
          delete chartConfig.name;
          gantt.mixin(gantt.config, chartConfig, true);
          var isRendered = !!gantt.$root;
          if (isRendered) {
            if (cursorOffset) {
              var cursorDate = _this.$gantt.dateFromPos(cursorOffset + _this.$gantt.getScrollState().x);
              _this.$gantt.render();
              var newPosition = _this.$gantt.posFromDate(cursorDate);
              _this.$gantt.scrollTo(newPosition - cursorOffset);
            }
            else {
              var viewPort = _this.$gantt.$task.offsetWidth;
              if (!_this._visibleDate) {
                _this._getVisibleDate();
              }
              var middleDate = _this._visibleDate;
              _this.$gantt.render();
              var newPosition = _this.$gantt.posFromDate(middleDate);
              _this.$gantt.scrollTo(newPosition - viewPort / 2);
            }
            _this.callEvent("onAfterZoom", [_this._activeLevelIndex, nextConfig]);
          }
        };
        this._attachWheelEvent = function (config) {
          var event = env.isFF ? "wheel" : "mousewheel";
          var el;
          if (typeof config.element === "function") {
            el = config.element();
          }
          else {
            el = config.element;
          }
          if (!el) {
            return;
          }
          _this._eventAttached = _this.$gantt.event(el, event, function (e) {
            if (_this._useKey) {
              if (USE_KEY.indexOf(_this._useKey) < 0) {
                return false;
              }
              if (!e[_this._useKey]) {
                return false;
              }
            }
            if (typeof _this._handler === "function") {
              _this._handler.apply(_this, [e]);
              return true;
            }
          });
        };
        this._defaultHandler = function (e) {
          var timelineOffset = _this.$gantt.$task.getBoundingClientRect().x;
          var cursorOffset = e.clientX - timelineOffset;
          var wheelY = _this.$gantt.env.isFF ? (e.deltaY * -40) : e.wheelDelta;
          var wheelUp = false;
          if (wheelY > 0) {
            wheelUp = true;
          }
          e.preventDefault();
          e.stopPropagation();
          _this._setScaleSettings(wheelUp, cursorOffset);
        };
        this._setScaleDates = function () {
          if (_this._initialStartDate && _this._initialEndDate) {
            _this.$gantt.config.start_date = _this._initialStartDate;
            _this.$gantt.config.end_date = _this._initialEndDate;
          }
        };
        this.$gantt = gantt;
      }
      TimelineZoom.prototype.init = function (config) {
        var _this = this;
        this._initialStartDate = config.startDate;
        this._initialEndDate = config.endDate;
        this._activeLevelIndex = config.activeLevelIndex ? config.activeLevelIndex : 0;
        this._levels = this._mapScales(config.levels || _defaultScales);
        this._handler = config.handler || this._defaultHandler;
        this._minColumnWidth = config.minColumnWidth || 60;
        this._maxColumnWidth = config.maxColumnWidth || 240;
        this._widthStep = config.widthStep || 3 / 8 * config.minColumnWidth;
        this._useKey = config.useKey;
        if (!this._initialized) {
          eventable(this);
          this.$gantt.attachEvent("onGanttScroll", function () {
            _this._getVisibleDate();
          });
        }
        if (this._eventAttached) {
          this.$gantt.eventRemove(this._eventAttached);
        }
        if (config.trigger === "wheel") {
          if (this.$gantt.$root) {
            this._attachWheelEvent(config);
          }
          else {
            this.$gantt.attachEvent("onGanttReady", function () {
              _this._attachWheelEvent(config);
            });
          }
        }
        this._initialized = true;
        this.setLevel(this._activeLevelIndex);
      };
      TimelineZoom.prototype._mapScales = function (levels) {
        return levels.map(function (l) {
          if (Array.isArray(l)) {
            return {
              scales: l
            };
          }
          else {
            return l;
          }
        });
      };
      TimelineZoom.prototype._setScaleSettings = function (wheelUp, cursorOffset) {
        if (wheelUp) {
          this._stepUp(cursorOffset);
        }
        else {
          this._stepDown(cursorOffset);
        }
      };
      TimelineZoom.prototype._stepUp = function (cursorOffset) {
        if (this._activeLevelIndex >= this._levels.length - 1) {
          return;
        }
        var nextLevel = this._activeLevelIndex;
        this._setScaleDates();
        if (this._widthStep) {
          var newColumnWidth = this.$gantt.config.min_column_width + this._widthStep;
          if (newColumnWidth > this._maxColumnWidth) {
            newColumnWidth = this._minColumnWidth;
            nextLevel++;
          }
          this.$gantt.config.min_column_width = newColumnWidth;
        }
        else {
          nextLevel++;
        }
        this._setLevel(nextLevel, cursorOffset);
      };
      TimelineZoom.prototype._stepDown = function (cursorOffset) {
        if (this._activeLevelIndex < 1) {
          return;
        }
        var nextLevel = this._activeLevelIndex;
        this._setScaleDates();
        if (this._widthStep) {
          var newColumnWidth = this.$gantt.config.min_column_width - this._widthStep;
          if (newColumnWidth < this._minColumnWidth) {
            newColumnWidth = this._maxColumnWidth;
            nextLevel--;
          }
          this.$gantt.config.min_column_width = newColumnWidth;
        }
        else {
          nextLevel--;
        }
        this._setLevel(nextLevel, cursorOffset);
      };
      return TimelineZoom;
    }());
    return { default : TimelineZoom };
  }

  plugins = function (gantt) {

    return function (gantt) {
      if (!gantt.ext) {
        gantt.ext = {};
      }

      var modules = [
        this.autoscroll,
        this.batchUpdate,
        this.wbs,
        this.jqueryHooks,
        this.dhtmlxHooks,
        this.resources,
        this.newTaskPlaceholder,
        this.autoTaskTypes
      ];

      for (var i = 0; i < modules.length; i++) {
        if (modules[i])
          modules[i](gantt);
      }

      var TimelineZoom = this.timelineZoom.default;
      gantt.ext.zoom = new TimelineZoom(gantt);
    };

  }

  dynamicLoading = function (gantt) {

    return function (gantt) {
    };

  }

  gridColumnApi = function (gantt) {

    return function (gantt) {
      gantt.getGridColumn = function (name) {
        var columns = gantt.config.columns;

        for (var i = 0; i < columns.length; i++) {
          if (columns[i].name == name)
            return columns[i];
        }

        return null;
      };

      gantt.getGridColumns = function () {
        return gantt.config.columns.slice();
      };
    };

  }

  wai_aria = function (gantt) {

    return function (gantt) {
      // TODO: why eslint fails on regexp?
      // eslint-disable-next-line no-control-regex
      var htmlTags = new RegExp("<(?:.|\n)*?>", "gm");
      var extraSpaces = new RegExp(" +", "gm");

      function stripHTMLLite(htmlText) {
        return (htmlText + "")
          .replace(htmlTags, " ").
          replace(extraSpaces, " ");
      }

      var singleQuotes = new RegExp("'", "gm");
      function escapeQuotes(text) {
        return (text + "").replace(singleQuotes, "&#39;");
      }

      gantt._waiAria = {
        getAttributeString: function (attr) {
          var attributes = [" "];
          for (var i in attr) {
            var text = escapeQuotes(stripHTMLLite(attr[i]));
            attributes.push(i + "='" + text + "'");
          }
          attributes.push(" ");
          return attributes.join(" ");

        },

        getTimelineCellAttr: function (dateString) {

          return gantt._waiAria.getAttributeString({ "aria-label": dateString });
        },

        _taskCommonAttr: function (task, div) {

          if (!(task.start_date && task.end_date))
            return;

          div.setAttribute("aria-label", stripHTMLLite(gantt.templates.tooltip_text(task.start_date, task.end_date, task)));

          if (gantt.isReadonly(task)) {
            div.setAttribute("aria-readonly", true);
          }

          if (task.$dataprocessor_class) {
            div.setAttribute("aria-busy", true);
          }

          div.setAttribute("aria-selected", gantt.isSelectedTask(task.id) ? "true" : "false");
        },

        setTaskBarAttr: function (task, div) {
          this._taskCommonAttr(task, div);

          if (!gantt.isReadonly(task) && gantt.config.drag_move) {
            if (task.id != gantt.getState().drag_id) {
              div.setAttribute("aria-grabbed", false);
            } else {
              div.setAttribute("aria-grabbed", true);
            }
          }
        },

        taskRowAttr: function (task, div) {

          this._taskCommonAttr(task, div);

          if (!gantt.isReadonly(task) && gantt.config.order_branch) {
            div.setAttribute("aria-grabbed", false);
          }

          div.setAttribute("role", "row");

          div.setAttribute("aria-level", task.$level);

          if (gantt.hasChild(task.id)) {
            div.setAttribute("aria-expanded", task.$open ? "true" : "false");
          }
        },

        linkAttr: function (link, div) {

          var linkTypes = gantt.config.links;

          var toStart = link.type == linkTypes.finish_to_start || link.type == linkTypes.start_to_start;
          var fromStart = link.type == linkTypes.start_to_start || link.type == linkTypes.start_to_finish;

          var content = gantt.locale.labels.link + " " + gantt.templates.drag_link(link.source, fromStart, link.target, toStart);

          div.setAttribute("aria-label", stripHTMLLite(content));
          if (gantt.isReadonly(link)) {
            div.setAttribute("aria-readonly", true);
          }
        },

        gridSeparatorAttr: function (div) {
          div.setAttribute("role", "separator");
        },

        lightboxHiddenAttr: function (div) {
          div.setAttribute("aria-hidden", "true");
        },

        lightboxVisibleAttr: function (div) {
          div.setAttribute("aria-hidden", "false");
        },

        lightboxAttr: function (div) {
          div.setAttribute("role", "dialog");
          div.setAttribute("aria-hidden", "true");
          div.firstChild.setAttribute("role", "heading");
        },

        lightboxButtonAttrString: function (buttonName) {
          return this.getAttributeString({ "role": "button", "aria-label": gantt.locale.labels[buttonName], "tabindex": "0" });
        },

        lightboxHeader: function (div, headerText) {
          div.setAttribute("aria-label", headerText);
        },

        lightboxSelectAttrString: function (time_option) {
          var label = "";

          switch (time_option) {
            case "%Y":
              label = gantt.locale.labels.years;
              break;
            case "%m":
              label = gantt.locale.labels.months;
              break;
            case "%d":
              label = gantt.locale.labels.days;
              break;
            case "%H:%i":
              label = gantt.locale.labels.hours + gantt.locale.labels.minutes;
              break;
            default:
              break;
          }

          return gantt._waiAria.getAttributeString({ "aria-label": label });
        },

        lightboxDurationInputAttrString: function (section) {
          return this.getAttributeString({ "aria-label": gantt.locale.labels.column_duration, "aria-valuemin": "0" });
        },

        gridAttrString: function () {
          return [" role='treegrid'", gantt.config.multiselect ? "aria-multiselectable='true'" : "aria-multiselectable='false'", " "].join(" ");
        },


        gridScaleRowAttrString: function () {
          return "role='row'";
        },

        gridScaleCellAttrString: function (column, label) {
          var attrs = "";
          if (column.name == "add") {
            attrs = this.getAttributeString({ "role": "button", "aria-label": gantt.locale.labels.new_task });
          } else {

            var attributes = {
              "role": "columnheader",
              "aria-label": label
            };

            if (gantt._sort && gantt._sort.name == column.name) {
              if (gantt._sort.direction == "asc") {
                attributes["aria-sort"] = "ascending";
              } else {
                attributes["aria-sort"] = "descending";
              }
            }

            attrs = this.getAttributeString(attributes);
          }
          return attrs;
        },

        gridDataAttrString: function () {
          return "role='rowgroup'";
        },

        gridCellAttrString: function (column, textValue) {
          return this.getAttributeString({ "role": "gridcell", "aria-label": textValue });
        },

        gridAddButtonAttrString: function (column) {
          return this.getAttributeString({ "role": "button", "aria-label": gantt.locale.labels.new_task });
        },

        messageButtonAttrString: function (buttonLabel) {
          return "tabindex='0' role='button' aria-label='" + buttonLabel + "'";
        },

        messageInfoAttr: function (div) {
          div.setAttribute("role", "alert");
          //div.setAttribute("tabindex", "-1");
        },

        messageModalAttr: function (div, uid) {
          div.setAttribute("role", "dialog");
          if (uid) {
            div.setAttribute("aria-labelledby", uid);
          }

          //	div.setAttribute("tabindex", "-1");
        },

        quickInfoAttr: function (div) {
          div.setAttribute("role", "dialog");
        },

        quickInfoHeaderAttrString: function () {
          return " role='heading' ";
        },

        quickInfoHeader: function (div, header) {
          div.setAttribute("aria-label", header);
        },

        quickInfoButtonAttrString: function (label) {
          return gantt._waiAria.getAttributeString({ "role": "button", "aria-label": label, "tabindex": "0" });
        },

        tooltipAttr: function (div) {
          div.setAttribute("role", "tooltip");
        },

        tooltipVisibleAttr: function (div) {
          div.setAttribute("aria-hidden", "false");
        },

        tooltipHiddenAttr: function (div) {
          div.setAttribute("aria-hidden", "true");
        }
      };

      function isDisabled() {
        return !gantt.config.wai_aria_attributes;
      }

      for (var i in gantt._waiAria) {
        gantt._waiAria[i] = (function (payload) {
          return function () {
            if (isDisabled()) {
              return "";
            }
            return payload.apply(this, arguments);
          };
        })(gantt._waiAria[i]);
      }


    };

  }

  tasks = function (gantt) {

    return function (gantt) {
      gantt.isReadonly = function (item) {
        if (item && item[this.config.editable_property]) {
          return false;
        } else {
          return (item && item[this.config.readonly_property]) || this.config.readonly;
        }
      };
    };

  }

  load = function (gantt) {

    var helpers = this.helperService;

    return function (gantt) {

      gantt.load = function (url, type, callback) {
        this._load_url = url;
        this.assert(arguments.length, "Invalid load arguments");

        var tp = 'json', cl = null;
        if (arguments.length >= 3) {
          tp = type;
          cl = callback;
        } else {
          if (typeof arguments[1] == "string")
            tp = arguments[1];
          else if (typeof arguments[1] == "function")
            cl = arguments[1];
        }

        this._load_type = tp;

        this.callEvent("onLoadStart", [url, tp]);

        return this.ajax.get(url, gantt.bind(function (l) {
          this.on_load(l, tp);
          this.callEvent("onLoadEnd", [url, tp]);
          if (typeof cl == "function")
            cl.call(this);
        }, this));
      };
      gantt.parse = function (data, type) {
        this.on_load({ xmlDoc: { responseText: data } }, type);
      };

      gantt.serialize = function (type) {
        type = type || "json";
        return this[type].serialize();
      };

      /*
      tasks and relations
      {
      data:[
        {
          "id":"string",
          "text":"...",
          "start_date":"Date or string",
          "end_date":"Date or string",
          "duration":"number",
          "progress":"0..1",
          "parent_id":"string",
          "order":"number"
        },...],
      links:[
        {
          id:"string",
          source:"string",
          target:"string",
          type:"string"
        },...],
      collections:{
          collectionName:[
            {key:, label:, optional:...},...
          ],...
        }
      }
    
      * */

      gantt.on_load = function (resp, type) {
        this.callEvent("onBeforeParse", []);
        if (!type)
          type = "json";
        this.assert(this[type], "Invalid data type:'" + type + "'");

        var raw = resp.xmlDoc.responseText;

        var data = this[type].parse(raw, resp);
        this._process_loading(data);
      };

      gantt._process_loading = function (data) {
        if (data.collections)
          this._load_collections(data.collections);

        this.$data.tasksStore.parse(data.data);
        var links = data.links || (data.collections ? data.collections.links : []);
        this.$data.linksStore.parse(links);

        //this._sync_links();
        this.callEvent("onParse", []);
        this.render();
        if (this.config.initial_scroll) {
          var firstTask = this.getTaskByIndex(0);
          var id = firstTask ? firstTask.id : this.config.root_id;
          if (this.isTaskExists(id))
            this.showTask(id);
        }
      };


      gantt._load_collections = function (collections) {
        var collections_loaded = false;
        for (var key in collections) {
          if (collections.hasOwnProperty(key)) {
            collections_loaded = true;
            var collection = collections[key];
            var arr = this.serverList[key];
            if (!arr) continue;
            arr.splice(0, arr.length); //clear old options
            for (var j = 0; j < collection.length; j++) {
              var option = collection[j];
              var obj = this.copy(option);
              obj.key = obj.value;// resulting option object

              for (var option_key in option) {
                if (option.hasOwnProperty(option_key)) {
                  if (option_key == "value" || option_key == "label")
                    continue;
                  obj[option_key] = option[option_key]; // obj['value'] = option['value']
                }
              }
              arr.push(obj);
            }
          }
        }
        if (collections_loaded)
          this.callEvent("onOptionsLoad", []);
      };

      gantt.attachEvent("onBeforeTaskDisplay", function (id, task) {
        return !task.$ignore;
      });

      gantt.json = {
        parse: function (data) {
          gantt.assert(data, "Invalid data");

          if (typeof data == "string") {
            if (window/*.JSON*/)
              data = JSON.parse(data);
            else {
              gantt.assert(false, "JSON is not supported");
            }
          }

          if (data.dhx_security)
            gantt.security_key = data.dhx_security;
          return data;
        },
        serializeTask: function (task) {
          return this._copyObject(task);
        },
        serializeLink: function (link) {
          return this._copyLink(link);
        },
        _copyLink: function (obj) {
          var copy = {};
          for (var key in obj)
            copy[key] = obj[key];
          return copy;
        },
        _copyObject: function (obj) {
          var copy = {};
          for (var key in obj) {
            if (key.charAt(0) == "$")
              continue;
            copy[key] = obj[key];

            if (helpers.isDate(copy[key])) {
              copy[key] = gantt.templates.xml_format !== gantt.templates.formate_date ? gantt.templates.xml_format(copy[key]) : gantt.templates.formate_date(copy[key]);
            }
          }
          return copy;
        },
        serialize: function () {
          var tasks = [];
          var links = [];

          gantt.eachTask(function (obj) {
            gantt.resetProjectDates(obj);
            tasks.push(this.serializeTask(obj));
          }, gantt.config.root_id, this);

          var rawLinks = gantt.getLinks();
          for (var i = 0; i < rawLinks.length; i++) {
            links.push(this.serializeLink(rawLinks[i]));
          }

          return {
            data: tasks,
            links: links
          };
        }
      };

      /*
      <data>
        <task id:"some" parent_id="0" progress="0.5">
          <text>My task 1</text>
          <start_date>16.08.2013</start_date>
          <end_date>22.08.2013</end_date>
        </task>
        <coll_options>
          <links>
            <link source='a1' target='b2' type='c3' />
          </links>
        </coll_options>
      </data>
      */

      gantt.xml = {
        _xmlNodeToJSON: function (node, attrs_only) {
          var t: any = {};
          for (var i = 0; i < node.attributes.length; i++)
            t[node.attributes[i].name] = node.attributes[i].value;

          if (!attrs_only) {
            for (var i = 0; i < node.childNodes.length; i++) {
              var child = node.childNodes[i];
              if (child.nodeType == 1)
                t[child.tagName] = child.firstChild ? child.firstChild.nodeValue : "";
            }

            if (!t.text) t.text = node.firstChild ? node.firstChild.nodeValue : "";
          }

          return t;
        },
        _getCollections: function (loader) {
          var collection = {};
          var opts = gantt.ajax.xpath("//coll_options", loader);
          for (var i = 0; i < opts.length; i++) {
            var bind = opts[i].getAttribute("for");
            var arr = collection[bind] = [];
            var itms = gantt.ajax.xpath(".//item", opts[i]);
            for (var j = 0; j < itms.length; j++) {
              var itm = itms[j];
              var attrs = itm.attributes;
              var obj = { key: itms[j].getAttribute("value"), label: itms[j].getAttribute("label") };
              for (var k = 0; k < attrs.length; k++) {
                var attr = attrs[k];
                if (attr.nodeName == "value" || attr.nodeName == "label")
                  continue;
                obj[attr.nodeName] = attr.nodeValue;
              }
              arr.push(obj);
            }
          }
          return collection;
        },
        _getXML: function (text, loader, toptag) {
          toptag = toptag || "data";
          if (!loader.getXMLTopNode) {
            loader = gantt.ajax.parse(loader);
          }

          var xml = gantt.ajax.xmltop(toptag, loader.xmlDoc);
          if (!xml || xml.tagName != toptag) throw "Invalid XML data";

          var skey = xml.getAttribute("dhx_security");
          if (skey)
            gantt.security_key = skey;

          return xml;
        },
        parse: function (text, loader) {
          loader = this._getXML(text, loader);
          var data: any = {};

          var evs = data.data = [];
          var xml = gantt.ajax.xpath("//task", loader);

          for (var i = 0; i < xml.length; i++)
            evs[i] = this._xmlNodeToJSON(xml[i]);

          data.collections = this._getCollections(loader);
          return data;
        },
        _copyLink: function (obj) {
          return "<item id='" + obj.id + "' source='" + obj.source + "' target='" + obj.target + "' type='" + obj.type + "' />";
        },
        _copyObject: function (obj) {
          return "<task id='" + obj.id + "' parent='" + (obj.parent || "") + "' start_date='" + obj.start_date + "' duration='" + obj.duration + "' open='" + (!!obj.open) + "' progress='" + obj.progress + "' end_date='" + obj.end_date + "'><![CDATA[" + obj.text + "]]></task>";
        },
        serialize: function () {
          var tasks = [];
          var links = [];

          var json = gantt.json.serialize();
          for (var i = 0, len = json.data.length; i < len; i++) {
            tasks.push(this._copyObject(json.data[i]));
          }
          for (var i = 0, len = json.links.length; i < len; i++) {
            links.push(this._copyLink(json.links[i]));
          }
          return "<data>" + tasks.join("") + "<coll_options for='links'>" + links.join("") + "</coll_options></data>";
        }
      };


      gantt.oldxml = {
        parse: function (text, loader) {
          loader = gantt.xml._getXML(text, loader, "projects");
          var data: any = { collections: { links: [] } };

          var evs = data.data = [];
          var xml = gantt.ajax.xpath("//task", loader);

          for (var i = 0; i < xml.length; i++) {
            evs[i] = gantt.xml._xmlNodeToJSON(xml[i]);
            var parent = xml[i].parentNode;

            if (parent.tagName == "project")
              evs[i].parent = "project-" + parent.getAttribute("id");
            else
              evs[i].parent = parent.parentNode.getAttribute("id");
          }

          xml = gantt.ajax.xpath("//project", loader);
          for (var i = 0; i < xml.length; i++) {
            var ev = gantt.xml._xmlNodeToJSON(xml[i], true);
            ev.id = "project-" + ev.id;
            evs.push(ev);
          }

          for (var i = 0; i < evs.length; i++) {
            var ev = evs[i];
            ev.start_date = ev.startdate || ev.est;
            ev.end_date = ev.enddate;
            ev.text = ev.name;
            ev.duration = ev.duration / 8;
            ev.open = 1;
            if (!ev.duration && !ev.end_date) ev.duration = 1;
            if (ev.predecessortasks)
              data.collections.links.push({
                target: ev.id,
                source: ev.predecessortasks,
                type: gantt.config.links.finish_to_start
              });
          }

          return data;
        },
        serialize: function () {
          gantt.message("Serialization to 'old XML' is not implemented");
        }
      };

      gantt.serverList = function (name, array) {
        if (array) {
          this.serverList[name] = array.slice(0);
        } else if (!this.serverList[name]) {
          this.serverList[name] = [];
        }
        return this.serverList[name];
      };

    };

  }

  calendarArgumentHelperJs = function () {

    var utils = this.helperService.utils;
    var helpers = this.helperService;


    function IsWorkTimeArgument(date, unit, task, id, calendar) {
      this.date = date;
      this.unit = unit;
      this.task = task;
      this.id = id;
      this.calendar = calendar;
      return this;
    }

    function ClosestWorkTimeArgument(date, dir, unit, task, id, calendar) {
      this.date = date;
      this.dir = dir;
      this.unit = unit;
      this.task = task;
      this.id = id;
      this.calendar = calendar;
      return this;
    }

    function CalculateEndDateArgument(start_date, duration, unit, step, task, id, calendar) {
      this.start_date = start_date;
      this.duration = duration;
      this.unit = unit;
      this.step = step;
      this.task = task;
      this.id = id;
      this.calendar = calendar;
      return this;
    }

    function GetDurationArgument(start, end, task, calendar?) {
      this.start_date = start;
      this.end_date = end;
      this.task = task;
      this.calendar = calendar;
      this.unit = null;
      this.step = null;
      return this;
    }

    var calendarArgumentsHelper = function (gantt) {
      return {
        getWorkHoursArguments: function () {
          var config = arguments[0];
          if (helpers.isDate(config)) {
            config = {
              date: config
            };
          } else {
            config = utils.mixin({}, config);
          }
          return config;
        },
        setWorkTimeArguments: function () {
          return arguments[0];
        },
        unsetWorkTimeArguments: function () {
          return arguments[0];
        },
        isWorkTimeArguments: function () {
          var config = arguments[0];
          if (config instanceof IsWorkTimeArgument) {
            return config;
          }

          var processedConfig;
          if (!config.date) {
            //IsWorkTimeArgument(date, unit, task, id, calendar)
            processedConfig = new this.IsWorkTimeArgument(arguments[0], arguments[1], arguments[2], null, arguments[3]);
          } else {
            processedConfig = new this.IsWorkTimeArgument(config.date, config.unit, config.task, null, config.calendar);
          }

          processedConfig.unit = processedConfig.unit || gantt.config.duration_unit;

          return processedConfig;
        },
        getClosestWorkTimeArguments: function (arg) {
          var config = arguments[0];
          if (config instanceof ClosestWorkTimeArgument)
            return config;

          var processedConfig;
          if (helpers.isDate(config)) {
            processedConfig = new this.ClosestWorkTimeArgument(config);

          } else {
            processedConfig = new this.ClosestWorkTimeArgument(
              config.date,
              config.dir,
              config.unit,
              config.task,
              null,//config.id,
              config.calendar
            );
          }

          if (config.id) {
            processedConfig.task = config;
          }
          processedConfig.dir = config.dir || 'any';
          processedConfig.unit = config.unit || gantt.config.duration_unit;

          return processedConfig;
        },

        _getStartEndConfig: function (param) {
          var argumentType = GetDurationArgument;
          var config;
          if (param instanceof argumentType)
            return param;

          if (helpers.isDate(param)) {
            config = argumentType(arguments[0], arguments[1], arguments[2], arguments[3]);
          } else {
            config = argumentType(param.start_date, param.end_date, param.task);
            if (param.id) {
              config.task = param;
            }
          }

          config.unit = config.unit || gantt.config.duration_unit;
          config.step = config.step || gantt.config.duration_step;
          config.start_date = config.start_date || config.start || config.date;

          return config;
        },

        getDurationArguments: function (start, end, unit, step) {
          return this._getStartEndConfig.apply(this, arguments);
        },

        hasDurationArguments: function (start, end, unit, step) {
          return this._getStartEndConfig.apply(this, arguments);
        },

        calculateEndDateArguments: function (start, duration, unit, step) {
          var config = arguments[0];
          if (config instanceof CalculateEndDateArgument)
            return config;

          var processedConfig;
          //CalculateEndDateArgument(start_date, duration, unit, step, task, id, calendar)
          if (helpers.isDate(config)) {
            processedConfig = new this.CalculateEndDateArgument(
              arguments[0],
              arguments[1],
              arguments[2],
              undefined,
              arguments[3],
              undefined,
              arguments[4]
            );

          } else {
            processedConfig = new this.CalculateEndDateArgument(
              config.start_date,
              config.duration,
              config.unit,
              config.step,
              config.task,
              null,//config.id,
              config.calendar
            );
          }
          if (config.id) {
            processedConfig.task = config;
          }

          processedConfig.unit = processedConfig.unit || gantt.config.duration_unit;
          processedConfig.step = processedConfig.step || gantt.config.duration_step;

          return processedConfig;
        }
      };
    };


    return calendarArgumentsHelper;

  }

  workunitMapCacheJs = function () {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    var WorkUnitsMapCache = /** @class */ (function () {
      function WorkUnitsMapCache() {
        this.clear();
      }
      WorkUnitsMapCache.prototype.getItem = function (unit, timestamp) {
        if (this._cache.has(unit)) {
          var unitCache = this._cache.get(unit);
          if (unitCache.has(timestamp)) {
            return unitCache.get(timestamp);
          }
        }
        return -1;
      };
      WorkUnitsMapCache.prototype.setItem = function (unit, timestamp, value) {
        if (!unit || !timestamp) {
          return;
        }
        var cache = this._cache;
        var unitCache;
        if (!cache.has(unit)) {
          unitCache = new Map();
          cache.set(unit, unitCache);
        }
        else {
          unitCache = cache.get(unit);
        }
        unitCache.set(timestamp, value);
      };
      WorkUnitsMapCache.prototype.clear = function () {
        this._cache = new Map();
      };
      return WorkUnitsMapCache;
    }());
    return { WorkUnitsMapCache : WorkUnitsMapCache };
  }

  workUnitObjectCacheJs = function () {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    var WorkUnitsObjectCache = /** @class */ (function () {
      function WorkUnitsObjectCache() {
        this.clear();
      }
      WorkUnitsObjectCache.prototype.getItem = function (unit, timestamp) {
        var cache = this._cache;
        if (cache && cache[unit]) {
          var units = cache[unit];
          if (units[timestamp] !== undefined) {
            return units[timestamp];
          }
        }
        return -1;
      };
      WorkUnitsObjectCache.prototype.setItem = function (unit, timestamp, value) {
        if (!unit || !timestamp) {
          return;
        }
        var cache = this._cache;
        if (!cache) {
          return;
        }
        if (!cache[unit]) {
          cache[unit] = {};
        }
        cache[unit][timestamp] = value;
      };
      WorkUnitsObjectCache.prototype.clear = function () {
        this._cache = {};
      };
      return WorkUnitsObjectCache;
    }());
    return { WorkUnitsObjectCache : WorkUnitsObjectCache };
  }

  cacheFactoryJs = function () {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    var workunit_map_cache_1 = this.workunitMapCacheJs;
    var workunit_object_cache_1 = this.workUnitObjectCacheJs;
    function createCacheObject() {
      // worktime hash is on the hot path,
      // Map seems to work faster than plain array, use it whenever possible
      if (typeof Map !== "undefined") {
        return new workunit_map_cache_1.WorkUnitsMapCache();
      }
      else {
        return new workunit_object_cache_1.WorkUnitsObjectCache();
      }
    }
    return  { createCacheObject : createCacheObject };
  }

  calendarStrategyJS = function () {

    var cacheFactory = this.cacheFactoryJs,
      utils = this.HelpersService.utils;

    function CalendarWorkTimeStrategy(gantt, argumentsHelper) {
      this.argumentsHelper = argumentsHelper;
      this.$gantt = gantt;
      this._workingUnitsCache = cacheFactory.createCacheObject();
    }

    CalendarWorkTimeStrategy.prototype = {
      units: [
        "year",
        "month",
        "week",
        "day",
        "hour",
        "minute"
      ],
      // cache previously calculated worktime
      _getUnitOrder: function (unit) {
        for (var i = 0, len = this.units.length; i < len; i++) {
          if (this.units[i] == unit)
            return i;
        }
      },
      _timestamp: function (settings) {

        var timestamp = null;
        if ((settings.day || settings.day === 0)) {
          timestamp = settings.day;
        } else if (settings.date) {
          // store worktime datestamp in utc so it could be recognized in different timezones (e.g. opened locally and sent to the export service in different timezone)
          timestamp = Date.UTC(settings.date.getFullYear(), settings.date.getMonth(), settings.date.getDate());
        }
        return timestamp;
      },
      _checkIfWorkingUnit: function (date, unit, order) {
        if (order === undefined) {
          order = this._getUnitOrder(unit);
        }

        // disable worktime check for custom time units
        if (order === undefined) {
          return true;
        }
        if (order) {
          //check if bigger time unit is a work time (hour < day < month...)
          //i.e. don't check particular hour if the whole day is marked as not working
          if (!this._isWorkTime(date, this.units[order - 1], order - 1))
            return false;
        }
        if (!this["_is_work_" + unit])
          return true;
        return this["_is_work_" + unit](date);
      },
      //checkings for particular time units
      //methods for month-year-week can be defined, otherwise always return 'true'
      _is_work_day: function (date) {
        var val = this._getWorkHours(date);

        if (val instanceof Array) {
          return val.length > 0;
        }
        return false;
      },
      _is_work_hour: function (date) {
        var hours = this._getWorkHours(date); // [7,12] or []
        var hour = date.getHours();
        for (var i = 0; i < hours.length; i += 2) {
          if (hours[i + 1] === undefined) {
            return hours[i] == hour;
          } else {
            if (hour >= hours[i] && hour < hours[i + 1])
              return true;
          }
        }
        return false;
      },
      _internDatesPull: {},
      _nextDate: function (start, unit, step) {
        var dateHelper = this.$gantt.date;
        return dateHelper.add(start, step, unit);

        /*var start_value = +start,
          key = unit + "_" + step;
        var interned = this._internDatesPull[key];
        if(!interned){
          interned = this._internDatesPull[key] = {};
        }
        var calculated;
        if(!interned[start_value]){
          interned[start_value] = calculated = dateHelper.add(start, step, unit);
          //interned[start_value] = dateHelper.add(start, step, unit);
        }
        return calculated || interned[start_value];*/
      },
      _getWorkUnitsBetweenGeneric: function (from, to, unit, step) {
        var dateHelper = this.$gantt.date;
        var start = new Date(from),
          end = new Date(to);
        step = step || 1;
        var units = 0;


        var next = null;
        var stepStart,
          stepEnd;

        // calculating decimal durations, i.e. 2016-09-20 00:05:00 - 2016-09-20 01:00:00 ~ 0.95 instead of 1
        // and also  2016-09-20 00:00:00 - 2016-09-20 00:05:00 ~ 0.05 instead of 1
        // durations must be rounded later
        var checkFirst = false;
        stepStart = dateHelper[unit + "_start"](new Date(start));
        if (stepStart.valueOf() != start.valueOf()) {
          checkFirst = true;
        }
        var checkLast = false;
        stepEnd = dateHelper[unit + "_start"](new Date(to));
        if (stepEnd.valueOf() != to.valueOf()) {
          checkLast = true;
        }

        var isLastStep = false;
        while (start.valueOf() < end.valueOf()) {
          next = this._nextDate(start, unit, step);
          isLastStep = (next.valueOf() > end.valueOf());

          if (this._isWorkTime(start, unit)) {
            if (checkFirst || (checkLast && isLastStep)) {
              stepStart = dateHelper[unit + "_start"](new Date(start));
              stepEnd = dateHelper.add(stepStart, step, unit);
            }

            if (checkFirst) {
              checkFirst = false;
              next = this._nextDate(stepStart, unit, step);
              units += ((stepEnd.valueOf() - start.valueOf()) / (stepEnd.valueOf() - stepStart.valueOf()));
            } else if (checkLast && isLastStep) {
              checkLast = false;
              units += ((end.valueOf() - start.valueOf()) / (stepEnd.valueOf() - stepStart.valueOf()));

            } else {
              units++;
            }
          }
          start = next;
        }
        return units;
      },

      _getMinutesPerDay: function (date) {
        // current api doesn't allow setting working minutes, so use hardcoded 60 minutes per hour
        return this._getHoursPerDay(date) * 60;
      },
      _getHoursPerDay: function (date) {
        var hours = this._getWorkHours(date);
        var res = 0;
        for (var i = 0; i < hours.length; i += 2) {
          res += ((hours[i + 1] - hours[i]) || 0);
        }
        return res;
      },
      _getWorkUnitsForRange: function (from, to, unit, step) {
        var total = 0;
        var start = new Date(from),
          end = new Date(to);

        var getUnitsPerDay;
        if (unit == "minute") {
          getUnitsPerDay = utils.bind(this._getMinutesPerDay, this);
        } else {
          getUnitsPerDay = utils.bind(this._getHoursPerDay, this);
        }

        while (start.valueOf() < end.valueOf()) {
          if (this._isWorkTime(start, "day")) {
            total += getUnitsPerDay(start);
          }
          start = this._nextDate(start, "day", 1);
        }

        return total / step;
      },

      // optimized method for calculating work units duration of large time spans
      // implemented for hours and minutes units, bigger time units don't benefit from the optimization so much
      _getWorkUnitsBetweenQuick: function (from, to, unit, step) {
        var start = new Date(from),
          end = new Date(to);
        step = step || 1;

        var firstDayStart = new Date(start);
        var firstDayEnd = this.$gantt.date.add(this.$gantt.date.day_start(new Date(start)), 1, "day");

        if (end.valueOf() <= firstDayEnd.valueOf()) {
          return this._getWorkUnitsBetweenGeneric(from, to, unit, step);
        } else {

          var lastDayStart = this.$gantt.date.day_start(new Date(end));
          var lastDayEnd = end;

          var startPart = this._getWorkUnitsBetweenGeneric(firstDayStart, firstDayEnd, unit, step);
          var endPart = this._getWorkUnitsBetweenGeneric(lastDayStart, lastDayEnd, unit, step);

          var rangePart = this._getWorkUnitsForRange(firstDayEnd, lastDayStart, unit, step);
          var total = startPart + rangePart + endPart;

          return total;
        }
      },

      _getCalendar: function () {
        return this.worktime;
      },
      _setCalendar: function (settings) {
        this.worktime = settings;
      },

      _tryChangeCalendarSettings: function (payload) {
        var backup = JSON.stringify(this._getCalendar());
        payload();
        if (this._isEmptyCalendar(this._getCalendar())) {
          this.$gantt.assert(false, "Invalid calendar settings, no worktime available");
          this._setCalendar(JSON.parse(backup));
          this._workingUnitsCache.clear();
          return false;
        }
        return true;

      },

      _isEmptyCalendar: function (settings) {
        var result = false,
          datesArray = [],
          isFullWeekSet = true;
        for (var i in settings.dates) {
          result || !!settings.dates[i];
          datesArray.push(i);
        }

        var checkFullArray = [];
        for (let i = 0; i < datesArray.length; i++) {
          if (datesArray[i] < 10) {
            checkFullArray.push(datesArray[i]);
          }
        }
        checkFullArray.sort();

        for (let i = 0; i < 7; i++) {
          if (checkFullArray[i] != i)
            isFullWeekSet = false;
        }
        if (isFullWeekSet)
          return !result;
        return !(result || !!settings.hours); // can still return false if separated dates are set to true
      },

      getWorkHours: function () {
        var config = this.argumentsHelper.getWorkHoursArguments.apply(this.argumentsHelper, arguments);
        return this._getWorkHours(config.date);
      },
      _getWorkHours: function (date) {
        var t = this._timestamp({ date: date });
        var hours = true;
        var calendar = this._getCalendar();
        if (calendar.dates[t] !== undefined) {
          hours = calendar.dates[t];//custom day
        } else if (calendar.dates[date.getDay()] !== undefined) {
          hours = calendar.dates[date.getDay()];//week day
        }
        if (hours === true) {
          return calendar.hours;
        } else if (hours) {
          return hours;
        }
        return [];
      },

      setWorkTime: function (settings) {
        return this._tryChangeCalendarSettings(utils.bind(function () {
          var hours = settings.hours !== undefined ? settings.hours : true;
          var timestamp = this._timestamp(settings);
          if (timestamp !== null) {
            this._getCalendar().dates[timestamp] = hours;
          } else {
            this._getCalendar().hours = hours;
          }
          this._workingUnitsCache.clear();
        }, this));
      },

      unsetWorkTime: function (settings) {
        return this._tryChangeCalendarSettings(utils.bind(function () {
          if (!settings) {
            this.reset_calendar();
          } else {

            var timestamp = this._timestamp(settings);

            if (timestamp !== null) {
              delete this._getCalendar().dates[timestamp];
            }
          }
          // Clear work units cache
          this._workingUnitsCache.clear();
        }, this));
      },

      _isWorkTime: function (date, unit, order) {
        // Check if this item has in the cache

        // use string keys
        var dateKey = String(date.valueOf());
        var is_work_unit = this._workingUnitsCache.getItem(unit, dateKey);

        if (is_work_unit == -1) {
          // calculate if not cached
          is_work_unit = this._checkIfWorkingUnit(date, unit, order);
          this._workingUnitsCache.setItem(unit, dateKey, is_work_unit);
        }

        return is_work_unit;
      },

      isWorkTime: function () {
        var config = this.argumentsHelper.isWorkTimeArguments.apply(this.argumentsHelper, arguments);
        return this._isWorkTime(config.date, config.unit);
      },

      calculateDuration: function () {
        var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);

        if (!config.unit) {
          return false;
        }
        return this._calculateDuration(config.start_date, config.end_date, config.unit, config.step);
      },

      _calculateDuration: function (from, to, unit, step) {
        var res = 0;
        if (unit == "hour" || unit == "minute") {
          res = this._getWorkUnitsBetweenQuick(from, to, unit, step);
        } else {
          res = this._getWorkUnitsBetweenGeneric(from, to, unit, step);
        }

        // getWorkUnits.. returns decimal durations
        return Math.round(res);
      },
      hasDuration: function () {
        var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);

        var from = config.start_date,
          to = config.end_date,
          unit = config.unit,
          step = config.step;

        if (!unit) {
          return false;
        }
        var start = new Date(from),
          end = new Date(to);
        step = step || 1;

        while (start.valueOf() < end.valueOf()) {
          if (this._isWorkTime(start, unit))
            return true;
          start = this._nextDate(start, unit, step);
        }
        return false;
      },

      calculateEndDate: function () {
        var config = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments);

        var from = config.start_date,
          duration = config.duration,
          unit = config.unit,
          step = config.step;

        if (!unit)
          return false;

        var mult = (config.duration >= 0) ? 1 : -1;
        duration = Math.abs(duration * 1);
        return this._calculateEndDate(from, duration, unit, step * mult);
      },

      _calculateEndDate: function (from, duration, unit, step) {
        if (!unit)
          return false;

        if (step == 1 && unit == "minute") {
          return this._calculateMinuteEndDate(from, duration, step);
        } else if (step == 1 && unit == "hour") {
          return this._calculateHourEndDate(from, duration, step);
        } else {
          var interval = this._addInterval(from, duration, unit, step, null);
          return interval.end;
        }
      },

      _addInterval: function (start, duration, unit, step, stopAction) {
        var added = 0;
        var current = start;
        while (added < duration && !(stopAction && stopAction(current))) {
          var next = this._nextDate(current, unit, step);
          if (this._isWorkTime(step > 0 ? new Date(next.valueOf() - 1) : new Date(next.valueOf() + 1), unit)) {
            added++;
          }
          current = next;
        }
        return {
          end: current,
          satrt: start,
          added: added
        };
      },

      _calculateHourEndDate: function (from, duration, step) {
        var start = new Date(from),
          added = 0;
        step = step || 1;
        duration = Math.abs(duration * 1);

        var interval = this._addInterval(start, duration, "hour", step, function (date) {
          // iterate until hour end
          if (!(date.getHours() || date.getMinutes() || date.getSeconds() || date.getMilliseconds())) {
            return true;
          }
          return false;
        });

        added = interval.added;
        start = interval.end;

        var durationLeft = duration - added;

        if (durationLeft && durationLeft > 24) {
          var current = start;
          while (added < duration) {
            var next = this._nextDate(current, "day", step);
            if (this._isWorkTime(step > 0 ? new Date(next.valueOf() - 1) : new Date(next.valueOf() + 1), "day")) {
              var hours = this._getHoursPerDay(current);
              if (added + hours >= duration) {
                break;
              } else {
                added += hours;
              }
            }
            current = next;
          }
          start = current;
        }

        if (added < duration) {
          var durationLeft = duration - added;
          interval = this._addInterval(start, durationLeft, "hour", step, null);
          start = interval.end;
        }

        return start;
      },

      _calculateMinuteEndDate: function (from, duration, step) {

        var start = new Date(from),
          added = 0;
        step = step || 1;
        duration = Math.abs(duration * 1);

        var interval = this._addInterval(start, duration, "minute", step, function (date) {
          // iterate until hour end
          if (!(date.getMinutes() || date.getSeconds() || date.getMilliseconds())) {
            return true;
          }
          return false;
        });

        added = interval.added;
        start = interval.end;

        if (added < duration) {
          var left = duration - added;
          var hours = Math.floor(left / 60);
          if (hours) {
            start = this._calculateEndDate(start, hours, "hour", step > 0 ? 1 : -1);
            added += hours * 60;
          }
        }

        if (added < duration) {
          var durationLeft = duration - added;
          interval = this._addInterval(start, durationLeft, "minute", step, null);
          start = interval.end;
        }

        return start;
      },

      getClosestWorkTime: function () {
        var settings = this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments);
        return this._getClosestWorkTime(settings.date, settings.unit, settings.dir);
      },

      _getClosestWorkTime: function (inputDate, unit, direction) {
        var result = new Date(inputDate);

        if (this._isWorkTime(result, unit)) {
          return result;
        }

        result = this.$gantt.date[unit + '_start'](result);

        if (direction == 'any' || !direction) {
          var closestFuture = this._getClosestWorkTimeFuture(result, unit);
          var closestPast = this._getClosestWorkTimePast(result, unit);
          if (Math.abs(closestFuture - inputDate) <= Math.abs(inputDate - closestPast)) {
            result = closestFuture;
          } else {
            result = closestPast;
          }
        } else if (direction == "past") {
          result = this._getClosestWorkTimePast(result, unit);
        } else {
          result = this._getClosestWorkTimeFuture(result, unit);
        }
        return result;
      },

      _getClosestWorkTimeFuture: function (date, unit) {
        return this._getClosestWorkTimeGeneric(date, unit, 1);
      },

      _getClosestWorkTimePast: function (date, unit) {
        var result = this._getClosestWorkTimeGeneric(date, unit, -1);
        // should return the end of the closest work interval
        return this.$gantt.date.add(result, 1, unit);
      },

      _getClosestWorkTimeGeneric: function (date, unit, increment) {
        var unitOrder = this._getUnitOrder(unit),
          biggerTimeUnit = this.units[unitOrder - 1];

        var result = date;

        // be extra sure we won't fall into infinite loop, 3k seems big enough
        var maximumLoop = 3000,
          count = 0;

        while (!this._isWorkTime(result, unit)) {
          if (biggerTimeUnit && !this._isWorkTime(result, biggerTimeUnit)) {
            // if we look for closest work hour and detect a week-end - first find the closest work day,
            // and continue iterations after that
            if (increment > 0) {
              result = this._getClosestWorkTimeFuture(result, biggerTimeUnit);
            } else {
              result = this._getClosestWorkTimePast(result, biggerTimeUnit);
            }

            if (this._isWorkTime(result, unit)) {
              break;
            }
          }

          count++;
          if (count > maximumLoop) {
            this.$gantt.assert(false, "Invalid working time check");
            return false;
          }

          var tzOffset = result.getTimezoneOffset();
          result = this.$gantt.date.add(result, increment, unit);

          result = this.$gantt._correct_dst_change(result, tzOffset, increment, unit);
          if (this.$gantt.date[unit + '_start']) {
            result = this.$gantt.date[unit + '_start'](result);
          }
        }
        return result;
      }
    };

    return CalendarWorkTimeStrategy;
  }

  calendarManagerJs = function () {

    var utils = this.helperService.utils;
    var createArgumentsHelper = this.createArgumentsHelperJs;
    var CalendarWorktimeStrategy = this.calendarStrategyJS;

    function CalendarManager(gantt) {
      this.$gantt = gantt;
      this._calendars = {};
    }

    CalendarManager.prototype = {
      _calendars: {},
      _getDayHoursForMultiple: function (calendars, date) {
        var units: any = [],
          tick = true,
          currPos = 0,
          is_work_hour = false,
          start = this.$gantt.date.day_start(new Date(date));
        for (var hour = 0; hour < 24; hour++) {
          is_work_hour = calendars.reduce(function (acc, calendar) {
            return acc && calendar._is_work_hour(start);
          }, true);
          if (is_work_hour) {
            if (tick) {
              units[currPos] = hour;
              units[currPos + 1] = (hour + 1);
              currPos += 2;
            } else {
              units[currPos - 1] += 1;
            }
            tick = false;
          } else if (!tick) {
            tick = true;
          }
          start = this.$gantt.date.add(start, 1, "hour");
        }
        if (!units.length)
          units = false;
        return units;
      },
      mergeCalendars: function () {
        var newCalendar = this.createCalendar(),
          day,
          units = [];
        var calendars = Array.prototype.slice.call(arguments, 0);
        newCalendar.worktime.hours = [0, 24];
        newCalendar.worktime.dates = {};
        var start = this.$gantt.date.day_start(new Date(259200000)); // 1970 day=0
        for (day = 0; day < 7; day++) {
          units = this._getDayHoursForMultiple(calendars, start);
          newCalendar.worktime.dates[day] = units;
          start = this.$gantt.date.add(start, 1, "day");
        }
        for (var i = 0; i < calendars.length; i++) {
          for (var value in calendars[i].worktime.dates) if (+value > 10000) {
            units = this._getDayHoursForMultiple(calendars, new Date(+value));
            newCalendar.worktime.dates[value] = units;
          }
        }
        return newCalendar;
      },

      _convertWorktimeSettings: function (settings) {
        var days = settings.days;
        if (days) {
          settings.dates = settings.dates || {};
          for (var i = 0; i < days.length; i++) {
            settings.dates[i] = days[i];
            if (!(days[i] instanceof Array)) {
              settings.dates[i] = !!days[i];
            }
          }
          delete settings.days;
        }
        return settings;
      },

      createCalendar: function (parentCalendar) {
        var settings;

        if (!parentCalendar) {
          parentCalendar = {};
        }

        if (parentCalendar.worktime) {
          settings = utils.copy(parentCalendar.worktime);
        } else {
          settings = utils.copy(parentCalendar);
        }

        var defaults = utils.copy(this.defaults.fulltime.worktime);
        utils.mixin(settings, defaults);

        var id = utils.uid();
        var calendar = {
          id: id + "",
          worktime: this._convertWorktimeSettings(settings)
        };

        var apiCore = new CalendarWorktimeStrategy(this.$gantt, createArgumentsHelper(this.$gantt));
        utils.mixin(apiCore, calendar);

        // validate/check if empty calendar
        if (!apiCore._tryChangeCalendarSettings(function () {
        })) {
          return null;
        } else {
          return apiCore;
        }
      },

      getCalendar: function (id) {
        id = id || "global";
        this.createDefaultCalendars();
        return this._calendars[id];
      },

      getCalendars: function () {
        var res = [];
        for (var i in this._calendars) {
          res.push(this.getCalendar(i));
        }
        return res;
      },

      _getOwnCalendar: function (task) {
        var config = this.$gantt.config;
        if (task[config.calendar_property]) {
          return this.getCalendar(task[config.calendar_property]);
        }

        if (config.resource_calendars) {
          for (var field in config.resource_calendars) {
            var resource = config.resource_calendars[field];
            if (task[field]) {
              var calendarId = resource[task[field]];
              if (calendarId) {
                return this.getCalendar(calendarId);
              }
            }
          }
        }
        return null;
      },

      getTaskCalendar: function (task) {
        if (!task) {
          return this.getCalendar();
        }

        var calendar = this._getOwnCalendar(task);
        var gantt = this.$gantt;
        if (!calendar && gantt.config.inherit_calendar && gantt.isTaskExists(task.parent)) {
          var stop = false;
          gantt.eachParent(function (parent) {
            if (stop) return;
            if (gantt.isSummaryTask(parent)) {
              calendar = this._getOwnCalendar(parent);
              if (calendar) {
                stop = true;
              }
            }
          }, task.id, this);
        }

        return calendar || this.getCalendar();
      },

      addCalendar: function (calendar) { // puts new calendar to Global Storage - gantt.calendarManager._calendars {}
        if (!(calendar instanceof CalendarWorktimeStrategy)) {
          var id = calendar.id;
          calendar = this.createCalendar(calendar);
          calendar.id = id;
        }
        var config = this.$gantt.config;

        calendar.id = calendar.id || utils.uid();
        this._calendars[calendar.id] = calendar;
        if (!config.worktimes)
          config.worktimes = {};
        config.worktimes[calendar.id] = calendar.worktime;
        return calendar.id;
      },

      deleteCalendar: function (calendar) {
        var config = this.$gantt.config;
        if (!calendar) return false;
        if (this._calendars[calendar]) {
          delete this._calendars[calendar];
          if (config.worktimes && config.worktimes[calendar])
            delete config.worktimes[calendar];
          return true;
        } else {
          return false;
        }
      },

      restoreConfigCalendars: function (configs) {
        for (var i in configs) {
          if (this._calendars[i])
            continue;

          var settings = configs[i];
          var calendar = this.createCalendar(settings);
          calendar.id = i;
          this.addCalendar(calendar);
        }
      },

      defaults: {
        global: {
          id: "global",
          worktime: {
            hours: [8, 17],
            days: [0, 1, 1, 1, 1, 1, 0]
          }
        },
        fulltime: {
          id: "fulltime",
          worktime: {
            hours: [0, 24],
            days: [1, 1, 1, 1, 1, 1, 1]
          }
        }
      },

      createDefaultCalendars: function () {
        var config = this.$gantt.config;
        this.restoreConfigCalendars(this.defaults);
        this.restoreConfigCalendars(config.worktimes);
      }
    };

    return CalendarManager;

  }

  noWorkTimeCalendarJs = function () {

    function CalendarDisabledTimeStrategy(gantt, argumentsHelper) {
      this.argumentsHelper = argumentsHelper;
      this.$gantt = gantt;
    }

    CalendarDisabledTimeStrategy.prototype = {
      getWorkHours: function () {
        return [0, 24];
      },
      setWorkTime: function () {
        return true;
      },
      unsetWorkTime: function () {
        return true;
      },
      isWorkTime: function () {
        return true;
      },
      getClosestWorkTime: function (config) {
        var config = this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments);
        return config.date;
      },

      calculateDuration: function () {
        var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);
        var from = config.start_date,
          to = config.end_date,
          unit = config.unit,
          step = config.step;

        return this._calculateDuration(from, to, unit, step);
      },
      _calculateDuration: function (start, end, unit, step) {
        var dateHelper = this.$gantt.date;
        var fixedUnits = {
          "week": 1000 * 60 * 60 * 24 * 7,
          "day": 1000 * 60 * 60 * 24,
          "hour": 1000 * 60 * 60,
          "minute": 1000 * 60
        };

        var res = 0;
        if (fixedUnits[unit]) {
          res = Math.round((end - start) / (step * fixedUnits[unit]));
        } else {
          var from = new Date(start),
            to = new Date(end);
          while (from.valueOf() < to.valueOf()) {
            res += 1;
            from = dateHelper.add(from, step, unit);
          }

          if (from.valueOf() != end.valueOf()) {
            res += (to.getDate() - from.getDate()) / (dateHelper.add(from, step, unit) - from.getDate());
          }
        }

        return Math.round(res);
      },

      hasDuration: function () {
        var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);
        var from = config.start_date,
          to = config.end_date,
          unit = config.unit;

        if (!unit) {
          return false;
        }
        from = new Date(from);
        to = new Date(to);

        return (from.valueOf() < to.valueOf());
      },

      calculateEndDate: function () {
        var config = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments);

        var start = config.start_date,
          duration = config.duration,
          unit = config.unit,
          step = config.step;

        return this.$gantt.date.add(start, step * duration, unit);
      }
    };

    return CalendarDisabledTimeStrategy;

  }

  timeCalculatorJs = function () {

    var createArgumentsHelper = this.createArgumentsHelperJs,
      NoWorkTimeCalendar = this.noWorkTimeCalendarJs;

    function TimeCalculator(calendarManager) {

      this.$gantt = calendarManager.$gantt;
      this.argumentsHelper = createArgumentsHelper(this.$gantt);
      this.calendarManager = calendarManager;
      this.$disabledCalendar = new NoWorkTimeCalendar(this.$gantt, this.argumentsHelper);
    }

    TimeCalculator.prototype = {
      _getCalendar: function (config) {
        var calendar;
        if (!this.$gantt.$services.config().work_time) {
          calendar = this.$disabledCalendar;
        } else {
          var manager = this.calendarManager;
          if (config.task) {
            calendar = manager.getTaskCalendar(config.task);
          } else if (config.id) {
            calendar = manager.getTaskCalendar(config);
          } else if (config.calendar) {
            calendar = config.calendar;
          }
          if (!calendar) {
            calendar = manager.getTaskCalendar();
          }
        }
        return calendar;
      },

      getWorkHours: function (config) {
        config = this.argumentsHelper.getWorkHoursArguments.apply(this.argumentsHelper, arguments);

        var calendar = this._getCalendar(config);

        return calendar.getWorkHours(config.date);
      },

      setWorkTime: function (config, calendar) {
        config = this.argumentsHelper.setWorkTimeArguments.apply(this.argumentsHelper, arguments);

        if (!calendar)
          calendar = this.calendarManager.getCalendar(); // Global
        return calendar.setWorkTime(config);
      },

      unsetWorkTime: function (config, calendar) {
        config = this.argumentsHelper.unsetWorkTimeArguments.apply(this.argumentsHelper, arguments);

        if (!calendar)
          calendar = this.calendarManager.getCalendar(); // Global
        return calendar.unsetWorkTime(config);
      },
      isWorkTime: function (date, unit, task, calendar) {
        var config = this.argumentsHelper.isWorkTimeArguments.apply(this.argumentsHelper, arguments);

        calendar = this._getCalendar(config);
        return calendar.isWorkTime(config);
      },
      getClosestWorkTime: function (config) {
        config = this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments);

        var calendar = this._getCalendar(config);

        return calendar.getClosestWorkTime(config);
      },

      calculateDuration: function () { // start_date_date, end_date, task
        var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);


        var calendar = this._getCalendar(config);
        return calendar.calculateDuration(config);
      },
      hasDuration: function () {
        var config = this.argumentsHelper.hasDurationArguments.apply(this.argumentsHelper, arguments);

        var calendar = this._getCalendar(config);

        return calendar.hasDuration(config);
      },
      calculateEndDate: function (config) { // start_date, duration, unit, task
        var config = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments);

        var calendar = this._getCalendar(config);
        return calendar.calculateEndDate(config);
      }
    };

    return TimeCalculator;
  }

  workTimeCalendarJs = function () {

    // TODO: rework public api for date methods
    var utils = this.helperService.utils;

    var createWorktimeFacade = function (calendarManager, timeCalculator) {
      return {
        getWorkHours: function (date) {
          return timeCalculator.getWorkHours(date);
        },

        setWorkTime: function (config) {
          return timeCalculator.setWorkTime(config);
        },

        unsetWorkTime: function (config) {
          timeCalculator.unsetWorkTime(config);
        },

        isWorkTime: function (date, unit, task) {
          return timeCalculator.isWorkTime(date, unit, task);
        },

        getClosestWorkTime: function (config) {
          return timeCalculator.getClosestWorkTime(config);
        },

        calculateDuration: function (start_date, end_date, task) {
          return timeCalculator.calculateDuration(start_date, end_date, task);
        },
        _hasDuration: function (start_date, end_date, task) {
          return timeCalculator.hasDuration(start_date, end_date, task);
        },

        calculateEndDate: function (start, duration, unit, task) {
          return timeCalculator.calculateEndDate(start, duration, unit, task);
        },

        createCalendar: utils.bind(calendarManager.createCalendar, calendarManager),
        addCalendar: utils.bind(calendarManager.addCalendar, calendarManager),
        getCalendar: utils.bind(calendarManager.getCalendar, calendarManager),
        getCalendars: utils.bind(calendarManager.getCalendars, calendarManager),
        getTaskCalendar: utils.bind(calendarManager.getTaskCalendar, calendarManager),
        deleteCalendar: utils.bind(calendarManager.deleteCalendar, calendarManager)
      };
    };


    return { create: createWorktimeFacade };
  }

  workTime = function (gantt) {

    var CalendarManager = this.calendarManagerJs,
      TimeCalculator = this.timeCalculatorJs,
      worktimeFacadeFactory = this.workTimeCalendarJs,
      utils = this.helperService.utils;

    return function (gantt) {
      var manager = new CalendarManager(gantt),
        timeCalculator = new TimeCalculator(manager);
      var facade = worktimeFacadeFactory.create(manager, timeCalculator);
      utils.mixin(gantt, facade);
    };
  }

  data = function (gantt) {

    var helpers = this.helperService;

    return function (gantt) {

      gantt.isUnscheduledTask = function (task) {
        gantt.assert(task && task instanceof Object, "Invalid argument <b>task</b>=" + task + " of gantt.isUnscheduledTask. Task object was expected");
        return (!!task.unscheduled || !task.start_date);
      };

      gantt._isAllowedUnscheduledTask = function (task) {
        return !!(task.unscheduled && gantt.config.show_unscheduled);
      };

      gantt.isTaskVisible = function (id) {
        if (!this.isTaskExists(id))
          return false;

        var task = this.getTask(id);

        var taskStart = task.start_date ? task.start_date.valueOf() : null;
        var taskEnd = task.end_date ? task.end_date.valueOf() : null;

        if (!(gantt._isAllowedUnscheduledTask(task) || (taskStart && taskEnd && taskStart <= this._max_date.valueOf() && taskEnd >= this._min_date.valueOf()))) {
          return false;
        }

        return !!(gantt.getGlobalTaskIndex(id) >= 0);
      };

      gantt._getProjectEnd = function () {
        if (gantt.config.project_end) {
          return gantt.config.project_end;
        } else {
          var tasks = gantt.getTaskByTime();
          tasks = tasks.sort(function (a, b) {
            return +a.end_date > +b.end_date ? 1 : -1;
          });
          return tasks.length ? tasks[tasks.length - 1].end_date : null;
        }
      };
      gantt._getProjectStart = function () {
        if (gantt.config.project_start) {
          return gantt.config.project_start;
        }

        // use timeline start if project start is not specified
        if (gantt.config.start_date) {
          return gantt.config.start_date;
        }
        if (gantt.getState().min_date) {
          return gantt.getState().min_date;
        }

        // earliest task start if neither project start nor timeline are specified
        var tasks = gantt.getTaskByTime();
        tasks = tasks.sort(function (a, b) {
          return +a.start_date > +b.start_date ? 1 : -1;
        });
        return tasks.length ? tasks[0].start_date : null;
      };

      gantt._defaultTaskDate = function (item, parent_id) {
        var parent = (parent_id && parent_id != gantt.config.root_id) ? gantt.getTask(parent_id) : false,
          startDate = null;
        if (parent) {
          if (gantt.config.schedule_from_end) {
            startDate = gantt.calculateEndDate({
              start_date: parent.end_date,
              duration: - gantt.config.duration_step,
              task: item
            });
          } else {
            startDate = parent.start_date;
          }

        } else if (gantt.config.schedule_from_end) {
          startDate = gantt.calculateEndDate({
            start_date: gantt._getProjectEnd(),
            duration: - gantt.config.duration_step,
            task: item
          });
        } else {
          var first = gantt.getTaskByIndex(0);
          startDate = first ? (first.start_date ? first.start_date : (first.end_date ? gantt.calculateEndDate({
            start_date: first.end_date,
            duration: -gantt.config.duration_step,
            task: item
          }) : null)) : gantt.config.start_date || gantt.getState().min_date;
        }
        gantt.assert(startDate, "Invalid dates");
        return new Date(startDate);
      };

      gantt._set_default_task_timing = function (task) {
        task.start_date = task.start_date || gantt._defaultTaskDate(task, gantt.getParent(task));
        task.duration = task.duration || gantt.config.duration_step;
        task.end_date = task.end_date || gantt.calculateEndDate(task);
      };

      gantt.createTask = function (item, parent, index) {
        item = item || {};
        if (!gantt.defined(item.id))
          item.id = gantt.uid();

        if (!item.start_date) {
          item.start_date = gantt._defaultTaskDate(item, parent);
        }
        if (item.text === undefined) {
          item.text = gantt.locale.labels.new_task;
        }
        if (item.duration === undefined) {
          item.duration = 1;
        }

        if (this.isTaskExists(parent)) {
          this.setParent(item, parent, true);
          var parentObj = this.getTask(parent);
          parentObj.$open = true;
        }

        if (!this.callEvent("onTaskCreated", [item])) {
          return null;
        }
        if (this.config.details_on_create) {
          item.$new = true;
          this.silent(function () {
            gantt.$data.tasksStore.addItem(item, index);
          });
          this.selectTask(item.id);
          this.refreshData();
          this.showLightbox(item.id);
        } else {
          if (this.addTask(item, parent, index)) {
            this.showTask(item.id);
            this.selectTask(item.id);
          }
        }
        return item.id;
      };

      gantt._update_flags = function (oldid, newid) {
        //  TODO: need a proper way to update all possible flags
        var store = gantt.$data.tasksStore;
        if (oldid === undefined) {
          this._lightbox_id = null;

          store.silent(function () {
            store.unselect();
          });

          if (this._tasks_dnd && this._tasks_dnd.drag) {
            this._tasks_dnd.drag.id = null;
          }
        } else {
          if (this._lightbox_id == oldid)
            this._lightbox_id = newid;

          // TODO: probably can be removed
          if (store.getSelectedId() == oldid) {
            store.silent(function () {
              store.unselect(oldid);
              store.select(newid);
            });
          }
          if (this._tasks_dnd && this._tasks_dnd.drag && this._tasks_dnd.drag.id == oldid) {
            this._tasks_dnd.drag.id = newid;
          }
        }
      };

      gantt._get_task_timing_mode = function (task, force) {
        var task_type = this.getTaskType(task.type);

        var state = {
          type: task_type,
          $no_start: false,
          $no_end: false
        };

        if (!force && task_type == task.$rendered_type) {
          state.$no_start = task.$no_start;
          state.$no_end = task.$no_end;
          return state;
        }

        if (task_type == this.config.types.project) {
          //project duration is always defined by children duration
          state.$no_end = state.$no_start = true;
        } else if (task_type != this.config.types.milestone) {
          //tasks can have fixed duration, children duration(as projects), or one date fixed, and other defined by nested items
          state.$no_end = !(task.end_date || task.duration);
          state.$no_start = !task.start_date;

          if (this._isAllowedUnscheduledTask(task)) {
            state.$no_end = state.$no_start = false;
          }
        }

        return state;
      };

      gantt._init_task_timing = function (task) {
        var task_mode = gantt._get_task_timing_mode(task, true);

        var dirty = task.$rendered_type != task_mode.type;

        var task_type = task_mode.type;

        if (dirty) {
          task.$no_start = task_mode.$no_start;
          task.$no_end = task_mode.$no_end;
          task.$rendered_type = task_mode.type;
        }

        if (dirty && task_type != this.config.types.milestone) {
          if (task_type == this.config.types.project) {
            //project duration is always defined by children duration
            this._set_default_task_timing(task);
          }
        }

        if (task_type == this.config.types.milestone) {
          task.end_date = task.start_date;
        }
        if (task.start_date && task.end_date) {
          task.duration = this.calculateDuration(task);
        }

        if (!task.end_date) {
          task.end_date = task.start_date;
        }

        task.duration = task.duration || 0;
      };

      gantt.isSummaryTask = function (task) {
        gantt.assert(task && task instanceof Object, "Invalid argument <b>task</b>=" + task + " of gantt.isSummaryTask. Task object was expected");

        var mode = gantt._get_task_timing_mode(task);

        return !!(mode.$no_end || mode.$no_start);
      };

      // downward calculation of project duration
      gantt.resetProjectDates = function (task) {
        var taskMode = this._get_task_timing_mode(task);
        if (taskMode.$no_end || taskMode.$no_start) {
          var dates = this.getSubtaskDates(task.id);
          this._assign_project_dates(task, dates.start_date, dates.end_date);
        }
      };

      gantt.getSubtaskDuration = function (task_id) {
        var res = 0,
          root = task_id !== undefined ? task_id : gantt.config.root_id;

        this.eachTask(function (child) {
          if (this.getTaskType(child.type) == gantt.config.types.project || this.isUnscheduledTask(child))
            return;

          res += child.duration;
        }, root);

        return res;
      };

      gantt.getSubtaskDates = function (task_id) {
        var min = null,
          max = null,
          root = task_id !== undefined ? task_id : gantt.config.root_id;

        this.eachTask(function (child) {
          if (this.getTaskType(child.type) == gantt.config.types.project || this.isUnscheduledTask(child))
            return;

          if ((child.start_date && !child.$no_start) && (!min || min > child.start_date.valueOf()))
            min = child.start_date.valueOf();
          if ((child.end_date && !child.$no_end) && (!max || max < child.end_date.valueOf()))
            max = child.end_date.valueOf();
        }, root);

        return {
          start_date: min ? new Date(min) : null,
          end_date: max ? new Date(max) : null
        };
      };

      gantt._assign_project_dates = function (task, from, to) {
        var taskTiming = this._get_task_timing_mode(task);
        if (taskTiming.$no_start) {
          if (from && from != Infinity) {
            task.start_date = new Date(from);
          } else {
            task.start_date = this._defaultTaskDate(task, this.getParent(task));
          }
        }

        if (taskTiming.$no_end) {
          if (to && to != -Infinity) {
            task.end_date = new Date(to);
          } else {
            task.end_date = this.calculateEndDate({
              start_date: task.start_date,
              duration: this.config.duration_step,
              task: task
            });
          }
        }
        if (taskTiming.$no_start || taskTiming.$no_end) {
          this._init_task_timing(task);
        }
      };

      // upward calculation of project duration
      gantt._update_parents = function (taskId, silent) {
        if (!taskId) return;

        var task = this.getTask(taskId);
        var pid = this.getParent(task);

        var taskTiming = this._get_task_timing_mode(task);

        var has_changed = true;

        if (taskTiming.$no_start || taskTiming.$no_end) {
          var oldStart = task.start_date.valueOf(),
            oldEnd = task.end_date.valueOf();

          gantt.resetProjectDates(task);

          // not refresh parent projects if dates hasn't changed
          if (oldStart == task.start_date.valueOf() && oldEnd == task.end_date.valueOf()) {
            has_changed = false;
          }

          if (has_changed && !silent) {
            this.refreshTask(task.id, true);
          }
        }


        if (has_changed && pid && this.isTaskExists(pid)) {
          this._update_parents(pid, silent);
        }
      };

      gantt.roundDate = function (config) {
        var scale = gantt.getScale();

        if (helpers.isDate(config)) {
          config = {
            date: config,
            unit: scale ? scale.unit : gantt.config.duration_unit,
            step: scale ? scale.step : gantt.config.duration_step
          };
        }
        var date = config.date,
          steps = config.step,
          unit = config.unit;

        if (!scale) {
          return date;
        }

        var upper, lower, colIndex;
        if (unit == scale.unit && steps == scale.step &&
          +date >= +scale.min_date && +date <= +scale.max_date) {
          //find date in time scale config
          colIndex = Math.floor(gantt.columnIndexByDate(date));

          if (!scale.trace_x[colIndex]) {
            colIndex -= 1;// end of time scale
            if (scale.rtl) {
              colIndex = 0;
            }
          }
          lower = new Date(scale.trace_x[colIndex]);
          upper = gantt.date.add(lower, steps, unit);
        } else {
          colIndex = Math.floor(gantt.columnIndexByDate(date));

          upper = gantt.date[unit + "_start"](new Date(scale.min_date));
          if (scale.trace_x[colIndex]) {
            upper = gantt.date[unit + "_start"](scale.trace_x[colIndex]);// end of time scale
          }

          while (+upper < +date) {
            upper = gantt.date[unit + "_start"](gantt.date.add(upper, steps, unit));

            var tzOffset = upper.getTimezoneOffset();

            upper = gantt._correct_dst_change(upper, tzOffset, upper, unit);
            if (gantt.date[unit + '_start'])
              upper = gantt.date[unit + '_start'](upper);
          }

          lower = gantt.date.add(upper, -1 * steps, unit);

        }
        if (config.dir && config.dir == 'future')
          return upper;
        if (config.dir && config.dir == 'past')
          return lower;

        if (Math.abs(date - lower) < Math.abs(upper - date)) {
          return lower;
        } else {
          return upper;
        }

      };

      gantt.correctTaskWorkTime = function (task) {
        if (gantt.config.work_time && gantt.config.correct_work_time) {
          if (!this.isWorkTime(task.start_date, undefined, task)) {
            task.start_date = this.getClosestWorkTime({ date: task.start_date, dir: 'future', task: task });
            task.end_date = this.calculateEndDate(task);
          } else if (!this.isWorkTime(new Date(+task.end_date - 1), undefined, task)) {
            task.end_date = this.calculateEndDate(task);
          }
        }
      };

      gantt.attachEvent("onBeforeTaskUpdate", function (id, task) {
        gantt._init_task_timing(task);
        return true;
      });
      gantt.attachEvent("onBeforeTaskAdd", function (id, task) {
        gantt._init_task_timing(task);
        return true;
      });

    };

  }

  superJs = function () {

    function dummy() {
      // eslint-disable-next-line
      console.log("Method is not implemented.");
    }
    function BaseControl() {
    }

    // base methods will be runned in gantt context
    BaseControl.prototype.render = dummy; // arguments: sns
    BaseControl.prototype.set_value = dummy; // arguments: node, value, ev, sns(config)
    BaseControl.prototype.get_value = dummy; // arguments node, ev, sns(config)
    BaseControl.prototype.focus = dummy; // arguments: node

    return function (gantt) { // we could send current instance of gantt to module
      return BaseControl;
    };

  }

  templateControlJs = function () {

    var __extends = this.helperService.extends;

    return function (gantt) {
      var _super = this.superJs(gantt);

      function TemplateControl() {
        var self = _super.apply(this, arguments) || this;
        return self;
      }

      __extends(TemplateControl, _super);


      TemplateControl.prototype.render = function (sns) {
        var height = (sns.height || "30") + "px";
        return "<div class='gantt_cal_ltext gantt_cal_template' style='height:" + height + ";'></div>";
      };

      TemplateControl.prototype.set_value = function (node, value) {
        node.innerHTML = value || "";
      };

      TemplateControl.prototype.get_value = function (node) {
        return node.innerHTML || "";
      };

      TemplateControl.prototype.focus = function () { };

      return TemplateControl;
    };

  }

  texteAreaControl = function () {

    var __extends = this.helperService.extends;

    return function (gantt) {
      var _super = this.superJs(gantt);

      function TextareaControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(TextareaControl, _super);

      TextareaControl.prototype.render = function (sns) {
        var height = (sns.height || "130") + "px";
        return "<div class='gantt_cal_ltext' style='height:" + height + ";'><textarea></textarea></div>";
      };

      TextareaControl.prototype.set_value = function (node, value) {
        gantt.form_blocks.textarea._get_input(node).value = value || "";
      };

      TextareaControl.prototype.get_value = function (node) {
        return gantt.form_blocks.textarea._get_input(node).value;
      };

      TextareaControl.prototype.focus = function (node) {
        var a = gantt.form_blocks.textarea._get_input(node);
        gantt._focus(a, true);
      };

      TextareaControl.prototype._get_input = function (node) {
        return node.querySelector("textarea");
      };

      return TextareaControl;
    };

  }

  timeControlJs = function () {

    var __extends = this.helpersService.extends;

    return function (gantt) {
      var _super = this.superJs(gantt);

      function TimeControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(TimeControl, _super);

      TimeControl.prototype.render = function (sns) {
        var time = gantt.form_blocks.getTimePicker.call(this, sns);
        var html = "<div style='height:" + (sns.height || 30) + "px;padding-top:0px;font-size:inherit;text-align:center;' class='gantt_section_time'>";
        html += time;

        if (sns.single_date) {
          time = gantt.form_blocks.getTimePicker.call(this, sns, true);
          html += "<span></span>";
        } else {
          html += "<span style='font-weight:normal; font-size:10pt;'> &nbsp;&ndash;&nbsp; </span>";
        }

        html += time;
        html += "</div>";
        return html;
      };

      TimeControl.prototype.set_value = function (node, value, ev, config) {
        var cfg = config;
        var s = node.getElementsByTagName("select");
        var map = config._time_format_order;

        if (cfg.auto_end_date) {
          var _update_lightbox_select = function () {
            start_date = new Date(s[map[2]].value, s[map[1]].value, s[map[0]].value, 0, 0);
            end_date = gantt.calculateEndDate({ start_date: start_date, duration: 1, task: ev });
            gantt.form_blocks._fill_lightbox_select(s, map.size, end_date, map, cfg);
          };
          for (var i = 0; i < 4; i++) {
            s[i].onchange = _update_lightbox_select;
          }
        }

        var mapping = gantt._resolve_default_mapping(config);

        if (typeof (mapping) === "string") mapping = { start_date: mapping };

        var start_date = ev[mapping.start_date] || new Date();
        var end_date = ev[mapping.end_date] || gantt.calculateEndDate({
          start_date: start_date,
          duration: 1,
          task: ev
        });

        gantt.form_blocks._fill_lightbox_select(s, 0, start_date, map, cfg);
        gantt.form_blocks._fill_lightbox_select(s, map.size, end_date, map, cfg);
      };

      TimeControl.prototype.get_value = function (node, ev, config) {
        var selects = node.getElementsByTagName("select");
        var startDate;
        var map = config._time_format_order;
        function _getEndDate(selects, map, startDate) {
          var endDate = gantt.form_blocks.getTimePickerValue(selects, config, map.size);

          if (endDate <= startDate) {
            return gantt.date.add(startDate, gantt._get_timepicker_step(), "minute");
          }
          return endDate;
        }

        startDate = gantt.form_blocks.getTimePickerValue(selects, config);

        if (typeof gantt._resolve_default_mapping(config) === "string") {
          return startDate;
        }

        return {
          start_date: startDate,
          end_date: _getEndDate(selects, map, startDate)
        };
      };

      TimeControl.prototype.focus = function (node) {
        gantt._focus(node.getElementsByTagName("select")[0]);
      };

      return TimeControl;
    };

  }

  selectControlJs = function () {

    var __extends = this.helperService.extends;
    var htmlHelpers = this.helperService.htmlHelpers;

    return function (gantt) {
      var _super = this.superJs(gantt);

      function SelectControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(SelectControl, _super);

      SelectControl.prototype.render = function (sns) {
        var height = (sns.height || "23") + "px";
        var html = "<div class='gantt_cal_ltext' style='height:" + height + ";'>";

        html += htmlHelpers.getHtmlSelect(sns.options, [{ key: "style", value: "width:100%;" }]);
        html += "</div>";
        return html;
      };

      SelectControl.prototype.set_value = function (node, value, ev, sns) {
        var select = node.firstChild;
        if (!select._dhx_onchange && sns.onchange) {
          select.onchange = sns.onchange;
          select._dhx_onchange = true;
        }
        if (typeof value === "undefined")
          value = (select.options[0] || {}).value;
        select.value = value || "";
      };

      SelectControl.prototype.get_value = function (node) {
        return node.firstChild.value;
      };

      SelectControl.prototype.focus = function (node) {
        var a = node.firstChild;
        gantt._focus(a, true);
      };

      return SelectControl;
    };

  }

  checkboxControlJs = function () {

    var helpers = this.helperService;
    var __extends = this.helperService.extends;

    return function (gantt) {
      var _super = this.superJs(gantt);

      function CheckboxControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(CheckboxControl, _super);

      CheckboxControl.prototype.render = function (sns) {
        var height = (sns.height || "23") + "px";
        var html = "<div class='gantt_cal_ltext' style='height:" + height + ";'>";

        if (sns.options && sns.options.length) {
          for (var i = 0; i < sns.options.length; i++) {
            html += "<label><input type='checkbox' value='" + sns.options[i].key + "' name='" + sns.name + "'>" + sns.options[i].label + "</label>";
          }
        }
        html += "</div>";
        return html;
      };

      CheckboxControl.prototype.set_value = function (node, value, ev, sns) {
        var checkboxes = Array.prototype.slice.call(node.querySelectorAll("input[type=checkbox]"));

        if (!node._dhx_onchange && sns.onchange) {
          node.onchange = sns.onchange;
          node._dhx_onchange = true;
        }

        helpers.forEach(checkboxes, function (entry) {
          entry.checked = value ? value.indexOf(entry.value) >= 0 : false;
        });
      };

      CheckboxControl.prototype.get_value = function (node) {
        return helpers.arrayMap(Array.prototype.slice.call(node.querySelectorAll("input[type=checkbox]:checked")), function (entry) {
          return entry.value;
        });
      };

      CheckboxControl.prototype.focus = function (node) {
        gantt._focus(node.querySelector("input[type=checkbox]"));
      };

      return CheckboxControl;
    };

    /***/
  }

  radioControlJs = function () {

    var __extends = this.helperService.extends;

    return function (gantt) {
      var _super = this.superJs(gantt);

      function RadioControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(RadioControl, _super);

      RadioControl.prototype.render = function (sns) {
        var height = (sns.height || "23") + "px";
        var html = "<div class='gantt_cal_ltext' style='height:" + height + ";'>";

        if (sns.options && sns.options.length) {
          for (var i = 0; i < sns.options.length; i++) {
            html += "<label><input type='radio' value='" + sns.options[i].key + "' name='" + sns.name + "'>" + sns.options[i].label + "</label>";
          }
        }

        html += "</div>";
        return html;
      };

      RadioControl.prototype.set_value = function (node, value, ev, sns) {
        var radio;

        if (!sns.options || !sns.options.length) return;

        radio = node.querySelector("input[type=radio][value='" + value + "']") ||
          node.querySelector("input[type=radio][value='" + sns.default_value + "']");

        if (!radio) return;

        if (!node._dhx_onchange && sns.onchange) {
          node.onchange = sns.onchange;
          node._dhx_onchange = true;
        }

        radio.checked = true;
      };

      RadioControl.prototype.get_value = function (node, ev) {
        var result = node.querySelector("input[type=radio]:checked");

        return result ? result.value : "";
      };

      RadioControl.prototype.focus = function (node) {
        gantt._focus(node.querySelector("input[type=radio]"));
      };

      return RadioControl;
    };

  }

  DurationControlJs = function () {

    var __extends = this.helperService.extends;

    return function (gantt) {
      var _super = this.superJs(gantt);

      function DurationControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(DurationControl, _super);

      DurationControl.prototype.render = function (sns) {
        var time = "<div class='gantt_time_selects'>" + gantt.form_blocks.getTimePicker.call(this, sns) + "</div>";
        var label = gantt.locale.labels[gantt.config.duration_unit + "s"];
        var singleDate = sns.single_date ? " style='display:none'" : "";
        var readonly = sns.readonly ? " disabled='disabled'" : "";
        var ariaAttr = gantt._waiAria.lightboxDurationInputAttrString(sns);
        var duration = "<div class='gantt_duration' " + singleDate + ">" +
          "<input type='button' class='gantt_duration_dec' value='−'" + readonly + ">" +
          "<input type='text' value='5' class='gantt_duration_value'" + readonly + " " + ariaAttr + ">" +
          "<input type='button' class='gantt_duration_inc' value='+'" + readonly + "> " + label + " <span></span>" +
          "</div>";
        var html = "<div style='height:" + (sns.height || 30) + "px;padding-top:0px;font-size:inherit;' class='gantt_section_time'>" + time + " " + duration + "</div>";
        return html;
      };

      DurationControl.prototype.set_value = function (node, value, ev, config) {
        var cfg = config;
        var s = node.getElementsByTagName("select");
        var inps = node.getElementsByTagName("input");
        var duration = inps[1];
        var btns = [inps[0], inps[2]];
        var endspan = node.getElementsByTagName("span")[0];
        var map = config._time_format_order;
        var mapping;
        var start_date;
        var end_date;
        var duration_val;

        function _calc_date() {
          var start_date = _getStartDate.call(gantt, node, config);
          var duration = _getDuration.call(gantt, node, config);
          var end_date = gantt.calculateEndDate({ start_date: start_date, duration: duration, task: ev });

          endspan.innerHTML = gantt.templates.task_date(end_date);
        }

        function _change_duration(step) {
          var value = duration.value;

          value = parseInt(value, 10);
          if (window/*.isNaN(value)*/)
            value = 0;
          value += step;
          if (value < 1) value = 1;
          duration.value = value;
          _calc_date();
        }

        btns[0].onclick = gantt.bind(function () {
          _change_duration(-1 * gantt.config.duration_step);
        }, this);
        btns[1].onclick = gantt.bind(function () {
          _change_duration(1 * gantt.config.duration_step);
        }, this);
        s[0].onchange = _calc_date;
        s[1].onchange = _calc_date;
        s[2].onchange = _calc_date;
        if (s[3]) s[3].onchange = _calc_date;

        duration.onkeydown = gantt.bind(function (e) {
          var code;

          e = e || window.event;
          code = (e.charCode || e.keyCode || e.which);

          if (code == gantt.constants.KEY_CODES.DOWN) {
            _change_duration(-1 * gantt.config.duration_step);
            return false;
          }

          if (code == gantt.constants.KEY_CODES.UP) {
            _change_duration(1 * gantt.config.duration_step);
            return false;
          }
          window.setTimeout(_calc_date, 1);
        }, this);

        duration.onchange = gantt.bind(_calc_date, this);

        mapping = gantt._resolve_default_mapping(config);
        if (typeof (mapping) === "string") mapping = { start_date: mapping };

        start_date = ev[mapping.start_date] || new Date();
        end_date = ev[mapping.end_date] || gantt.calculateEndDate({
          start_date: start_date,
          duration: 1,
          task: ev
        });
        duration_val = Math.round(ev[mapping.duration]) || gantt.calculateDuration({
          start_date: start_date,
          end_date: end_date,
          task: ev
        });

        gantt.form_blocks._fill_lightbox_select(s, 0, start_date, map, cfg);
        duration.value = duration_val;
        _calc_date();
      };

      DurationControl.prototype.get_value = function (node, ev, config) {
        var startDate = _getStartDate(node, config);
        var duration = _getDuration(node, config);
        var endDate = gantt.calculateEndDate({ start_date: startDate, duration: duration, task: ev });

        if (typeof gantt._resolve_default_mapping(config) == "string") {
          return startDate;
        }

        return {
          start_date: startDate,
          end_date: endDate,
          duration: duration
        };
      };

      DurationControl.prototype.focus = function (node) {
        gantt._focus(node.getElementsByTagName("select")[0]);
      };


      function _getStartDate(node, config) {
        var s = node.getElementsByTagName("select");
        var map = config._time_format_order;
        var hours = 0;
        var minutes = 0;

        if (gantt.defined(map[3])) {
          var input = s[map[3]];
          var time = parseInt(input.value, 10);
          if (isNaN(time) && input.hasAttribute("data-value")) {
            time = parseInt(input.getAttribute("data-value"), 10);
          }

          hours = Math.floor(time / 60);
          minutes = time % 60;
        }
        return new Date(s[map[2]].value, s[map[1]].value, s[map[0]].value, hours, minutes);
      }

      function _getDuration(node, ...args) {
        var duration = node.getElementsByTagName("input")[1];

        duration = parseInt(duration.value, 10);
        if (!duration || window/*.isNaN(duration)*/) {
          duration = 1;
        }
        if (duration < 0) duration *= -1;
        return duration;
      }


      return DurationControl;
    };

  }

  parentControlJs = function () {

    var __extends = this.helperService.extends;

    return function (gantt) {
      var _super = this.superJs(gantt);

      function ParentControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(ParentControl, _super);


      ParentControl.prototype.render = function (sns) {
        return _display(sns, false);
      };

      ParentControl.prototype.set_value = function (node, value, ev, config) {
        var tmpDom = document.createElement("div");
        tmpDom.innerHTML = _display(config, ev.id);
        var newOptions = tmpDom.removeChild(tmpDom.firstChild);
        node.onselect = null;
        node.parentNode.replaceChild(newOptions, node);

        return gantt.form_blocks.select.set_value.apply(gantt, [newOptions, value, ev, config]);
      };

      function _display(config, item_id) {
        var tasks = [],
          options = [];
        if (item_id) {
          tasks = gantt.getTaskByTime();
          if (config.allow_root) {
            tasks.unshift({ id: gantt.config.root_id, text: config.root_label || "" });
          }
          tasks = _filter(tasks, config, item_id);
          if (config.sort) {
            tasks.sort(config.sort);
          }
        }
        var text = config.template || gantt.templates.task_text;
        for (var i = 0; i < tasks.length; i++) {
          var label = text.apply(gantt, [tasks[i].start_date, tasks[i].end_date, tasks[i]]);
          if (label === undefined) {
            label = "";
          }
          options.push({
            key: tasks[i].id,
            label: label
          });
        }
        config.options = options;
        config.map_to = config.map_to || "parent";
        return gantt.form_blocks.select.render.apply(this, arguments);
      }

      function _filter(options, config, item_id) {
        var filter = config.filter || function () {
          return true;
        };

        options = options.slice(0);

        for (var i = 0; i < options.length; i++) {
          var task = options[i];
          if (task.id == item_id || gantt.isChildOf(task.id, item_id) || filter(task.id, task) === false) {
            options.splice(i, 1);
            i--;
          }
        }
        return options;
      }
      return ParentControl;
    };

  }

  constraintControlJs = function () {

    var __extends = this.helperService.extends;
    var htmlHelpers = this.helperService.htmlHelpers;

    return function (gantt) {
      var _super = this.superJs(gantt);

      function ConstraintControl() {
        var self = _super.apply(this, arguments) || this;
        return self;
      }

      __extends(ConstraintControl, _super);

      function isNonTimedConstraint(value) {
        if (!value || value === gantt.config.constraint_types.ASAP || value === gantt.config.constraint_types.ALAP) {
          return true;
        } else {
          return false;
        }
      }

      function toggleTimeSelect(timeSelects, typeValue) {
        var isNonTimed = isNonTimedConstraint(typeValue);
        for (var i = 0; i < timeSelects.length; i++) {
          timeSelects[i].disabled = isNonTimed;
        }
      }

      ConstraintControl.prototype.render = function (sns) {
        var height = (sns.height || 30) + "px";
        var html = "<div class='gantt_cal_ltext gantt_section_" + sns.name + "' style='height:" + height + ";'>";

        var options = [];
        for (var i in gantt.config.constraint_types) {
          options.push({ key: gantt.config.constraint_types[i], label: gantt.locale.labels[gantt.config.constraint_types[i]] });
        }

        sns.options = sns.options || options;

        html += "<span data-constraint-type-select>" + htmlHelpers.getHtmlSelect(sns.options, [{ key: "data-type", value: "constraint-type" }]) + "</span>";

        var timeLabel = gantt.locale.labels["constraint_date"] || "Constraint date";
        html += "<label data-constraint-time-select>" + timeLabel + ": " + gantt.form_blocks.getTimePicker.call(this, sns) + "</label>";

        html += "</div>";
        return html;
      };

      ConstraintControl.prototype.set_value = function (node, value, task, config) {
        var typeSelect = node.querySelector("[data-constraint-type-select] select");
        var timeSelects = node.querySelectorAll("[data-constraint-time-select] select");
        var map = config._time_format_order;

        var mapping = gantt._resolve_default_mapping(config);

        if (!typeSelect._eventsInitialized) {
          typeSelect.addEventListener("change", function (e) {
            toggleTimeSelect(timeSelects, e.target.value);
          });
          typeSelect._eventsInitialized = true;
        }

        var constraintDate = task[mapping.constraint_date] || new Date();
        gantt.form_blocks._fill_lightbox_select(timeSelects, 0, constraintDate, map, config);

        var constraintType = task[mapping.constraint_type] || gantt.getConstraintType(task);
        typeSelect.value = constraintType;
        toggleTimeSelect(timeSelects, constraintType);
      };

      ConstraintControl.prototype.get_value = function (node, task, config) {
        var typeSelect = node.querySelector("[data-constraint-type-select] select");
        var timeSelects = node.querySelectorAll("[data-constraint-time-select] select");

        var constraintType = typeSelect.value;
        var constraintDate = null;
        if (!isNonTimedConstraint(constraintType)) {
          constraintDate = gantt.form_blocks.getTimePickerValue(timeSelects, config);
        }

        return {
          constraint_type: constraintType,
          constraint_date: constraintDate
        };
      };

      ConstraintControl.prototype.focus = function (node) {
        gantt._focus(node.querySelector("select"));
      };

      return ConstraintControl;
    };

  }

  lightbox = function (gantt) {

    return function (gantt) {
      var domHelpers = this.helperService.domHelpers;
      var helpers = this.helperService;

      var TemplateControl = this.TemplateControlJs;
      var TextareaControl = this.TextareaControlJs;
      var TimeControl = this.TimeControlJs;
      var SelectControl = this.SelectControlJs;
      var CheckboxControl = this.CheckboxControlJs;
      var RadioControl = this.RadioControlJs;
      var DurationControl = this.DurationControlJs;
      var ParentControl = this.ParentControlJs;
      var ResourcesControl = this.ResourcesControlJs;
      var ConstraintControl = this.ConstraintControlJs;


      gantt._lightbox_methods = {};
      gantt._lightbox_template = "<div class='gantt_cal_ltitle'><span class='gantt_mark'>&nbsp;</span><span class='gantt_time'></span><span class='gantt_title'></span></div><div class='gantt_cal_larea'></div>";


      //TODO: gantt._lightbox_id is changed from data.js and accessed from autoscheduling, check if it can be removed from gantt object
      var state = gantt.$services.getService("state");
      state.registerProvider("lightbox", function () {
        return {
          lightbox: gantt._lightbox_id
        };
      });

      gantt.showLightbox = function (id) {
        if (!id || gantt.isReadonly(this.getTask(id))) return;
        if (!this.callEvent("onBeforeLightbox", [id])) return;

        var task = this.getTask(id);

        var box = this.getLightbox(this.getTaskType(task.type));
        this._center_lightbox(box);
        this.showCover();
        this._fill_lightbox(id, box);

        this._waiAria.lightboxVisibleAttr(box);

        this.callEvent("onLightbox", [id]);
      };

      function _is_chart_visible(gantt) {
        var timeline = gantt.$ui.getView("timeline");
        if (timeline && timeline.isVisible()) {
          return true;
        } else {
          return false;
        }
      }

      gantt._get_timepicker_step = function () {
        if (this.config.round_dnd_dates) {
          var step;
          if (_is_chart_visible(this)) {
            var scale = gantt.getScale();
            step = (helpers.getSecondsInUnit(scale.unit) * scale.step) / 60;//timepicker step is measured in minutes
          }

          if (!step || step >= 60 * 24) {
            step = this.config.time_step;
          }
          return step;
        }
        return this.config.time_step;
      };
      gantt.getLabel = function (property, key) {
        var sections = this._get_typed_lightbox_config();
        for (var i = 0; i < sections.length; i++) {
          if (sections[i].map_to == property) {
            var options = sections[i].options;
            for (var j = 0; j < options.length; j++) {
              if (options[j].key == key) {
                return options[j].label;
              }
            }
          }
        }
        return "";
      };

      gantt.updateCollection = function (list_name, collection) {
        collection = collection.slice(0);
        var list = gantt.serverList(list_name);
        if (!list) return false;
        list.splice(0, list.length);
        list.push.apply(list, collection || []);
        gantt.resetLightbox();
      };
      gantt.getLightboxType = function () {
        return this.getTaskType(this._lightbox_type);
      };
      gantt.getLightbox = function (type) {
        var lightboxDiv;
        var fullWidth;
        var html;
        var sns;
        var ds;
        var classNames = "";

        if (type === undefined)
          type = this.getLightboxType();

        if (!this._lightbox || this.getLightboxType() != this.getTaskType(type)) {
          this._lightbox_type = this.getTaskType(type);
          lightboxDiv = document.createElement("div");
          classNames = "gantt_cal_light";
          fullWidth = this._is_lightbox_timepicker();

          if (gantt.config.wide_form || fullWidth)
            classNames += " gantt_cal_light_wide";

          if (fullWidth) {
            gantt.config.wide_form = true;
            classNames += " gantt_cal_light_full";
          }

          lightboxDiv.className = classNames;

          lightboxDiv.style.visibility = "hidden";
          html = this._lightbox_template;

          html += getHtmlButtons(this.config.buttons_left);
          html += getHtmlButtons(this.config.buttons_right, true);

          lightboxDiv.innerHTML = html;

          gantt._waiAria.lightboxAttr(lightboxDiv);

          if (gantt.config.drag_lightbox) {
            lightboxDiv.firstChild.onmousedown = gantt._ready_to_dnd;
            lightboxDiv.firstChild.onselectstart = function () {
              return false;
            };
            lightboxDiv.firstChild.style.cursor = "pointer";
            gantt._init_dnd_events();
          }

          document.body.insertBefore(lightboxDiv, document.body.firstChild);
          this._lightbox = lightboxDiv;

          sns = this._get_typed_lightbox_config(type);
          html = this._render_sections(sns);

          ds = lightboxDiv.querySelector("div.gantt_cal_larea");
          ds.innerHTML = html;

          bindLabelsToInputs(sns);

          //sizes
          this.resizeLightbox();

          this._init_lightbox_events(this);
          lightboxDiv.style.display = "none";
          lightboxDiv.style.visibility = "visible";
        }
        return this._lightbox;
      };

      gantt._render_sections = function (sns) {
        var html = "";
        for (var i = 0; i < sns.length; i++) {
          var block = this.form_blocks[sns[i].type];
          if (!block) continue; //ignore incorrect blocks
          sns[i].id = "area_" + this.uid();

          var display = sns[i].hidden ? " style='display:none'" : "";
          var button = "";
          if (sns[i].button) {
            button = "<div class='gantt_custom_button' data-index='" + i + "'><div class='gantt_custom_button_" + sns[i].button + "'></div><div class='gantt_custom_button_label'>" + this.locale.labels["button_" + sns[i].button] + "</div></div>";
          }
          if (this.config.wide_form) {
            html += "<div class='gantt_wrap_section' " + display + ">";
          }
          html += "<div id='" + sns[i].id + "' class='gantt_cal_lsection'><label>" + button + this.locale.labels["section_" + sns[i].name] + "</label></div>" + block.render.call(this, sns[i]);
          html += "</div>";
        }
        return html;
      };


      gantt.resizeLightbox = function () {
        if (!this._lightbox) return;

        var con = this._lightbox.childNodes[1];
        con.style.height = "0px";
        con.style.height = con.scrollHeight + "px";
        this._lightbox.style.height = con.scrollHeight + this.config.lightbox_additional_height + "px";
        con.style.height = con.scrollHeight + "px"; //it is incredible , how ugly IE can be
      };

      gantt._center_lightbox = function (box) {
        if (box) {
          box.style.display = "block";

          var scroll_top = window.pageYOffset || document.body.scrollTop || document.documentElement.scrollTop;
          var scroll_left = window.pageXOffset || document.body.scrollLeft || document.documentElement.scrollLeft;

          var view_height = window.innerHeight || document.documentElement.clientHeight;

          if (scroll_top) // if vertical scroll on window
            box.style.top = Math.round(scroll_top + Math.max((view_height - box.offsetHeight) / 2, 0)) + "px";
          else // vertical scroll on body
            box.style.top = Math.round(Math.max(((view_height - box.offsetHeight) / 2), 0) + 9) + "px"; // +9 for compatibility with auto tests

          // not quite accurate but used for compatibility reasons
          if (document.documentElement.scrollWidth > document.body.offsetWidth) // if horizontal scroll on the window
            box.style.left = Math.round(scroll_left + (document.body.offsetWidth - box.offsetWidth) / 2) + "px";
          else // horizontal scroll on the body
            box.style.left = Math.round((document.body.offsetWidth - box.offsetWidth) / 2) + "px";
        }
      };
      gantt.showCover = function () {
        if (this._cover) return;

        this._cover = document.createElement("DIV");
        this._cover.className = "gantt_cal_cover";
        var _document_height = ((document !== undefined) ? document.body.clientHeight : document.body.offsetHeight);
        var _scroll_height = ((document.documentElement) ? document.documentElement.scrollHeight : 0);
        this._cover.style.height = Math.max(_document_height, _scroll_height) + "px";
        document.body.appendChild(this._cover);
      };


      gantt._init_lightbox_events = function () {
        gantt.lightbox_events = {};


        gantt.lightbox_events.gantt_save_btn = function () {
          gantt._save_lightbox();
        };


        gantt.lightbox_events.gantt_delete_btn = function () {
          if (!gantt.callEvent("onLightboxDelete", [gantt._lightbox_id]))
            return;

          if (gantt.isTaskExists(gantt._lightbox_id)) {
            gantt.$click.buttons["delete"](gantt._lightbox_id);
          } else {
            gantt.hideLightbox();
          }

        };


        gantt.lightbox_events.gantt_cancel_btn = function () {
          gantt._cancel_lightbox();
        };


        gantt.lightbox_events["default"] = function (e, src) {
          if (src.getAttribute("data-dhx-button")) {
            gantt.callEvent("onLightboxButton", [src.className, src, e]);
          } else {
            var index, block, sec;

            var className = domHelpers.getClassName(src);
            if (className.indexOf("gantt_custom_button") != -1) {
              if (className.indexOf("gantt_custom_button_") != -1) {
                index = src.parentNode.getAttribute("data-index");
                sec = src;
                while (sec && domHelpers.getClassName(sec).indexOf("gantt_cal_lsection") == -1) {
                  sec = sec.parentNode;
                }
              } else {
                index = src.getAttribute("data-index");
                sec = src.parentNode;
                src = src.firstChild;
              }
            }

            var sections = gantt._get_typed_lightbox_config();

            if (index) {
              index = index * 1;
              block = gantt.form_blocks[sections[index * 1].type];
              block.button_click(index, src, sec, sec.nextSibling);
            }
          }
        };
        this.event(gantt.getLightbox(), "click", function (e) {
          e = e || window.event;
          var src = e.target ? e.target : e.srcElement;

          var className = domHelpers.getClassName(src);
          if (!className) {
            src = src.previousSibling;
            className = domHelpers.getClassName(src);
          }
          if (src && className && className.indexOf("gantt_btn_set") === 0) {
            src = src.firstChild;
            className = domHelpers.getClassName(src);
          }
          if (src && className) {
            var func = gantt.defined(gantt.lightbox_events[src.className]) ? gantt.lightbox_events[src.className] : gantt.lightbox_events["default"];
            return func(e, src);
          }
          return false;
        });

        gantt.getLightbox().onkeydown = function (e) {
          var event = e || window.event;
          var target = e.target || e.srcElement;
          var buttonTarget = domHelpers.getClassName(target).indexOf("gantt_btn_set") > -1;

          switch ((e || event).keyCode) {
            case gantt.constants.KEY_CODES.SPACE: {
              if ((e || event).shiftKey) return;
              if (buttonTarget && target.click) {
                target.click();
              }
              break;
            }
            case gantt.keys.edit_save:
              if ((e || event).shiftKey) return;
              if (buttonTarget && target.click) {
                target.click();
              } else {
                gantt._save_lightbox();
              }
              break;
            case gantt.keys.edit_cancel:
              gantt._cancel_lightbox();
              break;
            default:
              break;
          }
        };
      };

      gantt._cancel_lightbox = function () {
        var task = this.getLightboxValues();
        this.callEvent("onLightboxCancel", [this._lightbox_id, task.$new]);
        if (gantt.isTaskExists(task.id) && task.$new) {
          this.silent(function () {
            gantt.$data.tasksStore.removeItem(task.id);
            gantt._update_flags(task.id, null);
          });
        }

        this.refreshData();
        this.hideLightbox();
      };

      gantt._save_lightbox = function () {
        var task = this.getLightboxValues();
        if (!this.callEvent("onLightboxSave", [this._lightbox_id, task, !!task.$new]))
          return;

        if (task.$new) {
          delete task.$new;
          this.addTask(task, task.parent, this.getTaskIndex(task.id));
        } else if (this.isTaskExists(task.id)) {
          this.mixin(this.getTask(task.id), task, true);
          this.refreshTask(task.id);
          this.updateTask(task.id);
        }
        this.refreshData();

        // TODO: do we need any blockable events here to prevent closing lightbox?
        this.hideLightbox();
      };

      gantt._resolve_default_mapping = function (section) {
        var mapping = section.map_to;
        var time_controls = { "time": true, "time_optional": true, "duration": true, "duration_optional": true };
        if (time_controls[section.type]) {
          if (section.map_to == "auto") {
            mapping = { start_date: "start_date", end_date: "end_date", duration: "duration" };
          } else if (typeof (section.map_to) === "string") {
            mapping = { start_date: section.map_to };
          }
        } else if (section.type === "constraint") {
          if (!section.map_to || typeof (section.map_to) === "string") {
            mapping = { constraint_type: "constraint_type", constraint_date: "constraint_date" };
          }
        }

        return mapping;
      };

      gantt.getLightboxValues = function () {
        var task = {};

        if (gantt.isTaskExists(this._lightbox_id)) {
          task = this.mixin({}, this.getTask(this._lightbox_id));
        }

        var sns = this._get_typed_lightbox_config();
        for (var i = 0; i < sns.length; i++) {
          var node: any = document.getElementById(sns[i].id);
          node = (node ? node.nextSibling : node);
          var block = this.form_blocks[sns[i].type];
          if (!block) continue;
          var res = block.get_value.call(this, node, task, sns[i]);
          var map_to = gantt._resolve_default_mapping(sns[i]);
          if (typeof map_to == "string" && map_to != "auto") {
            task[map_to] = res;
          } else if (typeof map_to == "object") {
            for (var property in map_to) {
              if (map_to[property])
                task[map_to[property]] = res[property];
            }
          }
        }
        return task;
      };


      gantt.hideLightbox = function () {
        var box = this.getLightbox();
        if (box) box.style.display = "none";

        this._waiAria.lightboxHiddenAttr(box);
        this._lightbox_id = null;

        this.hideCover();
        this.callEvent("onAfterLightbox", []);
      };
      gantt.hideCover = function () {
        if (this._cover)
          this._cover.parentNode.removeChild(this._cover);
        this._cover = null;
      };

      gantt.resetLightbox = function () {
        if (gantt._lightbox && !gantt._custom_lightbox)
          gantt._lightbox.parentNode.removeChild(gantt._lightbox);
        gantt._lightbox = null;
        gantt.hideCover();
      };
      gantt._set_lightbox_values = function (data, box) {
        var task = data;
        var s = box.getElementsByTagName("span");
        var lightboxHeader = [];
        if (gantt.templates.lightbox_header) {
          lightboxHeader.push("");
          lightboxHeader.push(gantt.templates.lightbox_header(task.start_date, task.end_date, task));
          s[1].innerHTML = "";
          s[2].innerHTML = gantt.templates.lightbox_header(task.start_date, task.end_date, task);
        } else {
          lightboxHeader.push(this.templates.task_time(task.start_date, task.end_date, task));
          lightboxHeader.push(String(this.templates.task_text(task.start_date, task.end_date, task) || "").substr(0, 70)); //IE6 fix
          s[1].innerHTML = this.templates.task_time(task.start_date, task.end_date, task);
          s[2].innerHTML = String(this.templates.task_text(task.start_date, task.end_date, task) || "").substr(0, 70); //IE6 fix
        }
        s[1].innerHTML = lightboxHeader[0];
        s[2].innerHTML = lightboxHeader[1];

        gantt._waiAria.lightboxHeader(box, lightboxHeader.join(" "));

        var sns = this._get_typed_lightbox_config(this.getLightboxType());
        for (var i = 0; i < sns.length; i++) {
          var section = sns[i];

          if (!this.form_blocks[section.type]) {
            continue;//skip incorrect sections, same check is done during rendering
          }


          var node = document.getElementById(section.id).nextSibling;
          var block = this.form_blocks[section.type];
          var map_to = gantt._resolve_default_mapping(sns[i]);
          var value = this.defined(task[map_to]) ? task[map_to] : section.default_value;
          block.set_value.call(gantt, node, value, task, section);

          if (section.focus)
            block.focus.call(gantt, node);
        }
        if (data.id)
          gantt._lightbox_id = data.id;
      };
      gantt._fill_lightbox = function (id, box) {
        var task = this.getTask(id);
        this._set_lightbox_values(task, box);
      };


      gantt.getLightboxSection = function (name) {
        var config = this._get_typed_lightbox_config();
        var i = 0;
        for (i; i < config.length; i++)
          if (config[i].name == name)
            break;
        var section = config[i];
        if (!section)
          return null;

        if (!this._lightbox)
          this.getLightbox();
        var header = document.getElementById(section.id);
        var node = header.nextSibling;

        var result = {
          section: section,
          header: header,
          node: node,
          getValue: function (ev) {
            return gantt.form_blocks[section.type].get_value.call(gantt, node, (ev || {}), section);
          },
          setValue: function (value, ev) {
            return gantt.form_blocks[section.type].set_value.call(gantt, node, value, (ev || {}), section);
          }
        };

        var handler = this._lightbox_methods["get_" + section.type + "_control"];
        return handler ? handler(result) : result;
      };

      gantt._lightbox_methods.get_template_control = function (result) {
        result.control = result.node;
        return result;
      };
      gantt._lightbox_methods.get_select_control = function (result) {
        result.control = result.node.getElementsByTagName("select")[0];
        return result;
      };
      gantt._lightbox_methods.get_textarea_control = function (result) {
        result.control = result.node.getElementsByTagName("textarea")[0];
        return result;
      };
      gantt._lightbox_methods.get_time_control = function (result) {
        result.control = result.node.getElementsByTagName("select"); // array
        return result;
      };


      gantt._init_dnd_events = function () {
        this.event(document.body, "mousemove", gantt._move_while_dnd);
        this.event(document.body, "mouseup", gantt._finish_dnd);
        gantt._init_dnd_events = function () {
        };
      };
      gantt._move_while_dnd = function (e) {
        if (gantt._dnd_start_lb) {
          // if (!document.gantt_unselectable) {
          //   document.body.className += " gantt_unselectable";
          //   document.gantt_unselectable = true;
          // }
          var lb = gantt.getLightbox();
          var now = (e && e.target) ? [e.pageX, e.pageY] : [e.clientX, e.clientY];
          lb.style.top = gantt._lb_start[1] + now[1] - gantt._dnd_start_lb[1] + "px";
          lb.style.left = gantt._lb_start[0] + now[0] - gantt._dnd_start_lb[0] + "px";
        }
      };
      gantt._ready_to_dnd = function (e) {
        var lb = gantt.getLightbox();
        gantt._lb_start = [parseInt(lb.style.left, 10), parseInt(lb.style.top, 10)];
        gantt._dnd_start_lb = (e && e.target) ? [e.pageX, e.pageY] : [e.clientX, e.clientY];
      };
      gantt._finish_dnd = function () {
        if (gantt._lb_start) {
          gantt._lb_start = gantt._dnd_start_lb = false;
          document.body.className = document.body.className.replace(" gantt_unselectable", "");
          // document.gantt_unselectable = false;
        }
      };


      gantt._focus = function (node, select) {
        if (node && node.focus) {
          if (gantt.config.touch) {
            //do not focus editor, to prevent auto-zoom
          } else {
            try {
              if (select && node.select) node.select();
              node.focus();
            } catch (e) {
              // silent errors
            }
          }
        }
      };


      gantt.form_blocks = {
        getTimePicker: function (sns, hidden) {
          var html = "";
          var cfg = this.config;
          var i;
          var options;
          var ariaAttrs;
          var readonly;
          var display;
          var settings = {
            first: 0,
            last: 24 * 60,
            date: this.date.date_part(new Date(gantt._min_date.valueOf())),
            timeFormat: getTimeFormat(sns)
          };

          // map: default order => real one
          sns._time_format_order = { size: 0 };

          if (gantt.config.limit_time_select) {
            settings.first = 60 * cfg.first_hour;
            settings.last = 60 * cfg.last_hour + 1;
            settings.date.setHours(cfg.first_hour);
          }

          for (i = 0; i < settings.timeFormat.length; i++) {
            // adding spaces between selects
            if (i > 0) {
              html += " ";
            }

            options = getHtmlTimePickerOptions(sns, i, settings);

            if (options) {
              ariaAttrs = gantt._waiAria.lightboxSelectAttrString(settings.timeFormat[i]);
              readonly = sns.readonly ? "disabled='disabled'" : "";
              display = hidden ? " style='display:none' " : "";
              html += "<select " + readonly + display + ariaAttrs + ">" + options + "</select>";
            }
          }
          return html;
        },
        getTimePickerValue: function (selects, config, offset) {
          var map = config._time_format_order;
          var needSetTime = gantt.defined(map[3]);

          var time;
          var hours = 0;
          var minutes = 0;

          var mapOffset = offset || 0;

          if (needSetTime) {
            time = parseInt(selects[map[3] + mapOffset].value, 10);
            hours = Math.floor(time / 60);
            minutes = time % 60;
          }
          return new Date(selects[map[2] + mapOffset].value, selects[map[1] + mapOffset].value, selects[map[0] + mapOffset].value, hours, minutes);
        },

        _fill_lightbox_select: function (s, i, d, map) {
          s[i + map[0]].value = d.getDate();
          s[i + map[1]].value = d.getMonth();
          s[i + map[2]].value = d.getFullYear();
          if (gantt.defined(map[3])) {
            var v = d.getHours() * 60 + d.getMinutes();
            v = Math.round(v / gantt._get_timepicker_step()) * gantt._get_timepicker_step();
            var input = s[i + map[3]];
            input.value = v;
            //in case option not shown
            input.setAttribute("data-value", v);
          }
        },
        template: new TemplateControl(),
        textarea: new TextareaControl(),
        select: new SelectControl(),
        time: new TimeControl(),
        duration: new DurationControl(),
        parent: new ParentControl(),
        radio: new RadioControl(),
        checkbox: new CheckboxControl(),
        resources: new ResourcesControl(),
        constraint: new ConstraintControl()
      };

      gantt._is_lightbox_timepicker = function () {
        var s = this._get_typed_lightbox_config();
        for (var i = 0; i < s.length; i++)
          if (s[i].name == "time" && s[i].type == "time")
            return true;
        return false;
      };

      gantt._dhtmlx_confirm = function (message, title, callback, ok) {
        if (!message)
          return callback();
        var opts: any = { text: message };
        if (title)
          opts.title = title;
        if (ok) {
          opts.ok = ok;
        }
        if (callback) {
          opts.callback = function (result) {
            if (result)
              callback();
          };
        }
        gantt.confirm(opts);
      };

      function _get_type_name(type_value) {
        for (var i in this.config.types) {
          if (this.config.types[i] == type_value) {
            return i;
          }
        }
        return "task";
      }

      gantt._get_typed_lightbox_config = function (type) {
        if (type === undefined) {
          type = this.getLightboxType();
        }

        var field = _get_type_name.call(this, type);

        if (gantt.config.lightbox[field + "_sections"]) {
          return gantt.config.lightbox[field + "_sections"];
        } else {
          return gantt.config.lightbox.sections;
        }
      };

      gantt._silent_redraw_lightbox = function (type) {
        var oldType = this.getLightboxType();

        if (this.getState().lightbox) {
          var taskId = this.getState().lightbox;
          var formData = this.getLightboxValues(),
            task = this.copy(this.getTask(taskId));

          this.resetLightbox();

          var updTask = this.mixin(task, formData, true);
          var box = this.getLightbox(type ? type : undefined);
          this._center_lightbox(this.getLightbox());
          this._set_lightbox_values(updTask, box);
          this.showCover();
        } else {
          this.resetLightbox();
          this.getLightbox(type ? type : undefined);
        }
        this.callEvent("onLightboxChange", [oldType, this.getLightboxType()]);
      };

      function bindLabelsToInputs(sns) {
        var section;
        var label;
        var labelBlock;
        var inputBlock;
        var input;
        var i;

        for (i = 0; i < sns.length; i++) {
          section = sns[i];
          labelBlock = document.getElementById(section.id);

          if (!section.id || !labelBlock) continue;

          label = labelBlock.querySelector("label");
          inputBlock = labelBlock.nextSibling;

          if (!inputBlock) continue;

          input = inputBlock.querySelector("input, select, textarea");
          if (input) {
            input.id = input.id || "input_" + gantt.uid();
            section.inputId = input.id;
            label.setAttribute("for", section.inputId);
          }
        }
      }

      function getHtmlButtons(buttons, floatRight?) {
        var button;
        var ariaAttr;
        var html = "";
        var i;

        for (i = 0; i < buttons.length; i++) {
          // needed to migrate from 'dhx_something' to 'gantt_something' naming in a lightbox
          button = gantt.config._migrate_buttons[buttons[i]] ? gantt.config._migrate_buttons[buttons[i]] : buttons[i];

          ariaAttr = gantt._waiAria.lightboxButtonAttrString(button);
          html += "<div " + ariaAttr + " class='gantt_btn_set gantt_left_btn_set " + button + "_set'" + (floatRight ? " style='float:right;'" : "") + "><div dhx_button='1' data-dhx-button='1' class='" + button + "'></div><div>" + gantt.locale.labels[button] + "</div></div>";
        }
        return html;
      }

      function getTimeFormat(sns) {
        var scale;
        var unit;
        var result;

        if (sns.time_format) return sns.time_format;

        // default order
        result = ["%d", "%m", "%Y"];
        scale = gantt.getScale();
        unit = scale ? scale.unit : gantt.config.duration_unit;
        if (helpers.getSecondsInUnit(unit) < helpers.getSecondsInUnit("day")) {
          result.push("%H:%i");
        }
        return result;
      }

      function getHtmlTimePickerOptions(sns, index, settings) {
        var range;
        var offset;
        var start_year;
        var end_year;
        var i;
        var time;
        var diff;
        var tdate;
        var html = "";

        switch (settings.timeFormat[index]) {
          case "%Y":
            sns._time_format_order[2] = index;
            sns._time_format_order.size++;
            //year

            if (sns.year_range) {
              if (!isNaN(sns.year_range)) {
                range = sns.year_range;
              } else if (sns.year_range.push) {
                // if
                start_year = sns.year_range[0];
                end_year = sns.year_range[1];
              }
            }

            range = range || 10;
            offset = offset || Math.floor(range / 2);
            start_year = start_year || settings.date.getFullYear() - offset;
            end_year = end_year || start_year + range;

            for (i = start_year; i < end_year; i++)
              html += "<option value='" + (i) + "'>" + (i) + "</option>";
            break;
          case "%m":
            sns._time_format_order[1] = index;
            sns._time_format_order.size++;
            //month
            for (i = 0; i < 12; i++)
              html += "<option value='" + i + "'>" + gantt.locale.date.month_full[i] + "</option>";
            break;
          case "%d":
            sns._time_format_order[0] = index;
            sns._time_format_order.size++;
            //days
            for (i = 1; i < 32; i++)
              html += "<option value='" + i + "'>" + i + "</option>";
            break;
          case "%H:%i":
            //  var last = 24*60, first = 0;
            sns._time_format_order[3] = index;
            sns._time_format_order.size++;
            //hours
            i = settings.first;
            tdate = settings.date.getDate();
            sns._time_values = [];

            while (i < settings.last) {
              time = gantt.templates.time_picker(settings.date);
              html += "<option value='" + i + "'>" + time + "</option>";
              sns._time_values.push(i);
              settings.date.setTime(settings.date.valueOf() + gantt._get_timepicker_step() * 60 * 1000);
              diff = (settings.date.getDate() != tdate) ? 1 : 0; // moved or not to the next day
              i = diff * 24 * 60 + settings.date.getHours() * 60 + settings.date.getMinutes();
            }
            break;
          default:
            break;
        }
        return html;
      }
    };

  }

  lightboxOptionalTime = function (gantt) {

    return function (gantt) {

      gantt._extend_to_optional = function (lightbox_block) {

        var duration = lightbox_block;
        var optional_time = {
          render: duration.render,
          focus: duration.focus,
          set_value: function (node, value, task, section) {
            var mapping = gantt._resolve_default_mapping(section);
            if (!task[mapping.start_date] || (mapping.start_date == "start_date" && this._isAllowedUnscheduledTask(task))) {
              optional_time.disable(node, section);
              var val = {};

              for (var i in mapping) {
                //take default values from the time control from task start/end dates
                val[mapping[i]] = task[i];
              }

              return duration.set_value.call(gantt, node, value, val, section);//set default value
            } else {
              optional_time.enable(node, section);
              return duration.set_value.call(gantt, node, value, task, section);
            }
          },
          get_value: function (node, task, section) {
            if (section.disabled) {
              return { start_date: null };
            } else {
              return duration.get_value.call(gantt, node, task, section);
            }
          },
          update_block: function (node, section) {
            gantt.callEvent("onSectionToggle", [gantt._lightbox_id, section]);
            node.style.display = section.disabled ? "none" : "block";

            if (section.button) {
              var button = node.previousSibling.querySelector(".gantt_custom_button_label"),
                labels = gantt.locale.labels;

              var button_text = section.disabled ? labels[section.name + "_enable_button"] : labels[section.name + "_disable_button"];

              button.innerHTML = button_text;
            }
            gantt.resizeLightbox();
          },
          disable: function (node, section) {
            section.disabled = true;
            optional_time.update_block(node, section);

          },
          enable: function (node, section) {
            section.disabled = false;
            optional_time.update_block(node, section);
          },
          button_click: function (index, el, section, container) {
            if (gantt.callEvent("onSectionButton", [gantt._lightbox_id, section]) === false) {
              return;
            }
            var config = gantt._get_typed_lightbox_config()[index];
            if (config.disabled) {
              optional_time.enable(container, config);
            } else {
              optional_time.disable(container, config);
            }
          }
        };
        return optional_time;
      };

      gantt.form_blocks.duration_optional = gantt._extend_to_optional(gantt.form_blocks.duration);
      gantt.form_blocks.time_optional = gantt._extend_to_optional(gantt.form_blocks.time);

    };
  }

  dataTaskType = function (gantt) {

    return function (gantt) {

      gantt.getTaskType = function (type) {
        return "task";
      };
    };
  }

  cachedFunctions = function (gantt) {

    /*
     reuse results of functions that can be recalculated during rendering
     greatly increases the rendering speed when critical path enabled
     Sample - 94_dev/critical_path.html
    
     */
    return function (gantt) {

      gantt._cached_functions = {
        cache: {},
        mode: false,
        critical_path_mode: false,
        wrap_methods: function (methods, object) {
          if (object._prefetch_originals) {
            for (var i in object._prefetch_originals) {
              object[i] = object._prefetch_originals[i];
            }
          }
          object._prefetch_originals = {};
          for (let i = 0; i < methods.length; i++)
            this.prefetch(methods[i], object);

        },
        prefetch: function (methodname, host) {
          var original = host[methodname];
          if (original) {
            var optimizer = this;

            host._prefetch_originals[methodname] = original;
            host[methodname] = function get_prefetched_value() {

              var argumentsArray = new Array(arguments.length);
              for (var i = 0, l = arguments.length; i < l; i++) {
                argumentsArray[i] = arguments[i];
              }

              if (optimizer.active) {
                var args = optimizer.get_arguments_hash(Array.prototype.slice.call(argumentsArray));
                if (!optimizer.cache[methodname]) {
                  optimizer.cache[methodname] = {};
                }

                var cached_values = optimizer.cache[methodname];

                if (optimizer.has_cached_value(cached_values, args)) {
                  return optimizer.get_cached_value(cached_values, args);
                } else {
                  var value = original.apply(this, argumentsArray);
                  optimizer.cache_value(cached_values, args, value);
                  return value;
                }
              }

              return original.apply(this, argumentsArray);
            };
          }
          return original;
        },
        cache_value: function (cache, arguments_hash, value) {
          if (this.is_date(value))
            value = new Date(value);
          cache[arguments_hash] = value;
        },
        has_cached_value: function (cache, arguments_hash) {
          return cache.hasOwnProperty(arguments_hash);
        },
        get_cached_value: function (cache, arguments_hash) {
          var data = cache[arguments_hash];

          //for cached dates - return copy
          if (this.is_date(data)) {
            data = new Date(data);
          }
          return data;
        },
        is_date: function (value) {
          return (value && value.getUTCDate);
        },
        get_arguments_hash: function (args) {
          var values = [];
          for (var i = 0; i < args.length; i++) {
            values.push(this.stringify_argument(args[i]));
          }
          return "(" + values.join(";") + ")";
        },
        stringify_argument: function (value) {
          //expecting task or link, or any other data entries, dates and primitive values
          var ret = "";
          if (value.id) {
            ret = value.id;
          } else if (this.is_date(value)) {
            ret = value.valueOf();
          } else {
            ret = value;
          }
          return ret + "";
        },
        activate: function () {
          this.clear();
          this.active = true;
        },
        deactivate: function () {
          this.clear();
          this.active = false;
        },
        clear: function () {
          this.cache = {};
        },

        setup: function (gantt) {
          var override_gantt = [];

          var gantt_methods = [
            '_isProjectEnd',
            '_getProjectEnd',
            '_getSlack'
          ];



          if (this.mode == 'auto') {
            if (gantt.config.highlight_critical_path) {
              override_gantt = gantt_methods;
            }
          } else if (this.mode === true) {
            override_gantt = gantt_methods;
          }

          this.wrap_methods(override_gantt, gantt);

        },
        update_if_changed: function (gantt) {
          var changed = (this.critical_path_mode != gantt.config.highlight_critical_path ||
            this.mode !== gantt.config.optimize_render);
          if (changed) {
            this.critical_path_mode = gantt.config.highlight_critical_path;
            this.mode = gantt.config.optimize_render;
            this.setup(gantt);
          }
        }
      };

      function activate() {
        gantt._cached_functions.update_if_changed(gantt);
        if (!gantt._cached_functions.active) {
          gantt._cached_functions.activate();
        }
        return true;
      }
      gantt.attachEvent("onBeforeGanttRender", activate);
      gantt.attachEvent("onBeforeDataRender", activate);
      gantt.attachEvent("onBeforeSmartRender", function () {
        activate();
      });
      gantt.attachEvent("onBeforeParse", activate);
      gantt.attachEvent("onDataRender", function () {
        gantt._cached_functions.deactivate();
      });
      var deactivTimeout = null;
      gantt.attachEvent("onSmartRender", function () {
        if (deactivTimeout)
          clearTimeout(deactivTimeout);
        deactivTimeout = setTimeout(function () {
          gantt._cached_functions.deactivate();
        }, 1000);
      });

      gantt.attachEvent("onBeforeGanttReady", function () {
        gantt._cached_functions.update_if_changed(gantt);
        return true;
      });

    };
  }

  skin = function (gantt) {

    function _configure(col, data, force) {
      for (var key in data)
        if (typeof col[key] == "undefined" || force)
          col[key] = data[key];
    }

    function _get_skin(force, gantt) {
      var skin = gantt.skin;
      if (!skin || force) {
        var links = document.getElementsByTagName("link");
        for (var i = 0; i < links.length; i++) {
          var res = links[i].href.match("dhtmlxgantt_([a-z_]+).css");
          if (res) {
            if (gantt.skins[res[1]] || !skin) {
              skin = res[1];
              break;
            }
          }
        }
      }

      gantt.skin = skin || "terrace";
      var skinset = gantt.skins[gantt.skin] || gantt.skins["terrace"];

      //apply skin related settings
      _configure(gantt.config, skinset.config, force);

      var config = gantt.getGridColumns();
      if (config[1] && !gantt.defined(config[1].width))
        config[1].width = skinset._second_column_width;
      if (config[2] && !gantt.defined(config[2].width))
        config[2].width = skinset._third_column_width;

      for (var i = 0; i < config.length; i++) {
        var column = config[i];
        if (column.name == "add") {
          if (!column.width) {
            column.width = 44;
          }
          if (!(gantt.defined(column.min_width) && gantt.defined(column.max_width))) {
            column.min_width = column.min_width || column.width;
            column.max_width = column.max_width || column.width;
          }
          if (column.min_width)
            column.min_width = +column.min_width;
          if (column.max_width)
            column.max_width = +column.max_width;
          if (column.width) {
            column.width = +column.width;
            column.width = (column.min_width && column.min_width > column.width) ? column.min_width : column.width;
            column.width = (column.max_width && column.max_width < column.width) ? column.max_width : column.width;
          }
        }
      }

      if (skinset.config.task_height)
        gantt.config.task_height = skinset.config.task_height || "full";

      if (skinset._lightbox_template)
        gantt._lightbox_template = skinset._lightbox_template;

      if (skinset._redefine_lightbox_buttons) {
        gantt.config.buttons_right = skinset._redefine_lightbox_buttons["buttons_right"];
        gantt.config.buttons_left = skinset._redefine_lightbox_buttons["buttons_left"];
      }


      gantt.resetLightbox();
    }

    return function (gantt) {
      if (!gantt.resetSkin) {
        gantt.resetSkin = function () {
          this.skin = "";
          _get_skin(true, this);
        };
        gantt.skins = {};

        gantt.attachEvent("onGanttLayoutReady", function () {
          _get_skin(false, this);
        });
      }
    };
  }

  touch = function (gantt) {

    return function (gantt) {

      gantt.config.touch_drag = 500; //nearly immediate dnd
      gantt.config.touch = true;
      gantt.config.touch_feedback = true;
      gantt.config.touch_feedback_duration = 1;
      gantt._prevent_touch_scroll = false;


      gantt._touch_feedback = function () {
        if (gantt.config.touch_feedback) {
          if (navigator.vibrate)
            navigator.vibrate(gantt.config.touch_feedback_duration);
        }
      };

      gantt.attachEvent("onGanttReady", gantt.bind(function () {
        if (this.config.touch != "force")
          this.config.touch = this.config.touch &&
            ((navigator.userAgent.indexOf("Mobile") != -1) ||
              (navigator.userAgent.indexOf("iPad") != -1) ||
              (navigator.userAgent.indexOf("Android") != -1) ||
              (navigator.userAgent.indexOf("Touch") != -1));

        if (this.config.touch) {

          var touchEventsSupported = true;
          try {
            document.createEvent("TouchEvent");
          } catch (e) {
            touchEventsSupported = false;
          }

          if (touchEventsSupported) {
            this._touch_events(["touchmove", "touchstart", "touchend"], function (ev) {
              if (ev.touches && ev.touches.length > 1) return null;
              if (ev.touches[0])
                return {
                  target: ev.target,
                  pageX: ev.touches[0].pageX,
                  pageY: ev.touches[0].pageY,
                  clientX: ev.touches[0].clientX,
                  clientY: ev.touches[0].clientY
                };
              else
                return ev;
            }, function () {
              return false;
            });
          } else if (window.navigator.pointerEnabled) {
            this._touch_events(["pointermove", "pointerdown", "pointerup"], function (ev) {
              if (ev.pointerType == "mouse") return null;
              return ev;
            }, function (ev) {
              return (!ev || (ev.pointerType == "mouse"));
            });
          } else if (window.navigator.msPointerEnabled) {
            this._touch_events(["MSPointerMove", "MSPointerDown", "MSPointerUp"], function (ev) {
              if (ev.pointerType == ev.MSPOINTER_TYPE_MOUSE) return null;
              return ev;
            }, function (ev) {
              return (!ev || ev.pointerType == ev.MSPOINTER_TYPE_MOUSE);
            });
          }

        }
      }, gantt));


      function getTaskDND() {
        var _tasks_dnd;
        if (gantt.$ui.getView("timeline")) {
          _tasks_dnd = gantt.$ui.getView("timeline")._tasks_dnd;
        }
        return _tasks_dnd;
      }

      var touchHandlers = [];

      //we can't use native scrolling, as we need to sync momentum between different parts
      //so we will block native scroll and use the custom one
      //in future we can add custom momentum
      gantt._touch_events = function (names, accessor, ignore) {
        //webkit on android need to be handled separately
        var dblclicktime: any = 0;
        var action_mode = false;
        var scroll_mode = false;
        var action_start = null;
        var scroll_state;
        var long_tap_timer = null;
        var current_target = null;



        for (var i = 0; i < touchHandlers.length; i++) {
          gantt.eventRemove(touchHandlers[i][0], touchHandlers[i][1], touchHandlers[i][2]);
        }
        touchHandlers = [];

        //touch move
        touchHandlers.push([gantt.$container, names[0], function (e) {
          var _tasks_dnd = getTaskDND();

          if (ignore(e)) return;

          //ignore common and scrolling moves
          if (!action_mode) return;

          if (long_tap_timer) clearTimeout(long_tap_timer);

          var source = accessor(e);
          if (_tasks_dnd && (_tasks_dnd.drag.id || _tasks_dnd.drag.start_drag)) {
            _tasks_dnd.on_mouse_move(source);
            if (e.preventDefault)
              e.preventDefault();
            e.cancelBubble = true;
            return false;
          }
          if (!gantt._prevent_touch_scroll) {
            if (source && action_start) {
              var dx = action_start.pageX - source.pageX;
              var dy = action_start.pageY - source.pageY;
              if (!scroll_mode && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) {
                gantt._touch_scroll_active = scroll_mode = true;
                dblclicktime = 0;
                scroll_state = gantt.getScrollState();
              }

              if (scroll_mode) {
                gantt.scrollTo(scroll_state.x + dx, scroll_state.y + dy);
                var new_scroll_state = gantt.getScrollState();

                if ((scroll_state.x != new_scroll_state.x && dy > 2 * dx) ||
                  (scroll_state.y != new_scroll_state.y && dx > 2 * dy)) {
                  return block_action(e);
                }
              }
            }
            return block_action(e);
          }
          return true;
        }]);


        //block touch context menu in IE10
        touchHandlers.push([this.$container, "contextmenu", function (e) {
          if (action_mode)
            return block_action(e);
        }]);

        //touch start
        touchHandlers.push([this.$container, names[1], function (e) {
          if (ignore(e)) return;
          if (e.touches && e.touches.length > 1) {
            action_mode = false;
            return;
          }

          action_start = accessor(e);
          if (!gantt._locate_css(action_start, "gantt_hor_scroll") && !gantt._locate_css(action_start, "gantt_ver_scroll")) {
            action_mode = true;
          }
          var _tasks_dnd = getTaskDND();

          //long tap
          long_tap_timer = setTimeout(function () {
            var taskId = gantt.locate(action_start);
            if (_tasks_dnd && (taskId && !gantt._locate_css(action_start, "gantt_link_control") && !gantt._locate_css(action_start, "gantt_grid_data"))) {
              _tasks_dnd.on_mouse_down(action_start);

              if (_tasks_dnd.drag && _tasks_dnd.drag.start_drag) {
                cloneTaskRendered(taskId);
                _tasks_dnd._start_dnd(action_start);
                gantt._touch_drag = true;

                gantt.refreshTask(taskId);

                gantt._touch_feedback();
              }

            }

            long_tap_timer = null;
          }, gantt.config.touch_drag);
        }]);

        //touch end
        touchHandlers.push([this.$container, names[2], function (e) {
          if (ignore(e)) return;
          if (long_tap_timer) clearTimeout(long_tap_timer);
          gantt._touch_drag = false;
          action_mode = false;
          var source = accessor(e);

          var _tasks_dnd = getTaskDND();

          if (_tasks_dnd)
            _tasks_dnd.on_mouse_up(source);

          if (current_target) {
            gantt.refreshTask(gantt.locate(current_target));
            if (current_target.parentNode) {
              current_target.parentNode.removeChild(current_target);
              gantt._touch_feedback();
            }
          }

          gantt._touch_scroll_active = action_mode = scroll_mode = false;
          current_target = null;

          //dbl-tap handling
          if (action_start && dblclicktime) {
            var now = new Date();
            if ((now.getDate() - dblclicktime) < 500) {

              var mouseEvents = gantt.$services.getService("mouseEvents");
              mouseEvents.onDoubleClick(action_start);
              block_action(e);
            } else
              dblclicktime = now;
          } else {
            dblclicktime = new Date();
          }
        }]);

        for (var i = 0; i < touchHandlers.length; i++) {
          gantt.event(touchHandlers[i][0], touchHandlers[i][1], touchHandlers[i][2]);
        }

        //common helper, prevents event
        function block_action(e) {
          if (e && e.preventDefault)
            e.preventDefault();
          (e || event).cancelBubble = true;
          return false;
        }

        function cloneTaskRendered(taskId) {
          var renders = gantt._getTaskLayers();
          var task = gantt.getTask(taskId);
          if (task && gantt.isTaskVisible(taskId)) {
            for (var i = 0; i < renders.length; i++) {
              task = renders[i].rendered[taskId];
              if (task && task.getAttribute(gantt.config.task_attribute) && task.getAttribute(gantt.config.task_attribute) == taskId) {
                var copy = task.cloneNode(true);
                current_target = task;
                renders[i].rendered[taskId] = copy;
                task.style.display = "none";
                copy.className += " gantt_drag_move ";
                task.parentNode.appendChild(copy);
                //return copy;
              }
            }
          }
        }
      };

    };
  }

  assertJs = function(gantt) {

    /*
       asserts will be removed in final code, so you can place them anythere
      without caring about performance impacts
    */
    
    return function(gantt){
      return function assert(check, message){
        if (!check){
          if(gantt.config.show_errors && gantt.callEvent("onError",[message]) !== false) {
            gantt.message({type: "error", text: message, expire: -1});
    
            // eslint-disable-next-line no-debugger
            // debugger;
          }
        }
      };
    };
  }

  ganttCore(gantt) {

    var domHelpers = this.helperService,
      helpers = this.helperService;

    return function (gantt) {
      var calculateScaleRange = this.calculateScaleRangeJs;

      gantt.assert = this.assertJs(gantt);

      //initial initialization
      gantt.init = function (node, from, to) {
        if (from && to) {
          this.config.start_date = this._min_date = new Date(from);
          this.config.end_date = this._max_date = new Date(to);
        }
        this.date.init();

        if (!this.config.scroll_size)
          this.config.scroll_size = domHelpers.getScrollSize() || 1;

        //can be called only once
        this.init = function (node) {
          if (this.$container && this.$container.parentNode) {
            this.$container.parentNode.removeChild(this.$container);
            this.$container = null;
          }

          if (this.$layout) {
            this.$layout.clear();
          }
          this._reinit(node);
        };

        this._reinit(node);
      };

      gantt._reinit = function (node) {
        this.callEvent("onBeforeGanttReady", []);

        // detach listeners before clearing old DOM, possible IE errors when accessing detached nodes
        this._eventRemoveAll();
        this.$mouseEvents.reset();

        this.resetLightbox();
        this._update_flags();


        var config = this.$services.getService("templateLoader");
        config.initTemplates(this);

        this._clearTaskLayers();
        this._clearLinkLayers();

        //this.clear
        if (this.$layout) {
          this.$layout.destructor();
          this.$ui.reset();
        }

        this.$root = domHelpers.toNode(node);
        if (this.$root) {
          this.$root.innerHTML = "";
        }
        this.$root.gantt = this;
        calculateScaleRange(this);
        this.config.layout.id = "main";
        this.$layout = this.$ui.createView("layout", node, this.config.layout);

        this.$layout.attachEvent("onBeforeResize", function () {
          var storeNames = gantt.$services.getService("datastores");
          for (var i = 0; i < storeNames.length; i++) {
            gantt.getDatastore(storeNames[i]).filter();
          }
        });

        this.$layout.attachEvent("onResize", function () {
          gantt.refreshData();
        });

        this.callEvent("onGanttLayoutReady", []);
        this.$layout.render();

        gantt.$container = this.$layout.$container.firstChild;

        addResizeListener(gantt);

        this.callEvent("onTemplatesReady", []);
        this.$mouseEvents.reset(this.$root);
        this.callEvent("onGanttReady", []);

        this.render();
      };

      function addResizeListener(gantt) {
        var containerStyles = window.getComputedStyle(gantt.$root);
        if (containerStyles.getPropertyValue("position") == "static") {
          gantt.$root.style.position = "relative";
        }

        var resizeWatcher = document.createElement('iframe');
        resizeWatcher.className = "gantt_container_resize_watcher";
        resizeWatcher.tabIndex = -1;

        // in some environments (namely, in SalesForce) iframe.contentWindow is not available
        gantt.$root.appendChild(resizeWatcher);
        if (resizeWatcher.contentWindow) {
          listenWindowResize(gantt, resizeWatcher.contentWindow);
        } else {
          // if so - ditch the iframe and fallback to listening the main window resize
          gantt.$root.removeChild(resizeWatcher);
          listenWindowResize(gantt, window);
        }
      }

      function listenWindowResize(gantt, window) {
        var resizeDelay;
        gantt.event(window, "resize", function () {
          clearTimeout(resizeDelay);
          resizeDelay = setTimeout(function () {
            gantt.render();
          }, 300);
        });
      }

      gantt.$click = {
        buttons: {
          "edit": function (id) {
            gantt.showLightbox(id);
          },
          "delete": function (id) {
            var question = gantt.locale.labels.confirm_deleting;
            var title = gantt.locale.labels.confirm_deleting_title;

            gantt._dhtmlx_confirm(question, title, function () {
              if (!gantt.isTaskExists(id)) {
                gantt.hideLightbox();
                return;
              }

              var task = gantt.getTask(id);
              if (task.$new) {
                gantt.silent(function () {
                  gantt.deleteTask(id, true);
                });
                gantt.refreshData();
              } else {
                gantt.deleteTask(id);
              }

              gantt.hideLightbox();
            });
          }
        }
      };

      //renders self
      gantt.render = function () {
        this.callEvent("onBeforeGanttRender", []);

        if (!this.config.sort && this._sort) {
          this._sort = undefined;
        }

        var pos = this.getScrollState();
        var posX = pos ? pos.x : 0;
        if (this._getHorizontalScrollbar()) {
          var scrollbar = this._getHorizontalScrollbar();
          posX = scrollbar.$config.codeScrollLeft || posX || 0;
        }


        var visible_date = null;
        if (posX) {
          visible_date = gantt.dateFromPos(posX + this.config.task_scroll_offset);
        }
        calculateScaleRange(this);

        this.$layout.$config.autosize = this.config.autosize;
        this.$layout.resize();

        if (this.config.preserve_scroll && pos) {

          if (posX) {
            var new_pos = gantt.getScrollState();
            var new_date = gantt.dateFromPos(new_pos.x);
            if (!(+visible_date == +new_date && new_pos.y == pos.y)) {
              if (visible_date) {
                this.showDate(visible_date);
              }
              if (pos.y)
                gantt.scrollTo(undefined, pos.y);
            }
          }
        }

        this.callEvent("onGanttRender", []);
      };

      //TODO: add layout.resize method that wouldn't trigger data repaint
      gantt.setSizes = gantt.render;

      gantt.locate = function (e) {
        var trg = domHelpers.getTargetNode(e);

        //ignore empty cells
        var className = domHelpers.getClassName(trg);
        if ((className || "").indexOf("gantt_task_cell") >= 0) return null;

        var targetAttribute = arguments[1] || this.config.task_attribute;

        var node = domHelpers.locateAttribute(trg, targetAttribute);
        if (node) {
          return node.getAttribute(targetAttribute);
        } else {
          return null;
        }
      };

      gantt._locate_css = function (e, classname, strict) {
        return domHelpers.locateClassName(e, classname, strict);
      };

      gantt._locateHTML = function (e, attribute) {
        return domHelpers.locateAttribute(e, attribute || this.config.task_attribute);
      };

      gantt.getTaskRowNode = function (id) {
        var els = this.$grid_data.childNodes;
        var attribute = this.config.task_attribute;
        for (var i = 0; i < els.length; i++) {
          if (els[i].getAttribute) {
            var value = els[i].getAttribute(attribute);
            if (value == id) return els[i];
          }
        }
        return null;
      };

      gantt.changeLightboxType = function (type) {
        if (this.getLightboxType() == type)
          return true;
        gantt._silent_redraw_lightbox(type);
      };


      gantt._get_link_type = function (from_start, to_start) {
        var type = null;
        if (from_start && to_start) {
          type = gantt.config.links.start_to_start;
        } else if (!from_start && to_start) {
          type = gantt.config.links.finish_to_start;
        } else if (!from_start && !to_start) {
          type = gantt.config.links.finish_to_finish;
        } else if (from_start && !to_start) {
          type = gantt.config.links.start_to_finish;
        }
        return type;
      };

      gantt.isLinkAllowed = function (from, to, from_start, to_start) {
        var link = null;
        if (typeof (from) == "object") {
          link = from;
        } else {
          link = { source: from, target: to, type: this._get_link_type(from_start, to_start) };
        }

        if (!link) return false;
        if (!(link.source && link.target && link.type)) return false;
        if (link.source == link.target) return false;

        var res = true;
        //any custom rules
        if (this.checkEvent("onLinkValidation"))
          res = this.callEvent("onLinkValidation", [link]);

        return res;
      };


      gantt._correct_dst_change = function (date, prevOffset, step, unit) {
        var time_unit = helpers.getSecondsInUnit(unit) * step;
        if (time_unit > 60 * 60 && time_unit < 60 * 60 * 24) {
          //correct dst change only if current unit is more than one hour and less than day (days have own checking), e.g. 12h
          var offsetChanged = date.getTimezoneOffset() - prevOffset;
          if (offsetChanged) {
            date = gantt.date.add(date, offsetChanged, "minute");
          }
        }
        return date;
      };

      gantt.isSplitTask = function (task) {
        gantt.assert(task && task instanceof Object, "Invalid argument <b>task</b>=" + task + " of gantt.isSplitTask. Task object was expected");
        return this.$data.tasksStore._isSplitItem(task);
      };

      gantt._is_icon_open_click = function (e) {
        if (!e)
          return false;
        var target = e.target || e.srcElement;
        if (!(target && target.className))
          return false;
        var className = domHelpers.getClassName(target);
        if (className.indexOf("gantt_tree_icon") !== -1 && (className.indexOf("gantt_close") !== -1 || className.indexOf("gantt_open") !== -1))
          return true;
        return false;
      };

    };
  }

  destructor = function(gantt) {

    function extend(gantt){
    
      gantt.destructor = function(){
        gantt.callEvent("onDestroy", []);
        this.clearAll();
    
        if(this.$root){
          delete this.$root.gantt;
        }
    
        this._eventRemoveAll();
        if(this.$layout){
          this.$layout.destructor();
        }
    
        this.resetLightbox();
    
        if(this._dp && this._dp.destructor){
          this._dp.destructor();
        }
        this.$services.destructor();
    
        // detachAllEvents should be called last, because in components may be attached events
        this.detachAllEvents();
    
        for(var i in this){
          if(i.indexOf("$") === 0){
            delete this[i];
          }
        }
        gantt.$destroyed = true;
      };
    }
    
    return extend;
  }

}
