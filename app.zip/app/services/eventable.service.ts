import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EventableService {
  _connected: any[];
  _silent_mode: boolean;

  constructor() { }

  EventHost() {
    this._connected = [];
    this._silent_mode = false;
  };

  _silentStart() {
    this._silent_mode = true;
  }

  _silentEnd() {
    this._silent_mode = false;
  }

  // tslint:disable-next-line: member-ordering
  // EventHostPrototype: any = {
   
  // };

  // tslint:disable-next-line: member-ordering

eventHost = new this.EventHost();
dhx_catch = [];

createEventStorage(obj) {
  // tslint:disable-next-line: variable-name
  // tslint:disable-next-line: only-arrow-functions
  var z: any = function () {
    var res = true;
    for (var i = 0; i < this.dhx_catch.length; i++) {
      if (this.dhx_catch[i]) {
        var zr = this.dhx_catch[i].apply(obj, arguments);
        res = res && zr;
      }
    }
    return res;
  };
  
  return z;
}

addEvent(ev) {
  if (typeof (ev) == "function")
    return this.dhx_catch.push(ev) - 1;
  return false;
}

removeEvent(id) {
  this.dhx_catch[id] = null;
}


attachEvent(name, catcher, callObj) {
  name = 'ev_' + name.toLowerCase();
  if (!this.eventHost[name]) {
    this.eventHost[name] = this.createEventStorage(callObj || this);
  }

  return (name + ':' + this.eventHost[name].addEvent(catcher)); //return ID (event name & event ID)
};

attachAll(callback, callObj) {
  this.attachEvent('listen_all', callback, callObj);
}

callEvent(name, arg0, callObj ?) {
  if (this.eventHost._silent_mode) return true;

  var handlerName = 'ev_' + name.toLowerCase();

  if (this.eventHost['ev_listen_all']) {
    this.eventHost['ev_listen_all'].apply(callObj || this, [name].concat(arg0));
  }

  if (this.eventHost[handlerName])
    return this.eventHost[handlerName].apply(callObj || this, arg0);
  return true;
}

checkEvent(name) {
  return (!!this.eventHost['ev_' + name.toLowerCase()]);
}

detachEvent(id) {
  if (id) {
    var list = id.split(':'); //get EventName and ID
    var eventName = list[0];
    var eventId = list[1];

    if (this.eventHost[eventName]) {
      this.eventHost[eventName].removeEvent(eventId); //remove event
    }
  }
}

detachAllEvents() {
  for (var name in this.eventHost) {
    if (name.indexOf("ev_") === 0)
      delete this.eventHost[name];
  }
}

makeEventable(obj) {

  var eventHost = new this.EventHost();
  obj.attachEvent = function(name, catcher, callObj) {
    name = 'ev_' + name.toLowerCase();
    if (!eventHost[name]) {
      eventHost[name] = this.createEventStorage(callObj || this);
    }

    return (name + ':' + eventHost[name].addEvent(catcher)); //return ID (event name & event ID)
  };
  obj.attachAll = function (callback, callObj) {
    this.attachEvent('listen_all', callback, callObj);
  };

  obj.callEvent = function (name, arg0, callObj) {
    if (eventHost._silent_mode) return true;

    var handlerName = 'ev_' + name.toLowerCase();

    if (eventHost['ev_listen_all']) {
      eventHost['ev_listen_all'].apply(callObj || this, [name].concat(arg0));
    }

    if (eventHost[handlerName])
      return eventHost[handlerName].apply(callObj || this, arg0);
    return true;
  };
  obj.checkEvent = function (name) {
    return (!!eventHost['ev_' + name.toLowerCase()]);
  };
  obj.detachEvent = function (id) {
    if (id) {
      var list = id.split(':'); //get EventName and ID
      var eventName = list[0];
      var eventId = list[1];

      if (eventHost[eventName]) {
        eventHost[eventName].removeEvent(eventId); //remove event
      }
    }
  };
  obj.detachAllEvents = function () {
    for (var name in eventHost) {
      if (name.indexOf("ev_") === 0)
        delete eventHost[name];
    }
  };
}
}
