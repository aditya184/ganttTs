import { Injectable } from '@angular/core';
import { ConstantService } from './constant.service';
import { CommonService } from './common.service';
import { EventableService } from './eventable.service';
import { HelpersService } from './helpers.service';
import { UiService } from './ui.service';
import { CoreService } from './core.service';
import { CssSkinsService } from './css-skins.service';
import { Promise } from '../../../node_modules/bluebird/js/browser/bluebird.js';



@Injectable({
  providedIn: 'root'
})
export class GanttService {
  constructor(private constantService: ConstantService,
    private commonService: CommonService,
    private eventableService: EventableService,
    private helperService: HelpersService,
    private uiService: UiService,
    private coreService: CoreService,
    private cssSkinsService: CssSkinsService) {
    console.log(this.commonService);
  }
  constants: string;
  version: string;
  license: string;
  ext: {};
  templates: {};
  keys = {
    edit_save: this.constantService.KEY_CODES.ENTER,
    edit_cancel: this.constantService.KEY_CODES.ESC
  };

  gantt = function(gantt) {

    var gantt = new this.DHXGantt();

    gantt.$services = this.commonService.servicesEnum;
    gantt.config = this.commonService.result;
    gantt.ajax = this.commonService.requestMethods(gantt);
    gantt.date = this.commonService.date(gantt);
    // var dnd = this.commonService.dnd(gantt);
    // this.commonService.register("dnd", function () { return dnd; });

    this.commonService.register("config", function () {
      return gantt.config;
    });
    this.commonService.register("date", function () {
      return gantt.date;
    });
    this.commonService.register("locale", function () {
      return gantt.locale;
    });
    this.commonService.register("templates", function () {
      return gantt.templates;
    });

    var templatesLoader = this.commonService.templates(gantt);
    this.commonService.register("templateLoader", function () {
      return templatesLoader;
    });

    var eventable = this.eventableService;
    eventable.makeEventable(gantt);


    // var StateService = this.commonService.StateService();
    var stateService = this.commonService;

    stateService.registerProvider("global", function () {
      var res = {
        min_date: gantt._min_date,
        max_date: gantt._max_date,
        selected_task: null
      };

      // do not throw error if getState called from non-initialized gantt
      if (gantt.$data && gantt.$data.tasksStore) {
        res.selected_task = gantt.$data.tasksStore.getSelectedId();
      }
      return res;
    });
    gantt.getState = stateService.getState;
    this.commonService.register("state", function () {
      return stateService;
    });

    var utils = this.helperService;
    utils.mixin(gantt, this.helperService);

    gantt.Promise = Promise;
    gantt.env = this.constantService.env;

    var domHelpers = this.helperService;
    gantt.utils = {
      dom: {
        getNodePosition: domHelpers.getNodePosition,
        getRelativeEventPosition: domHelpers.getRelativeEventPosition,
        isChildOf: domHelpers.isChildOf,
        hasClass: domHelpers.hasClass,
        closest: domHelpers.closest
      }
    };

    var domEvents = this.helperService;
    utils.event = domEvents.attach;
    utils.eventRemove = domEvents.detach;
    gantt._eventRemoveAll = domEvents.detachAll;
    gantt._createDomEventScope = domEvents.extend;

    utils.mixin(gantt, this.helperService.messageBox(gantt));
    var uiApi = this.uiService.uiApi.initUI(gantt);
    gantt.$ui = uiApi.factory;
    gantt.$ui.layers = uiApi.render;
    gantt.$mouseEvents = uiApi.mouseEvents;
    this.commonService.register("mouseEvents", function () {
      return gantt.$mouseEvents;
    });
    gantt.mixin(gantt, uiApi.layersApi);

    this.coreService.dataTaskLayers(gantt);

    this.commonService.register("layers", function () {
      return uiApi.layersService;
    });

    var createLayoutFacade = this.coreService.createLayoutFacadeJs;
    gantt.mixin(gantt, createLayoutFacade());

    this.coreService.datastoreHooks(gantt);

    // Pending
    const DataProcessor = this.coreService.dataProcessor;
    // gantt.dataProcessor = DataProcessor.DEPRECATED_api;
    // gantt.createDataProcessor = DataProcessor.createDataProcessor;

    this.coreService.plugins(gantt);

    this.coreService.dynamicLoading(gantt);
    this.coreService.gridColumnApi(gantt);
    this.coreService.wai_aria(gantt);
    this.coreService.tasks(gantt);
    this.coreService.load(gantt);
    this.coreService.workTime(gantt);
    this.coreService.data(gantt);
    this.coreService.lightbox(gantt);
    this.coreService.lightboxOptionalTime(gantt);
    this.coreService.dataTaskType(gantt);
    this.coreService.cachedFunctions(gantt);
    this.coreService.skin(gantt);
    this.cssSkinsService.skyblue(gantt);
    this.cssSkinsService.meadow(gantt);
    this.cssSkinsService.terrace(gantt);
    this.cssSkinsService.broadway(gantt);
    this.cssSkinsService.material(gantt);
    this.cssSkinsService.contrastBlack(gantt);
    this.cssSkinsService.contrastWhite(gantt);
    this.coreService.touch(gantt);
    this.constantService.locale(gantt);
    this.coreService.ganttCore(gantt);
    this.coreService.destructor(gantt);

    return gantt;


  };

  DHXGantt() {
    // this.constants = this.constantService
    this.version = "6.2.3";
    this.license = "gpl";
    this.templates = {};
    this.ext = {};
    this.keys = this.keys;
  }

}
