import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
import 'dhtmlx-gantt';
import { GanttService } from '../services/gantt.service';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-gantt',
  templateUrl: './gantt.component.html',
  styleUrls: ['./gantt.component.css'],
  providers: [GanttService],
})
export class GanttComponent implements OnInit {
  ext: {};
  keys: { edit_save: any; edit_cancel: any; };
  constructor(private datepipe: DatePipe, private ganttService: GanttService) { }
  @ViewChild('gantt_here') ganttContainer: ElementRef;

  constants;
  templates;

  ngOnInit() {

    // gantt.init(this.ganttContainer.nativeElement);
    this.ganttService.gantt(this.ganttContainer.nativeElement);
    

    // const zoomConfig = {
    //   levels: [
    //     {
    //       name: 'day',
    //       scale_height: 27,
    //       min_column_width: 80,
    //       scales: [
    //         { unit: 'day', step: 1, format: '%d %M' }
    //       ]
    //     },
    //     {
    //       name: 'week',
    //       scale_height: 50,
    //       min_column_width: 50,
    //       scales: [
    //         {
    //           unit: 'week', step: 1, format(date) {
    //             const dateToStr = gantt.date.date_to_str('%d %M');
    //             const endDate = gantt.date.add(date, -6, 'day');
    //             const weekNum = gantt.date.date_to_str('%W')(date);
    //             return '#' + weekNum + ', ' + dateToStr(date) + ' - ' + dateToStr(endDate);
    //           }
    //         },
    //         { unit: 'day', step: 1, format: '%j %D' }
    //       ]
    //     },
    //     {
    //       name: 'month',
    //       scale_height: 50,
    //       min_column_width: 120,
    //       scales: [
    //         { unit: 'month', format: '%F, %Y' },
    //         { unit: 'week', format: 'Week #%W' }
    //       ]
    //     },
    //     {
    //       name: 'quarter',
    //       height: 50,
    //       min_column_width: 90,
    //       scales: [
    //         { unit: 'month', step: 1, format: '%M' },
    //         {
    //           unit: 'quarter', step: 1, format(date) {
    //             const dateToStr = gantt.date.date_to_str('%M');
    //             const endDate = gantt.date.add(gantt.date.add(date, 3, 'month'), -1, 'day');
    //             return dateToStr(date) + ' - ' + dateToStr(endDate);
    //           }
    //         }
    //       ]
    //     },
    //     {
    //       name: 'year',
    //       scale_height: 50,
    //       min_column_width: 30,
    //       scales: [
    //         { unit: 'year', step: 1, format: '%Y' }
    //       ]
    //     }
    //   ]
    // };

    // gantt.ext.zoom.init(zoomConfig);
    // this.ganttContainer.nativeElement.innerHTML = this.initialize();
    // document.getElementById('add_task_btn').addEventListener('click', this.add, false);
    // this.date_grid(new Date(), {});

    // this.gantt();
    // var gantt1 = new this.DHXGantt();
  }

  // zoomIn() {
  //   gantt.ext.zoom.zoomIn();
  // }

  // zoomOut() {
  //   gantt.ext.zoom.zoomOut();
  // }

}

